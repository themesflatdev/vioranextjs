Đọc CLAUDE.md trước. File này là TÀI LIỆU THAM CHIẾU DÙNG CHUNG cho MỌI
niche trong dự án Viora — đọc lại file này mỗi khi bắt đầu 1 niche mới
hoặc 1 bước mới, không chỉ đọc 1 lần.

# 1. Bảng style Header của toàn bộ 20 niche + landing (đã khảo sát)

| Niche | Style header | Breakpoint mobile (ĐÃ ĐO) | Cơ chế scroll |
|---|---|---|---|
| corporate | style-default | lg (991/992) | header-fixed (ngưỡng 300px) |
| agency | style-2 | lg (991/992) | header-fixed (ngưỡng 300px) |
| insurance | style-3 | **xl (1199/1200)** | header-fixed (ngưỡng 300px) |
| medical | style-4 | lg (991/992) | header-sticky (direction-aware) |
| restaurant | style-5 | lg (991/992) | header-sticky (direction-aware) |
| aitech | style-6 | xl (1199/1200) | header-sticky (direction-aware) |
| healthcoach | style-7 | lg (991/992) | header-sticky (direction-aware) |
| saas | style-8 | lg (991/992) | header-sticky (direction-aware) |
| spasalon | style-9 | xl (1199/1200) | header-fixed (ngưỡng 300px) |
| coworkingspace | style-9 v2 | xl (1199/1200) | header-sticky (direction-aware) |
| aicontentwriter | style-10 | lg (991/992) | header-fixed (ngưỡng 300px) |
| construction | style-11 | xl (1199/1200) | header-sticky (direction-aware) |
| gardenlandscaping | style-12 | xl (1199/1200) | header-sticky (direction-aware) |
| carservices | style-13 | xl (1199/1200) | header-sticky (direction-aware) |
| charity | style-14 | xl (1199/1200) | header-sticky (direction-aware) |
| logistics | style-15 | xl (1199/1200) | header-sticky (direction-aware) |
| solarenergy | style-16 | lg (991/992) | header-sticky (direction-aware) |
| agriculturefarming | style-17 | lg (991/992) | header-sticky (direction-aware) |
| lawyer | style-18 | xl (1199/1200) | header-sticky (direction-aware) |
| architechture | style-19 | xl (1199/1200) | header-fixed (ngưỡng 300px) |
| landing | style-default landing | lg (991/992) | header-fixed (ngưỡng 300px) |

TẤT CẢ 20 niche + landing ĐÃ XÁC NHẬN KHÔNG include splitting.min.js —
hiệu ứng hover chữ ở MỌI niche chỉ là CSS opacity fade đơn giản, KHÔNG
BAO GIỜ cần cài package Splitting cho phần header. Đây là kết luận
CHUNG CHO TOÀN DỰ ÁN, không cần verify lại mỗi niche.

Bảng breakpoint/cơ chế scroll trên ĐÃ ĐO bằng Playwright (không suy từ
tên class) — dùng trực tiếp, không cần đo lại trừ khi phát hiện mâu
thuẫn khi code thực tế.

spasalon và coworkingspace (cùng gốc style-9) có layout ĐẶC BIỆT: logo
NẰM GIỮA, menu chia 2 nửa trái/phải (không phải 1 dải liên tục) — mỗi
bên là 1 phần tử `.main-menu` riêng, cả 2 phải ẩn/hiện đồng thời ở đúng
breakpoint xl.

QUY TẮC: mỗi niche có header THIẾT KẾ RIÊNG — KHÔNG dùng chung code Header
giữa các niche, TRỪ 2 cặp trên (kiểm tra kỹ trước khi quyết định dùng
chung, không giả định). Trong CÙNG 1 niche, mọi trang con dùng chung đúng
1 component Header.

# 2. Danh sách trang từng niche (đã khảo sát — dùng để biết phạm vi thật)

- **agency (12 trang):** index, about, contact, faqs, our-pricing,
  our-team, portfolio, portfolio-detail, service-detail, services,
  team-detail, testimonials
- **corporate (16 trang):** index, about-us, contact, services,
  service-detail, our-team, team-detail, portfolio, portfolio-detail,
  blog-full-width, blog-with-sidebar, blog-detail, carrer, carrer-detail,
  FAQs, 404
- **insurance (15 trang):** index, about-us, contact, faqs, pricing,
  our-team, team-detail, services, service-detail, porfolio,
  porfolio-detail, blog-list, blog-grid, blog-detail, testimonials
- **medical (18 trang):** index, about, contact, faqs, pricing,
  appointment, costcalculator, workinghours, our-doctor, doctor-detail,
  service, service-detail, portfolio, portfolio-detail, bloglist,
  bloggrid, blogdetail, testimonials
- **spasalon (17 trang):** index, about, contact, faqs, booking,
  calender, packages, staffs, member-detail, service, service-detail,
  portfolio, portfolio-detail, bloglist, bloggrid, blogdetail,
  testimonials
- **15 niche còn lại CHỈ có index.html:** agriculturefarming,
  aicontentwriter, aitech, architechture, carservices, charity,
  construction, coworkingspace, gardenlandscaping, healthcoach, lawyer,
  logistics, restaurant, saas, solarenergy

KHÔNG tự thêm trang nào ngoài danh sách trên cho mỗi niche — nếu nghi ngờ
thiếu/thừa trang so với thực tế HTML gốc, tự kiểm tra lại bằng lệnh
`ls ../viora/viora/demo-<niche>/*.html` trước khi kết luận.

# 3. Breakpoint responsive dùng chung TOÀN THEME (bắt buộc tuân theo)

Định nghĩa gốc: assets/scss/abstracts/_mixin.scss

| Tên | max-width | min-width | Ý nghĩa |
|---|---|---|---|
| sm | 575px | 576px | điện thoại nhỏ |
| md | 767px | 768px | điện thoại lớn/tablet dọc |
| lg | 991px | 992px | tablet ngang — MỐC ẨN/HIỆN MENU MOBILE (class d-lg-none) |
| llg | 1024px | 1025px | tablet lớn |
| xl | 1199px | 1200px | desktop nhỏ — mốc đổi layout phức tạp (nếu có, kiểu horizontal-accordion) |
| xxl | 1440px | 1441px | desktop vừa |
| xxxl | 1599px | 1600px | desktop lớn |
| full | 1920px | 1921px | màn rất lớn |

BẮT BUỘC: khi convert bất kỳ section có hành vi đổi responsive (ẩn/hiện,
đổi layout, đổi số cột...), tra đúng breakpoint tương ứng trong bảng này
từ SCSS gốc của section đó, KHÔNG tự đặt breakpoint theo cảm tính.

# 4. Quy trình chuẩn BẮT BUỘC cho MỖI niche (6 bước, làm tuần tự)

## Bước 1 — Copy assets riêng niche
- Copy `../viora/viora/demo-<niche>/css/<Niche>.css` và
  `../viora/viora/demo-<niche>/images/` vào thư mục tách biệt (không trộn
  với assets/ chung), theo đúng cấu trúc đã định trong CLAUDE.md.

## Bước 2 — Header + Mobile nav
- Đọc ĐỦ CẢ 2 khối `<header>` (bản `header-fixed` ngoài #smooth-wrapper +
  bản thường trong #smooth-wrapper/#smooth-content) của TRANG ĐẦU TIÊN
  (thường là index.html) — xác nhận nội dung 2 bản có giống hệt nhau
  không (thường giống, chỉ khác vị trí DOM).
- Đọc RIÊNG mobile offcanvas — KHÔNG giả định giống desktop. Đối chiếu
  từng mục, đặc biệt danh sách "Demos" (đã từng phát hiện mobile liệt kê
  đủ 20, desktop chỉ 12 + nút xem thêm ở niche corporate — kiểm tra lại
  hiện tượng này có lặp lại ở niche khác không).
- Tách data menu vào `data/demo-<niche>/menu.ts`.
- Dựng layout.tsx cho route group `(demo-<niche>)` với cấu trúc
  #smooth-wrapper/#smooth-content nếu niche đó dùng GSAP ScrollSmoother
  (kiểm tra script tag trong HTML gốc trước, không giả định mọi niche
  đều dùng).
- Viết prompt riêng `.claude/prompts/<niche>-header.md` trước khi giao
  Claude Code thực thi — không code trực tiếp mà không có prompt ghi lại.

## Bước 3 — Trang chủ (index.html), làm THEO TỪNG NHÓM section
- Liệt kê hết section trong trang (kể cả section/div KHÔNG nằm trong thẻ
  `<section>` — đã từng bị sót 1 marquee vì lý do này ở dự án Agentra,
  RÚT KINH NGHIỆM: dùng `grep -n "<section\|infiniteSlide-app\|<div class=\"section-"` 
  thay vì chỉ tìm `<section`).
- Chia 2-3 section/nhóm, làm xong nhóm nào báo cáo nhóm đó, KHÔNG làm 1
  lượt hết cả trang.
- Section dùng thư viện bên thứ 3 (Swiper, GSAP/ScrollTrigger/SplitText,
  Isotope, Atropos, image-compare-viewer, Splitting.js, Fancybox...) →
  BẮT BUỘC đọc đúng file JS gốc điều khiển hiệu ứng đó (thường trong
  assets/js/ hoặc file riêng của niche) TRƯỚC khi viết lại bằng React
  hook. KHÔNG đoán qua giao diện.
- Trước khi kết luận bất kỳ hiện tượng nào là "bug" (lệch layout, dư
  khoảng trắng, ảnh sai kích thước...), XÁC MINH bằng cách đọc code gốc
  hoặc dùng Playwright chạy thử HTML gốc (cuộn tới đúng vị trí, đợi
  animation chạy xong rồi mới đo) — KHÔNG đoán qua ảnh chụp tĩnh.

## Bước 4 — Trang con (nếu niche có, theo đúng danh sách mục 2)
- Làm từng trang một, báo cáo xong mới sang trang kế.
- Tối đa tái dùng section/component/data đã có từ trang chủ hoặc trang
  khác CÙNG NICHE — kiểm tra trước khi viết mới, tránh trùng lặp.
- Trang dạng chi tiết (service-detail, portfolio-detail, blog-detail,
  team-detail, doctor-detail, member-detail...) → route động `[slug]`.
  Nếu HTML gốc chỉ viết 1 bản nội dung demo dùng chung cho mọi item (như
  đã gặp ở service-details/project-details của Agentra) → giữ đúng thực
  tế đó, KHÔNG tự bịa nội dung riêng cho từng item. Chỉ phần thật sự
  mang tính điều hướng động (next/prev, breadcrumb theo tên) mới cần làm
  động thật.
- Gắn `slug` vào data ngay khi tạo, cập nhật lại MỌI nơi đang link tĩnh
  tới trang đó (menu, card danh sách...).

## Bước 5 — Rà soát responsive & animation
- Kiểm tra đủ các breakpoint liên quan ở mục 3 bằng cách thu nhỏ/phóng to
  cửa sổ trình duyệt qua đúng các mốc đó, không chỉ test 1 kích thước.
- Nếu nghi ngờ hành vi HTML gốc ở 1 breakpoint cụ thể, dùng Playwright đo
  trực tiếp trên HTML gốc (viewport đúng bằng breakpoint nghi ngờ, cuộn
  tới, đợi animation) rồi mới kết luận.

## Bước 6 — Rà soát cuối niche
- `npm run build` phải pass, không lỗi.
- Không còn phụ thuộc jQuery/Bootstrap JS ở bất kỳ đâu trong niche vừa
  làm (`grep -rn "jQuery\|\\$(" src/` để tự kiểm tra).
- Mở song song HTML gốc và bản Next.js, đối chiếu từng trang (nội dung,
  giao diện, responsive) — báo cáo rõ nếu có sai khác, kèm lý do (thiếu
  sót thật hay chủ đích khác theo yêu cầu người dùng).

# 5. Cơ chế scroll Header — CÓ 2 LOẠI KHÁC NHAU (phát hiện từ corporate, áp dụng luôn cho niche khác)

Đã đọc assets/js/main.js, xác nhận có 2 hàm xử lý scroll khác nhau, áp
dụng theo đúng class mà header niche đó có:

- **`.header-fixed`** (corporate dùng): hàm `headerFixed` — ngưỡng đơn
  giản, threshold 300px. scrollTop > 300 → thêm class "is-fixed"; ngược
  lại gỡ bỏ. KHÔNG quan tâm hướng cuộn.
- **`.header-sticky`** (đa số niche khác dùng, theo bảng ở mục 3): hàm
  `headerSticky` — có HƯỚNG (direction-aware): cuộn XUỐNG thì ẩn
  (`is-sticky` gỡ), cuộn LÊN thì hiện lại (`is-sticky` thêm vào), có
  buffer delta=10px tránh nhạy quá, ngưỡng bắt đầu áp dụng từ
  scrollTop >= 400 (dưới 400 luôn ở trạng thái thường, không sticky).

TRƯỚC KHI code hook scroll cho niche mới: kiểm tra header niche đó dùng
class nào (`header-fixed` hay `header-sticky`, xem bảng mục 3 để tra
nhanh, nhưng LUÔN xác nhận lại bằng cách đọc đúng HTML gốc của niche đó,
vì bảng chỉ ghi nhận tại thời điểm khảo sát ban đầu). Viết đúng hook
tương ứng, KHÔNG dùng chung 1 hook cho cả 2 cơ chế.

# 6. Quy tắc xử lý link Footer/menu trỏ SAI NICHE (phát hiện ở footer agency, áp dụng cho TẤT CẢ niche)

Đã phát hiện: nhiều niche có link trong Footer (và có thể cả menu) bị
COPY NHẦM sang trang của niche KHÁC (thường là corporate, vì corporate
có đủ trang nhất nên hay được dùng làm gốc để nhân bản theme). Ví dụ ở
agency: "About" trỏ `../demo-corporate/about-us.html` dù agency có sẵn
`about.html` riêng.

QUY TẮC XỬ LÝ (đã thống nhất với người dùng, áp dụng cho MỌI niche khi
làm Footer/menu):
- Nếu niche ĐANG LÀM có trang tương ứng thật (tra bảng mục 2 — danh sách
  trang từng niche) → SỬA lại trỏ về ĐÚNG trang của CHÍNH niche đó
  (KHÔNG giữ nguyên link trỏ sang niche khác).
- Nếu niche ĐANG LÀM KHÔNG CÓ trang tương ứng (ví dụ hầu hết niche không
  có trang Blog riêng) → GIỮ NGUYÊN link trỏ sang trang của corporate
  (mượn tạm, đây là chủ đích chấp nhận được, không phải bug cần sửa).

LUÔN đối chiếu với bảng danh sách trang mục 2 trước khi quyết định sửa
hay giữ nguyên — không đoán.

# 7. Cơ chế Footer accordion mobile (phát hiện từ corporate — KHÔNG PHẢI niche nào cũng có)

Đã xác nhận: KHÔNG PHẢI mọi niche đều dùng kiểu accordion thu gọn ở
mobile cho Footer — vd agency, aitech KHÔNG có phần tử `.tf-collapse-content`
trong footer (footer của các niche này đơn giản hơn, không chia cột
theo kiểu accordion). Với niche NÀO CÓ dùng accordion (đã xác nhận ở
corporate, medical, spasalon, construction, lawyer — và nhiều niche khác
có khả năng cũng dùng, cần kiểm tra riêng từng cái):
- Breakpoint kích hoạt: "md" (767px max / 768px min) — đã đo xác nhận
  giống nhau ở nhiều niche.
- Trên 767px: nội dung LUÔN hiện, không có hành vi accordion.
- Dưới/bằng 767px: nội dung ẩn mặc định, bấm heading để mở, các cột
  ĐỘC LẬP nhau (không phải kiểu chỉ 1 mở tại 1 thời điểm).

TRƯỚC KHI code Footer cho niche mới: kiểm tra xem HTML gốc niche đó CÓ
hay KHÔNG có class `.tf-collapse-content`/`.footer-heading-mobile` —
không giả định niche nào cũng có.

# 8. Bài học quan trọng — KIỂM TRA BẮT BUỘC khi bắt đầu niche MỚI (phát hiện từ bug thật ở agency)

## 8.1. Luôn xác nhận import chain CSS đầy đủ

Đã gặp bug thật: trang /demo-agency hiện link bị GẠCH CHÂN + MÀU XANH
(giống style mặc định của trình duyệt) thay vì đúng style theme (không
gạch chân, màu theo theme) — nguyên nhân là _reset.scss (có rule
`a { text-decoration: none; }` ở dòng ~773) KHÔNG được import đầy đủ vào
route/layout của niche đó.

TRƯỚC KHI báo cáo "xong" bất kỳ niche nào, BẮT BUỘC kiểm tra:
- File SCSS/CSS của niche đó có import ĐÚNG THỨ TỰ: reset chung → biến
  chung (abstracts) → component chung → CSS override riêng niche
  (demo-<niche>.css/scss)?
- Mở route đó bằng Playwright, kiểm tra 1 vài phần tử cơ bản (thẻ <a>
  trong menu) có đúng `text-decoration: none` qua computed style không —
  nếu vẫn "underline" nghĩa là thiếu import, phải sửa ngay, không được
  báo cáo "xong" khi còn lỗi này.
- 1 lỗi import CSS bị thiếu thường làm SAI LỆCH TOÀN BỘ TRANG (không chỉ
  1 chỗ), nên nếu thấy nhiều phần tử cùng sai kiểu (menu, section, màu
  chữ...) → nghi ngờ ĐẦU TIÊN là lỗi import CSS, kiểm tra trước khi sửa
  từng chỗ riêng lẻ.

## 8.2. Cơ chế UI dùng chung PHẢI trích xuất thành hook/component tái dùng, KHÔNG viết lại mỗi niche

Đã gặp bug thật: mobile offcanvas accordion ở corporate ĐÃ ĐƯỢC SỬA có
transition mượt (giảm giật khi mở/đóng), nhưng khi làm niche agency,
Claude Code KHÔNG tái dùng lại đúng cơ chế đó, viết lại từ đầu và bị
MẤT effect transition này.

QUY TẮC: bất kỳ cơ chế UI/animation nào đã sửa/tinh chỉnh đúng cho 1
niche (transition, easing, threshold...) — nếu đó là cơ chế CHUNG (không
riêng biệt theo thiết kế niche đó), PHẢI trích xuất thành hook dùng
chung trong src/hooks/ (vd useCollapseTransition.ts) NGAY LÚC ĐÓ, rồi mọi
niche sau tái dùng lại hook này. KHÔNG viết lại logic collapse/transition
riêng cho từng niche.

Trước khi bắt đầu bất kỳ niche mới nào, kiểm tra src/hooks/ xem đã có
hook tương ứng cho: accordion (single-open và multi-open), collapse
transition mượt, header scroll (fixed/sticky), count-up, marquee, custom
cursor, Swiper thumbs đồng bộ — dùng lại nếu có, CHỈ viết mới khi thực sự
chưa tồn tại.

## 8.3. Biến CSS màu riêng niche PHẢI scope theo class `.niche-<niche>`, KHÔNG BAO GIỜ đặt ở `:root`

Đã gặp bug thật: chuyển qua lại giữa các niche trong CÙNG 1 session
Next.js (client-side navigation), MÀU SẮC/BIẾN CSS BỊ LẪN QUA NHAU — do
mọi file `src/styles/demo-<niche>.scss` từng định nghĩa biến màu riêng
(`--Primary`, `--Secondary`...) ở `:root` (phạm vi TOÀN TÀI LIỆU), trong
khi Next.js gộp chung mọi CSS import (kể cả import riêng trong từng
`layout.tsx` của route group) vào 1 bundle CSS TOÀN CỤC — file nào load
sau trong bundle sẽ đè biến màu của MỌI trang, không phân biệt route.

QUY TẮC ĐÃ ÁP DỤNG CHO ĐỦ 20 NICHE (verify bằng Playwright, cả dev lẫn
production build, điều hướng qua lại nhiều chiều — không còn lẫn màu):
- Mỗi file `src/styles/demo-<niche>.scss` bọc khối biến màu riêng niche
  trong selector class `.niche-<niche>` (KHÔNG dùng `:root`, KHÔNG dùng
  `[data-niche="..."]`), ví dụ:
  ```scss
  .niche-corporate {
      --Primary: #94F3B4;
      --Secondary: #154040;
      ...
  }
  ```
- Component `HeaderSection` (`src/components/layout/demo-<niche>/HeaderSection.tsx`)
  đặt className `niche-<niche>` lên phần tử wrapper NGOÀI CÙNG bọc cả
  Header (fixed + thường), `#smooth-wrapper/#smooth-content`, children và
  Footer — đảm bảo MỌI phần tử con của route đó đều nằm trong phạm vi
  scope này.
- Biến DÙNG CHUNG THẬT SỰ toàn site (không đổi theo niche — vd `--Black`,
  `--White`, `--body-text`, `--Line`, `--Bg-light`, `--Bg-dark`... định
  nghĩa ở `src/styles/abstracts/_variable.scss`) VẪN giữ nguyên ở `:root`
  — KHÔNG scope nhầm các biến này.

Vì dùng SELECTOR RIÊNG BIỆT cho từng niche (không phải cùng 1 selector
`:root` bị ghi đè theo thứ tự nạp), CSS của các niche không thể xung đột
nhau dù Next.js có gộp chung bundle hay tích luỹ nhiều stylesheet trong
`<head>` khi điều hướng client-side — bug KHÔNG THỂ tái diễn theo đúng cơ
chế cũ nữa.

TRƯỚC KHI viết file `demo-<niche>.scss` cho niche MỚI: LUÔN bọc biến màu
riêng niche trong `.niche-<niche>` ngay từ đầu, KHÔNG viết `:root` cho
biến này dù chỉ tạm thời rồi sửa sau.

## 8.4. Hệ quả của 8.3 — `body`/`html` KHÔNG BAO GIỜ đọc được biến của `.niche-<niche>`, phải set color NGAY TẠI wrapper

Đã gặp bug thật (phát hiện sau khi áp dụng 8.3): toàn bộ heading/text trên
trang chủ corporate (và các niche khác) hiện MÀU ĐEN thay vì đúng
`--Secondary` của niche — do `_reset.scss` có rule dùng chung:
```scss
body {
    color: var(--Secondary);
}
```
Custom property CSS chỉ kế thừa THEO CHIỀU XUỐNG (cha → con). Từ khi áp
dụng 8.3, `--Secondary` chỉ tồn tại trong `.niche-<niche>` — mà phần tử
này là DIV CON nằm BÊN TRONG `<body>` (do `HeaderSection` render), tức
`<body>` là TỔ TIÊN của `.niche-<niche>`, không phải hậu duệ — nên
`body { color: var(--Secondary) }` không bao giờ resolve được (không lỗi
nhưng luôn ra giá trị mặc định/đen), kéo theo MỌI heading/text con không
có `color` riêng (kế thừa từ body) đều bị sai.

QUY TẮC ĐÃ SỬA (áp dụng cho ĐỦ 20 niche, verify bằng Playwright — lấy
computed style của heading không có class `text_white`/tương tự, đối
chiếu đúng hex --Secondary hoặc --Text-* của niche đó):
- XOÁ `color: var(--Secondary)` khỏi rule `body` dùng chung trong
  `_reset.scss` — vì không bao giờ đúng cho niche nào cả, chỉ để lại các
  property KHÔNG phụ thuộc biến niche (line-height, padding, font-family
  dùng `--font-main` do next/font cấp qua class `<html>`, không phải biến
  scoped theo niche nên vẫn đọc được bình thường).
- MỖI file `demo-<niche>.scss` tự đặt `color: var(--Secondary)` (hoặc
  đúng biến niche đó dùng, có niche dùng `--Text-secondary`/`--Text-muted`/
  `--White` — biến DÙNG CHUNG thật ở `:root`, không phải lỗi) NGAY TRONG
  CHÍNH khối `.niche-<niche> { ... }` (cùng chỗ khai báo `--Primary`/
  `--Secondary`) — KHÔNG đặt riêng ở 1 rule `body { }` tách biệt trong
  từng file demo-<niche>.scss (rule `body` không phân biệt niche nào, các
  file lại bundle chung — nếu mỗi niche tự viết `body { color: ... }`
  riêng thì các rule này ĐÈ LÊN NHAU không theo niche, tái diễn đúng kiểu
  bug ở mục 8.3 nhưng ở cấp `body` thay vì `:root`).
- 2 niche `construction` và `coworkingspace` KHÔNG định nghĩa `--Secondary`
  (đúng như HTML gốc — bản thân HTML gốc cũng không định nghĩa biến này
  cho 2 niche này) → GIỮ NGUYÊN không thêm color, đây không phải bug cần
  sửa (theo quy tắc "giữ nguyên nội dung/hành vi HTML gốc" ở CLAUDE.md).

QUY TẮC CHUNG rút ra: BẤT KỲ selector nào là TỔ TIÊN của `.niche-<niche>`
trong DOM (`body`, `html`, `*` dùng chung...) — KHÔNG được dùng biến màu
riêng niche (`var(--Primary)`, `var(--Secondary)`, `var(--font-main2)`...)
vì chắc chắn không resolve được. Bất kỳ style nào cần áp dụng cho toàn bộ
nội dung 1 niche (đặc biệt text color, vì color là property kế thừa) PHẢI
đặt NGAY TẠI selector `.niche-<niche>` để con cháu kế thừa đúng xuống
dưới — không đặt ở `body`/`html`.

# 9. Thứ tự ưu tiên xử lý toàn dự án (ĐÃ CẬP NHẬT LẦN 2 — theo từng niche trọn vẹn, không dàn trải)

QUYẾT ĐỊNH MỚI NHẤT (thay thế cách chia theo Giai đoạn A/B/C/D cũ ở dưới
— cách cũ gây lỗi rò rỉ CSS/context giữa các niche do nhảy qua lại liên
tục): làm TRỌN VẸN 1 NICHE (Header → Footer → Trang chủ → TOÀN BỘ trang
con của niche đó) RỒI MỚI CHUYỂN SANG NICHE KHÁC. Không quay lại niche
cũ giữa chừng để làm dở dang việc khác, tránh gây rối và tái diễn bug
kiểu context-switch (màu CSS lẫn nhau, quên tái dùng hook chung...).

## Thứ tự niche (đã có Header+Footer đủ 20 niche, Home đã xong corporate
## và agency — tiếp tục dứt điểm CORPORATE trước khi sang agency)

1. **corporate** — ĐANG LÀM DỞ. Header ✅, Footer ✅, Home ✅ (đang audit
   sửa lỗi). TIẾP THEO: làm dứt điểm ĐỦ 15 trang con còn lại theo đúng
   thứ tự sau (bắt đầu từ Blog Full Width theo yêu cầu người dùng):
   blog-full-width, blog-with-sidebar, blog-detail, about-us, contact,
   services, service-detail, our-team, team-detail, portfolio,
   portfolio-detail, carrer, carrer-detail, FAQs, 404.
2. **agency** — Header ✅, Footer ✅, Home ✅ (đang audit sửa lỗi). Sau
   khi xong corporate hoàn toàn, làm dứt điểm 11 trang con của agency:
   about, contact, faqs, our-pricing, our-team, portfolio,
   portfolio-detail, service-detail, services, team-detail, testimonials.
3. **insurance** — Header ✅ Footer ✅, CHƯA làm Home. Làm Home rồi dứt
   điểm 14 trang con.
4. **medical** — Header ✅ Footer ✅, CHƯA làm Home. Làm Home rồi dứt
   điểm 17 trang con.
5. **spasalon** — Header ✅ Footer ✅, CHƯA làm Home. Làm Home rồi dứt
   điểm 16 trang con.
6. 15 niche còn lại (chỉ có index.html, Header+Footer đã xong) — mỗi
   niche chỉ cần làm Home, không có trang con. Thứ tự tuỳ ý.
7. Trang /landing (Header ✅, Footer ✅) — hoàn thiện phần nội dung giữa
   trang (section-demos lưới lọc 20 demo, các section overview/features/
   device-mobile...) — làm CUỐI CÙNG.

TRƯỚC KHI chuyển sang niche/trang con tiếp theo, LUÔN verify xong niche/
trang hiện tại bằng Playwright + kiểm tra bằng mắt, không để dở dang.

---
### (Lịch sử — cách chia Giai đoạn A/B/C/D cũ, KHÔNG CÒN ÁP DỤNG, giữ lại
### để tham khảo bối cảnh)

GIAI ĐOẠN A — Làm HEADER cho ĐỦ CẢ 20 niche trước (chưa làm section/nội
dung bên trong trang chủ):
1. Copy assets riêng (css + images) của TẤT CẢ 20 niche ngay bây giờ,
   không đợi tới lúc làm mới copy.
2. Với MỖI niche: đọc kỹ 2 khối `<header>` (fixed + thường), mobile
   offcanxas, breakpoint responsive (đo bằng Playwright nếu cần), cơ chế
   scroll (header-fixed hay header-sticky — xem mục 6 dưới), viết prompt
   riêng `.claude/prompts/<niche>-header.md`, chạy, verify bằng mắt +
   Playwright trước khi sang niche kế tiếp.
3. corporate đã xong Header + Footer — tiếp tục 19 niche còn lại theo
   thứ tự: agency, insurance, medical, spasalon (4 niche nhiều trang,
   ưu tiên trước) → rồi 15 niche còn lại (chỉ có index.html) theo thứ tự
   bất kỳ.

GIAI ĐOẠN B — Sau khi ĐỦ 20 header, quay lại làm Footer cho niche nào
chưa có (nếu bỏ qua ở giai đoạn A), rồi làm section/trang chủ (index.html)
từng niche, theo đúng Bước 3 ở mục 4 (làm theo nhóm section).

GIAI ĐOẠN C — Trang con của 5 niche nhiều trang (agency, corporate,
insurance, medical, spasalon), theo đúng Bước 4 ở mục 4.

GIAI ĐOẠN D — Trang landing (/landing) — hoàn thiện phần section-demos.