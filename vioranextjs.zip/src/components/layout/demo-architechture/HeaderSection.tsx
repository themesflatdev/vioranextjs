"use client";

import { useState, type ReactNode } from "react";
import { useHeaderFixed } from "@/hooks/useHeaderFixed";
import Header from "./Header";
import Footer from "./Footer";
import MobileNav from "./MobileNav";

export default function HeaderSection({ children }: { children: ReactNode }) {
  const isFixed = useHeaderFixed();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="niche-architechture">
      <Header fixed isFixed={isFixed} onOpenMobileNav={() => setMobileNavOpen(true)} />

      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Header onOpenMobileNav={() => setMobileNavOpen(true)} />
          {children}
          <Footer />
        </div>
      </div>

      <MobileNav open={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />
    </div>
  );
}
