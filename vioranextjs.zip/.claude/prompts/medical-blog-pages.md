Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc
(../viora/viora/demo-medical/bloggrid.html, bloglist.html, blogdetail.html). Đọc CSS/JS gốc lấy
đúng con số; không chắc thì dừng hỏi.

Làm 3 trang trong dropdown "Blog" của medical (route group (demo-medical)), THEO ĐÚNG THỨ TỰ,
xong trang nào báo cáo trang đó rồi mới sang trang tiếp:
  1) /demo-medical/bloggrid          (bloggrid.html)  — menu: "Blog Full Width"
  2) /demo-medical/bloglist          (bloglist.html)  — menu: "Blog With Sidebar"
  3) /demo-medical/blogdetail/[slug] (blogdetail.html) — menu: "Blog Detail" (route động)
(Tên file medical là "bloggrid/bloglist/blogdetail" KHÔNG có gạch nối — đã kiểm tra, là tên file
thật; giữ làm tên route.) KHÔNG làm Contact ở bước này.
YÊU CẦU CỨNG (2 điều, người dùng nhắc lại, KHÔNG được bỏ): (1) gắn link detail đầy đủ (menu desktop +
mobile, card, sidebar, prev/next) — mục "GẮN LINK" cuối prompt; (2) PHÂN TRANG HOẠT ĐỘNG THẬT ở cả
bloggrid và bloglist, giống blog của các demo khác — mục "PHÂN TRANG" ngay dưới. Làm và verify cả hai
TRƯỚC khi báo "xong".

## PHÂN TRANG — BẮT BUỘC (làm giống blog-full-width / blog-with-sidebar của corporate)
Mở code phân trang đã làm ở corporate (hook usePagination + component Pagination) và LÀM ĐỒNG NHẤT; không
tự phát minh cách khác. Thông số:
| Trang    | Bài/trang | Số trang | Tổng bài                | Markup phân trang                                  |
| bloggrid | 6         | 3        | 18 (6 gốc + 12 clone)   | ul.wg-pagination.style-2.justify-content-center    |
| bloglist | 3         | 3        | 9  (3 gốc + 6 clone)    | ul.wg-pagination.style-2 (KHÔNG justify-content-center) |
(Cùng một lớp CSS `wg-pagination` nhưng mỗi niche dùng style khác: corporate không style, insurance
style-1, medical style-2 -> component Pagination nhận prop className/variant, đừng nhân bản.)
Hành vi:
- Mỗi số trang là li > a href="#"; li.active = trang hiện tại; số li số = tổng số trang; li.arrow cuối
  (a > i.icon-CaretRight) = sang trang kế. Mọi click: preventDefault (không nhảy hash), đổi trang, rồi cuộn
  mượt lên đầu danh sách đúng như corporate đang làm (chưa có thì scrollIntoView đầu `.wrap-blog`).
- Mũi tên ở trang cuối: giống component của corporate; nếu corporate chưa có quy ước thì vô hiệu (không đổi
  trang, không báo lỗi).
- Dữ liệu clone: lặp lại đúng thứ tự bài gốc cho đủ số lượng (grid: bài 1-6 lặp 3 lần; list: 3 bài lặp 3
  lần), giữ nguyên ảnh/tag/tác giả/ngày; MỌI thẻ clone dùng LẠI slug của bài gốc (để bấm vào không 404);
  key React duy nhất (vd `${slug}-${index}`); ghi comment `// cloned for pagination demo`.
- Cấu trúc: trang vẫn là server component; chỉ phần "danh sách + phân trang" là client component dùng
  usePagination(items, pageSize). Sidebar của bloglist KHÔNG đổi khi đổi trang. Gắn
  `data-current-page={page}` lên `.wrap-blog` để Playwright kiểm thử.
- Nội dung ở trang 2-3 phải hiện NGAY (nếu vùng danh sách có phần tử `.wow`/reveal thì bảo đảm item mới mount
  không bị kẹt visibility:hidden do wow chỉ khởi tạo lúc vào trang).
- Chỉ phân trang ở bloggrid và bloglist; blogdetail không có.

## BƯỚC 0 — Chuẩn bị
- Dùng lại: PageHeaderBanner, BannerSection (variant "inner"), hook usePagination + component
  Pagination đã có từ corporate (nếu markup `wg-pagination style-2` khác bản đã có thì thêm
  variant, đừng viết lại), hook accordion/NiceSelect nếu cần, BlogSidebar (nếu đã có từ
  corporate/insurance CHỈ tái dùng khi markup giống hệt; sidebar medical có 5 khối — xem dưới).
- Dữ liệu bài viết: src/data/demo-medical/blogPosts.ts ĐÃ có 2 bài (trang chủ Insights) — MỞ RỘNG,
  đừng tạo file mới trùng. Danh sách bài "gốc" (canonical, 8 bài, theo thứ tự này, dùng cho
  generateStaticParams và prev/next):
   1 key-medicare-deadlines-you-shouldnt-miss-this-year   "Key Medicare Deadlines You Shouldn’t Miss This Year"
   2 top-signs-you-shouldnt-ignore-and-when-to-see-a-doctor "Top Signs You Shouldn't Ignore and When to See a Doctor"
   3 top-medicare-mistakes-you-should-avoid-before-enrolling "Top Medicare Mistakes You Should Avoid Before Enrolling"
   4 signs-you-may-need-to-change-your-medicare-coverage  "Signs You May Need to Change Your Medicare Coverage"
   5 medicare-options-you-should-compare-before-you-retire "Medicare Options You Should Compare Before You Retire"
   6 medicare-benefits-you-might-not-realize-you-can-claim "Medicare Benefits You Might Not Realize You Can Claim"
   7 hidden-medicare-costs-you-should-prepare-for-in-advance "Hidden Medicare Costs You Should Prepare For in Advance"
   8 nutrition-tips-recommended-by-our-medical-experts    "Nutrition Tips Recommended by Our Medical Experts"
  Mỗi trang dùng một mảng "hiển thị" riêng (ảnh/tag/tác giả/ngày/mô tả theo HTML của trang đó)
  tham chiếu tới slug ở trên. (Chữ "Medicare" xuất hiện nhiều trong tiêu đề — là chương trình bảo hiểm
  y tế, vẫn thuộc chủ đề sức khoẻ, GIỮ NGUYÊN.)
- QUY ƯỚC PHÂN TRANG: bản gốc chỉ có UI phân trang tĩnh (1 2 3 + mũi tên) với số bài ít. Theo quy ước
  dự án: làm phân trang THẬT bằng usePagination, clone dữ liệu để đủ 3 trang (ghi comment "cloned
  for pagination demo"). QUAN TRỌNG: bài clone dùng LẠI SLUG của bài gốc mà nó nhân bản (key React
  khác nhau) — để mọi thẻ đều dẫn tới trang detail hợp lệ, KHÔNG tạo slug mới (nếu không thẻ clone sẽ
  404). Prev/next của detail chỉ tính trên 8 bài gốc.

## TRANG 1 — /demo-medical/bloggrid
PageHeaderBanner: crumb/h2 gốc "blog grid"/"Blog Grid" -> "Blog Grid". main-content: `blog-post v2
tf-spacing-1 > tf-container > wrap-blog` gồm lưới `tf-grid-layout md-col-3` + phân trang; rồi banner
(inner). 6 `blog-item style-default v2 hover-image` (ảnh 445x334, `a.img-style.mb_23` chứa img +
`.tag.text-label`; `.content`: `ul.meta-post.mb_12.font-3` ["by <a href=#>Tác giả</a>", ngày],
`a.title.h5.mb_11.link.hover-line-text`). KHÔNG có đoạn mô tả. Dữ liệu 6 bài (đúng thứ tự gốc):
  1 blog-item-4.jpg  Culture & People  Mike Hanley       June 12, 2025  -> slug bài 1
  2 blog-item-5.jpg  Press Releases    Kelemen Krisztina May 08, 2025   -> slug bài 2
  3 blog-item-6.jpg  Case Studies      Kelemen Krisztina May 08, 2025   -> slug bài 3
  4 blog-item-7.jpg  Culture & People  Balla Daniella    May 06, 2025   -> slug bài 4
  5 blog-item-8.jpg  Press Releases    Kelemen Krisztina May 08, 2025   -> slug bài 5
  6 blog-item-9.jpg  Case Studies      Kelemen Krisztina May 08, 2025   -> slug bài 6
Phân trang: `ul.wg-pagination.style-2.justify-content-center` (số trang + li.arrow icon-CaretRight);
6 bài/trang, 3 trang (clone 12 bài). Tag "Culture & People/Press Releases/Case Studies" là danh mục
chung của theme, giữ nguyên.

## TRANG 2 — /demo-medical/bloglist
PageHeaderBanner: "blog list"/"Blog List" -> "Blog List". main-content: `blog-post-2 v2 tf-spacing-1
> tf-container > row`: col-lg-8 (`wrap-blog` + phân trang `ul.wg-pagination.style-2`) và col-lg-4
(sidebar); rồi banner (inner).
3 `blog-item style-2 v-list hover-image` (data-wow-delay ".1s"/".2s"/... đúng như gốc; ảnh 940x424
`a.img-style` + `.tag.text-label` "HEALTH care"; `.content`: meta-post mb_16 [by Kelemen Krisztina,
May 08, 2025], tiêu đề, đoạn mô tả, link "Read More"). Ảnh blog-item-1/2/3.jpg; tiêu đề: bài 1, bài 2,
bài 7 trong danh sách canonical. Link ảnh/tiêu đề/Read More -> /demo-medical/blogdetail/{slug}.
SỬA NỘI DUNG (gốc: cả 3 bài đều dùng chung 1 câu mô tả về BẤT ĐỘNG SẢN — "Mixed-use developments
are transforming once-overlooked districts into real estate hotbeds..." — chữ của niche khác lọt
vào; áp dụng quyết định đã thống nhất ở các niche trước: viết lại cho hợp bài, khác nhau từng bài):
  1 "Missing a Medicare enrollment deadline can mean late penalties and gaps in your coverage..."
  2 "Persistent pain, sudden fatigue or unexplained changes should never be ignored. Learn when to
     book a visit..."
  7 "Premiums are only part of the story. Deductibles, copays and gaps in coverage can add up quickly..."
Phân trang: 3 bài/trang, 3 trang (clone 6 bài).
SIDEBAR (đã đọc đủ, copy markup từ HTML): (a) sidebar-author: form tìm kiếm `form-search style-2
mb_30` (placeholder "Search products..." — sót chung của theme ở mọi niche, GIỮ NGUYÊN), author
"Tony Nguyen — Content writer at Viora" (avatar-1.jpg 80x80) + `tf-social style-2` 5 icon; (b)
sidebar-categories: Vitality Health Solutions (112), WellSpring Wellness Center (32), Harmony Family
Health Medical (42), Evergreen Medical Center (65), PureLife Health Services (13); (c)
sidebar-latest-post: 4 `latest-post v2 hover-image-rotate` (ảnh 120x120 latest-post-1..4.jpg, tác giả
"Zaire Culhane", June 12, 2025): "Signs You May Need to Change Your Medicare" -> bài 4,
"Medicare Options You Should Compare" -> bài 5, "Medicare Benefits You Might Not Realize" -> bài 6,
"Top Medicare Mistakes You Should Avoid" -> bài 3 (tiêu đề hiển thị giữ NGUYÊN bản rút gọn của
gốc, link tới slug bài đầy đủ tương ứng); (d) "Subscribe Newsletter": input "Email address" + nút
icon-PaperPlaneTilt; (e) sidebar-tags: Therapy, Wellness, Meditation, Clinics, Mental Health, Health.
Form tìm kiếm/newsletter: onSubmit preventDefault. Nội dung sidebar đúng chủ đề y tế, không cần sửa.

## TRANG 3 — /demo-medical/blogdetail/[slug]  (ROUTE ĐỘNG)
PageHeaderBanner: crumb "Blog Details", h2 gốc "blog details" (viết thường) -> "Blog Details".
main-content: `tf-container > row`: cột trái `col-md-2 md-hide` (ẩn ≤767px) chứa `ul.tf-social.style-2.
flex-column` 5 icon (messenger, x, instagram, skype, telegram, href "#") — copy markup; đọc CSS gốc xem
cột có sticky/cố định khi cuộn không rồi làm đúng, đừng đoán — + `col-xl-8 col-md-10 > .content-inner >
.post-detail`; rồi banner (inner). KHÔNG có sidebar. Quy ước các trang detail trước: HTML gốc chỉ có 1 bản nội dung
demo; thân bài DÙNG CHUNG cho 8 slug; theo slug là: h3 tiêu đề (= tiêu đề bài), Author và Post Date
trong meta (= tác giả/ngày của bài nếu HTML có: bài 1-6 từ trang grid, bài 7 từ trang list; bài 8
"Nutrition Tips..." KHÔNG có tác giả/ngày ở bất kỳ đâu trong HTML -> dùng giá trị tĩnh của bản demo
"Jordyn Culhane" / "May 18, 2025"); tag "HEALTH CARE" giữ tĩnh; mục meta "Comment: Full-Time" là sót
của theme ở mọi niche -> GIỮ NGUYÊN. generateStaticParams theo 8
slug; slug lạ -> notFound().
Cấu trúc theo THỨ TỰ trong HTML gốc (đọc lại file để lấy đúng thứ tự xen kẽ đoạn văn/h4, đừng suy từ
đây): `.thumb.mb_40` ảnh thumbs-main-blog.jpg 860x512 (img class rounded-16) -> `.heading-title.mb_40`
[tag "HEALTH CARE" (`tag text-button mb_17`, tĩnh), h3.title.text-capitalize.mb_16.font-main, `ul.meta`] ->
các đoạn mở đầu, h4 "Trusted Care Close to Home" + đoạn -> `.quote` (+ `.author`) -> `.thumbs.mb_40` ảnh
thumbs-blog.jpg 860x512 -> `.passive.mb_40` (h4 + 2 đoạn) -> `.tag-share` (tags-list style-2 + share) ->
`.tf-article-navigation` -> `.reply-comment.mb_40` (h4 "Customer Reviews", 3 `reply-comment-item`,
avatar-2/3/4.jpg 60x60, 5 sao) -> `.leave-comment` (`.heading-title` "Add A Review", "Your email address
will not be published", ô lưu tên/email) — form onSubmit preventDefault.
NỘI DUNG GỐC LÀ BẢN TRỘN (giống hệt portfolio-detail của medical): nửa trên y tế (GIỮ), nửa dưới là chữ
corporate/bất động sản lọt vào. Viết lại CHỈ phần sai (cùng quyết định đã áp dụng cho
portfolio-detail), GIỮ NGUYÊN ảnh, meta, đoạn mở đầu 1, khối "Trusted Care Close to Home", tên tác giả
quote, tên/ngày/avatar/sao của 3 review:
- Đoạn mở đầu 2 (gốc lặp và lủng củng): "Medical services are an essential part of our lives, offering
  care and treatment for various health conditions. These services encompass a wide range of
  specialties, including primary care, pediatrics and cardiology, each delivered by experienced
  doctors with a patient-centered approach."
- Quote (gốc "property management services..."): "\"The care my family received was beyond what we
  expected. Every doctor and nurse was attentive, patient and professional at every step of our
  journey.\"" — giữ tên "Cheyenne Mango"; chức danh (nếu có dòng chức danh) -> "Parent of Patient".
- Heading "Looking Inward To Grow Outward" -> "Care That Continues Beyond The Clinic"; đoạn 1: "Behind
  every successful recovery is a team that listens, plans and follows through — from the first
  consultation to the final check-up. Those quiet, consistent efforts are what allow us to deliver
  reliable care to every patient and family we serve."; đoạn 2: "At the end of the day, great healthcare
  isn’t built by chance. It’s built by design — one patient, one plan, one caring conversation at a
  time."
- Tags "CompanyCulture", "EnterpriseInsights" -> "HealthTips", "PatientCare".
- Prev/Next: gốc trỏ "single-post-1.html" (không tồn tại) với tiêu đề "Client Success Stories"/"Branded
  Impact". LÀM ĐỘNG THẬT theo vị trí slug trong 8 bài gốc: tiêu đề + link tới bài kế/trước; ẩn Previous
  ở bài đầu, ẩn Next ở bài cuối (giữ class ms-auto của Next).
- 3 review: "Great read! It's reassuring to see clear, honest information about your health options.
  Transparency like this builds real trust." / "Love how clearly you explained each step of the
  process. Many people find this confusing — thanks for sharing your approach!" / "Insightful post.
  Combining expert care with a personal touch is easier said than done — it's inspiring to see how you
  do it in practice."

## GẮN LINK DETAIL / BLOG — BẮT BUỘC
HTML gốc: link tới 3 trang blog nằm ở MENU (3 nơi: header cố định, header thường, offcanvas mobile), ở
2 bài Insights của trang chủ, ở các thẻ bài và sidebar. Footer KHÔNG có link blog. Sau khi có route,
SỬA TẤT CẢ, không còn href ".html" hay route không slug:
1. src/data/demo-medical/menu.ts, dropdown "Blog": "Blog Full Width" -> /demo-medical/bloggrid ; "Blog
   With Sidebar" -> /demo-medical/bloglist ; "Blog Detail" -> /demo-medical/blogdetail/
   key-medicare-deadlines-you-shouldnt-miss-this-year (slug bài ĐẦU TIÊN; KHÔNG để route không slug).
   Xác nhận cả 3 nơi render menu (desktop hover dropdown + mobile accordion) đọc cùng mảng; nơi nào
   hard-code thì sửa luôn.
2. Trang chủ: 2 bài Insights (ảnh + tiêu đề + btn-arrow) -> /demo-medical/blogdetail/
   {top-signs-... , nutrition-tips-...} (đã dặn ở bước trang chủ; kiểm tra lại thực tế đúng slug trong
   blogPosts.ts).
3. Trang grid/list: ảnh + tiêu đề (+ "Read More" ở list) của MỌI thẻ, kể cả thẻ clone -> /blogdetail/{slug}.
4. Sidebar "Latest Posts": 4 link -> đúng slug đã map ở trên. Trang detail: prev/next động; breadcrumb
   "HOME" -> /demo-medical.
5. Chạy quét link (scripts/viora-links.mjs nếu đã cài, hoặc Playwright tự viết) từ /demo-medical,
   /demo-medical/bloggrid, /demo-medical/bloglist, /demo-medical/blogdetail/<slug đầu> độ sâu 1-2: KHÔNG
   còn 404. Thử cả desktop (hover dropdown Blog) và mobile (≤1199px: mở offcanvas, accordion Blog, bấm
   từng mục) -> vào đúng trang.

## VERIFY
- So HTML gốc với Next ở 1440, 991, 575: số cột lưới grid (3/…), chiều cao block, ảnh, font, link không
  gạch chân; sidebar xếp dưới nội dung ở màn nhỏ đúng như gốc.
- PHÂN TRANG (bắt buộc kiểm bằng Playwright): bloggrid hiện 6 thẻ/trang, bloglist 3 thẻ/trang, đủ 3 trang;
  `data-current-page` và li.active đổi đúng khi bấm số 2, 3; bấm mũi tên tăng đúng 1 trang và dừng ở trang
  cuối; không có lỗi console; thẻ ở trang 2 và 3 bấm vào đều tới /blogdetail/{slug} hợp lệ (không 404);
  bố cục trang 2-3 giống trang 1 (cùng độ cao/cột). Phân trang thật ở grid và list: bấm số trang/mũi tên
  đổi bài đúng, trạng thái active đúng; cuộn lên đầu
  danh sách khi đổi trang (nếu hook đã có hành vi này ở corporate thì giữ đồng nhất).
- Detail: các slug khác nhau đổi h3/Author/Post Date đúng; prev/next đúng và ẩn đúng ở đầu/cuối; slug lạ
  -> 404; click mọi thẻ clone không 404.
- Chuyển qua lại /demo-medical ↔ /demo-agency bằng <Link>: màu không lẫn.
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: file tạo/sửa, từng chỗ đã gắn link (menu x3, trang chủ, card, sidebar, prev/next) kèm kết
quả quét link, nội dung đã viết lại (nguyên văn: 3 mô tả list, phần dưới blogdetail, 3 review), việc chưa xong.
