Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "agency" (route group (demo-agency)).
Chi tiết dưới đây đã XÁC MINH bằng đọc code gốc + đo Playwright.

## 1. Cấu trúc DOM (GSAP ScrollSmoother — giống corporate)

demo-agency/index.html dùng gsap.min.js + ScrollSmoother + ScrollTrigger +
SplitText (script tag xác nhận). 2 header "style-2 header-fixed" (ngoài
#smooth-wrapper) và "style-2" (trong #smooth-wrapper/#smooth-content) —
ĐÃ DIFF XÁC NHẬN nội dung giống hệt nhau (chỉ khác thụt lề). Dùng 1
component components/layout/demo-agency/Header.tsx, prop `fixed?: boolean`.

KHÔNG dùng chung component Header với corporate — 2 niche có style/thiết
kế khác nhau (đã xác nhận ở bảng khảo sát master-workflow.md: style-2 ≠
style-default).

## 2. KHÔNG có Splitting.js chạy thật (giống corporate — RÚT KINH NGHIỆM)

demo-agency/index.html KHÔNG include splitting.min.js (đã kiểm tra danh
sách script tag). Hiệu ứng hover đổi chữ ở menu CHỈ LÀ CSS opacity fade
đơn giản, KHÔNG có xoay 3D so le từng ký tự (giống kết luận cuối cùng đã
chốt ở corporate) — KHÔNG cài package splitting, KHÔNG viết code JS
Splitting cho phần này.

## 3. Breakpoint responsive (ĐÃ ĐO — giống hệt corporate)

Tại ≥992px: main-menu hiện, mobile-button ẩn. Tại ≤991px: ngược lại. Mốc
"lg" (991/992) — dùng CSS media query thuần.

## 4. Header scroll: dùng cơ chế `header-fixed` (ngưỡng 300px — ĐÃ ĐO)

Giống hệt corporate: scrollTop > 300 → thêm "is-fixed". Dùng lại hook
`useHeaderFixed` đã build ở corporate NẾU đặt ở vị trí dùng chung được
(src/hooks/useHeaderFixed.ts, không phụ thuộc gì riêng theo niche) — TÁI
DÙNG, không viết lại.

## 5. Header-right KHÔNG có nút CTA — dùng social icon list

Khác corporate (có nút "Get In Touch"), agency dùng: 4 icon mạng xã hội
(LinkedIn, X, Instagram, YouTube — class icon-Linkedin/icon-x-logo/
icon-instagram-logo/icon-Youtube, có class "sm-hide" ẩn ở màn nhỏ) rồi
mới tới mobile-button. KHÔNG thêm nút CTA nào không có trong HTML gốc.

## 6. Sửa lỗi nội dung đã phát hiện (không cần hỏi lại — chỉ có 1 cách sửa hợp lý)

- Link "Home AI Tech" trong mega-menu desktop VÀ trong mục Demos mobile
  đang bị lỗi gõ "../demo-aitech/index.html/index.html" (lặp index.html)
  → sửa thành đúng "/demo-aitech"
- Link "AI Content Writer" trong mobile Demos bị HỎNG CÚ PHÁP THẬT SỰ:
  `<a h..ref="/demo-aicontentwrindex.htmliter/">` (thuộc tính viết sai
  "h..ref", URL bị chèn nhầm "index.html" vào giữa) → sửa thành đúng
  `<a href="/demo-aicontentwriter">`

## 7. Menu (giữ nguyên, đã xác nhận đầy đủ — LƯU Ý KHÁC corporate ở mục Pages)

Desktop:
- Demos (mega-menu): ĐÚNG 12 demo, THỨ TỰ Y HỆT corporate (Corporate,
  Agency, Insurance, Medical, Restaurant, AI Tech, AI Content Writer,
  SaaS, Health Coach, Spa Salon, Lawyer, Charity) nhưng "Home Agency" trỏ
  "/demo-agency" và active tại chính trang này; "Home Corporate" trỏ
  "/". + nút "View all demos (20)".
- Pages (dropdown) — KHÁC corporate: About Us→/about, Our Team→/our-team,
  Team Detail→/team-detail, **Our Pricing→/our-pricing**,
  **Testimonials→/testimonials**, FAQs→/faqs (không có Carrer/Carrer
  Detail như corporate, vì agency không có 2 trang này — xem danh sách
  12 trang agency ở master-workflow.md mục 2).
- Services (dropdown): Services→/services, Services Detail→/service-detail
- Project (dropdown): Portfolio→/portfolio, Portfolio Detail→/portfolio-detail
- Contact→/contact

Mobile — ĐỦ 20 niche (đã sửa 2 lỗi ở mục 6), Pages/Services/Project dạng
accordion, KHÔNG có mục "Contact" trong accordion (Contact là link thẳng
cuối danh sách, giống desktop).

Phần "support" cuối mobile nav (Need help?, số điện thoại, email, social)
— LƯU Ý: icon social ở đây dùng class KHÁC với desktop (icon-XLogo-2,
icon-InsLogo-fill — thay vì icon-x-logo, icon-instagram-logo) — giữ
ĐÚNG NHƯ HTML GỐC, không tự đổi cho giống desktop (có thể là biến thể
icon filled/outline có chủ đích).

Tách data vào src/data/demo-agency/menu.ts, 2 mảng riêng
`desktopDemosFeatured` (12) và `mobileDemosFull` (20) như đã làm ở
corporate.

## 8. Modal "View all demos"

Có sẵn `#modalDemo` riêng trong trang này (không dùng chung DOM với
corporate vì đây là trang khác) — nội dung 12 demo giống hệt mega-menu
desktop. Tái dùng component DemoQuickModal đã build ở trang landing nếu
kiến trúc cho phép import xuyên route group, hoặc tạo bản
components/layout/demo-agency/DemoQuickModal.tsx nếu không tiện tái dùng
trực tiếp — quyết định dựa trên độ phức tạp thực tế lúc code.

## Sau khi xong — checklist verify

- ≥992px: main-menu hiện, hover Pages/Services/Project xổ đúng submenu
  (CSS hover thuần)
- ≤991px: main-menu ẩn, mobile-button hiện, offcanvas mở đúng, Demos xổ
  đủ 20 (2 link đã sửa lỗi phải trỏ đúng, không còn h..ref hỏng)
- Cuộn qua 300px: header ngoài nhận "is-fixed" đúng lúc
- Header-right hiện đúng 4 social icon, KHÔNG có nút CTA nào
- Hover chữ chỉ fade đơn giản, không có hiệu ứng xoay 3D (xác nhận không
  cài Splitting)
- Không còn phụ thuộc jQuery/Bootstrap JS