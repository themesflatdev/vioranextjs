Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng
con số, không áng chừng, không tự đơn giản hoá. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-aitech/index.html (route "/demo-aitech", route group (demo-aitech)).
Header/Footer ĐÃ CÓ SẴN (header style-6 header-sticky, mốc menu mobile xl 1199/1200; footer-style-5). Niche này CHỈ
có index.html, không có trang con. Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS), hero, rồi 8 block main-content
(ĐÃ ĐỌC ĐỦ), THEO 4 NHÓM; verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.

## ĐẶC ĐIỂM RIÊNG CỦA AITECH (khác mọi niche đã làm)
- KHÔNG dùng ScrollSmoother: DOM là `<div id="wrapper">` (không có #smooth-wrapper/#smooth-content) dù HTML gốc vẫn
  nạp file ScrollSmoother.min.js. Layout Next phải render `#wrapper` thường; HeaderSection/trang KHÔNG được gọi
  useScrollSmoother() (sẽ lỗi/giật vì không có wrapper). Vẫn gọi useWow(). ScrollTrigger dùng scroller mặc định (window).
- Cấu trúc: `#wrapper` > header, hero-banner-6 (NGOÀI main-content), `.main-content`, footer.
- Nền tối: AItech.css đặt `#wrapper { background-color: var(--Bg-dark) }` và `body { color: var(--White) }`.

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-aitech)/layout.tsx: wrapper `data-niche="aitech"` bao toàn bộ; bên trong là `#wrapper` (không có
   smooth-wrapper); HeaderSection của aitech KHÔNG gọi useScrollSmoother(); có useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE (đã phát hiện lỗi hệ thống — ĐỌC KỸ): demo-aitech/css/AItech.css (và 18 file
   CSS của các niche khác — tất cả trừ corporate; đã quét) KHÔNG chỉ có `:root` mà còn nhiều selector TOÀN CỤC: `body {color}`, `#wrapper {background}`,
   `h1,.h1…h6,.h6 {color; font-family; font-weight}`, `.font-main/.font-2/.font-3/.font-4`, `.navigation li>a`,
   `.main-menu …`, `.tf-btn …`. Next gộp CSS mọi niche vào 1 bundle nên các rule này RÒ sang mọi niche khác
   (vd mọi h1-h6 thành chữ trắng ở niche sáng). Bản fix-css-variable-scope.md trước đó chỉ đổi khối `:root`.
   Làm với src/styles/demo-aitech.scss: BỌC TOÀN BỘ nội dung trong `[data-niche="aitech"] { ... }` (SCSS nesting) với
   ánh xạ: `:root {…}` -> khai báo biến + thuộc tính trực tiếp trên `[data-niche="aitech"]` (dùng `&`); `body {color}` ->
   `color` trên chính `[data-niche="aitech"]`; `#wrapper {…}` -> `#wrapper {…}` lồng bên trong; mọi rule còn lại lồng
   nguyên văn (thêm tiền tố tự động). KHÔNG đổi giá trị/thứ tự. Sau đó so với HTML gốc: nếu có chỗ lệch do độ ưu
   tiên selector thay đổi (thêm 1 attribute selector), sửa riêng từng chỗ cho khớp bản gốc.
3. KIỂM TRA RÒ RỈ CHÉO (đo bằng Playwright, đừng đoán): mở lần lượt `/`, `/demo-agency`, `/demo-insurance`,
   `/demo-medical`, `/demo-restaurant`, `/demo-aitech` (cả vào trực tiếp lẫn điều hướng client-side bằng <Link> giữa
   chúng); với mỗi trang lấy computed color + font-family của 1 thẻ h2 trong main-content, color của body, background
   của wrapper, và so với trang HTML gốc tương ứng (server tĩnh ../viora/viora, cổng KHÔNG dùng 5060/5061).
   Nếu niche đã làm trước đó bị lệch (nghi do file demo-<niche>.scss của chúng còn selector toàn cục): báo cáo
   danh sách, rồi sửa CÙNG cách (bọc [data-niche]) cho đúng các file bị ảnh hưởng, đo lại, báo từng file. Không sửa
   file niche nào không bị lệch.
4. `ls src/hooks src/components/common` và tái dùng: useSplitTextReveal, useWow, useScrollTransform, useCountUp (không
   cần), useHeaderSticky, useInfiniteSlide, useAtropos (nếu restaurant đã làm), hook tab giá Monthly/Yearly, hook hover-tab,
   hook accordion 1-mục-mở + collapse transition, useSwiperControls (trang này KHÔNG có Swiper). Kiểm tra/bổ sung:
   a. useSplitTextReveal: đủ các chế độ dùng ở trang này — `effect-up` (from opacity 0, y 20), `effect-blur-fade`,
      `split-lines-transform` (tách lines, from opacity 0, yPercent 100, autoAlpha 0, stagger 0.2), `split-lines-rotation-x`
      (tách lines, from opacity 0, rotationX -120, transformOrigin "top center -50", stagger 0.2) và `split-words-scale`
      (MỚI, dùng cho tiêu đề hero): tách "words"; mỗi từ đặt trước opacity 0, scale = (chỉ số chẵn ? 0 : 2), force3D; rồi
      gsap.to(từ, {scrollTrigger như các chế độ khác, rotateX 0, scale 1, opacity 1, ease power3.out, stagger 0.05}).
      Mặc định: SplitText "words, chars", duration 0.9, stagger 0.02, ease power3.out; target là `p`/`a` con đầu tiên nếu có,
      không thì chính phần tử.
   b. HOOK MỚI `useRevealElements` cho thuộc tính `data-ns-animate` (13 chỗ trong trang; tên "Springer" trong HTML gốc
      KHÔNG cần: chỉ dùng khi có data-spring, trang này không có). Logic gốc (gsapAnimate.js initRevealElements): với
      mỗi phần tử có data-ns-animate: duration = parseFloat(data-duration) (mặc định 0.6); delay = parseFloat(data-delay)
      (chuỗi "0.2s" -> 0.2; rỗng -> 0); offset 60 (data-offset); start "top 90%" (data-start); end "top 50%"; direction
      mặc định "down"; đặt trước style opacity 1 + filter blur(0); gsap.from(elem, {opacity 0, filter "blur(16px)",
      duration, delay, ease "power2.out"} + vị trí: direction left -> x:-offset, right -> x:+offset, down -> y:+offset,
      up -> y:-offset; scrollTrigger {trigger elem, start, end, scrub:false}). Hỗ trợ data-instant (bỏ scrollTrigger),
      data-rotation, data-animation-type="to". Chạy lại khi vào trang/đổi route, dọn ScrollTrigger khi unmount.
   c. useWow có đọc data-wow-delay; class `rotateIn`, `zoomIn`, `fadeInUp/Left/Right` từ animate.css.
5. next/image bắt buộc width/height: ảnh trong HTML gốc KHÔNG khai báo kích thước (dùng kích thước thật của file):
   images/hero-1.png 907x981 | ../assets/images/shape/Lightning-2.png 20x21 | images/item-1.png 735x753. Các ảnh còn
   lại (project-1..7, banner-1/2, process-1..3, avatar) đã có width/height trong HTML, giữ nguyên.
6. Video hero: ../video/video-techai.mp4 (~28MB). Dùng /assets/video/video-techai.mp4 (copy từ ../viora/viora/video/ vào
   public/assets/video/ nếu chưa có). Thẻ video React: muted + autoPlay + loop + playsInline; do React không gắn
   thuộc tính `muted` đúng lúc render, đặt `el.muted = true` và gọi `el.play()` trong ref/useEffect để autoplay chạy.
7. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, KHÔNG chỉ kiểm tra; làm ngay ở bước này). Đã đọc HTML: niche này KHÔNG có
   trang con; trong header và offcanvas mobile `#menu-mobile`, MỌI mục ngoài "Demos" (Pages, Services, Project, Blog,
   Contact) đều trỏ sang trang CORPORATE (`../demo-corporate/*.html`; tập link đã so với restaurant: GIỐNG HỆT, header
   17 + mobile 18 link). Corporate chạy ở route GỐC (không tiền tố):
   | Nhãn menu                  | href trong HTML gốc                       | Route Next                      |
   | Home Corporate             | ../demo-corporate/index.html              | /                               |
   | Pages > About Us           | ../demo-corporate/about-us.html           | /about-us                       |
   | Pages > Our Team           | ../demo-corporate/our-team.html           | /our-team                       |
   | Pages > Team Detail        | ../demo-corporate/team-detail.html        | /team-detail/{slug}             |
   | Pages > Carrer             | ../demo-corporate/carrer.html             | /carrer                         |
   | Pages > Carrer Detail      | ../demo-corporate/carrer-detail.html      | /carrer-detail/{slug}           |
   | Pages > FAQs               | ../demo-corporate/FAQs.html (F hoa)       | /faqs                           |
   | Services > Services        | ../demo-corporate/services.html           | /services                       |
   | Services > Services Detail | ../demo-corporate/service-detail.html     | /service-detail/{slug}          |
   | Project > Porfolio         | ../demo-corporate/portfolio.html          | /portfolio                      |
   | Project > Portfolio Detail | ../demo-corporate/portfolio-detail.html   | /portfolio-detail/{slug}        |
   | Blog > Blog Full Width     | ../demo-corporate/blog-full-width.html    | /blog-full-width                |
   | Blog > Blog With Sidebar   | ../demo-corporate/blog-with-sidebar.html  | /blog-with-sidebar              |
   | Blog > Blog Detail         | ../demo-corporate/blog-detail.html        | /blog-detail/{slug}             |
   | Contact                    | ../demo-corporate/contact.html            | /contact                        |
   - {slug}: LẤY từ menu của corporate (src/data/demo-corporate/menu.ts đang dùng slug đầu tiên cho các mục "...Detail"),
     KHÔNG gõ tay/đoán. Route "...Detail" không slug sẽ 404.
   - "404 Error": làm ĐỒNG NHẤT với menu corporate (đã bỏ); nếu aitech đang có sẵn thì giữ nguyên trạng thái hiện tại.
   - Nhãn "Porfolio" là lỗi gõ -> "Portfolio" (nếu corporate vẫn ghi "Porfolio" thì sửa luôn ở corporate cho đồng nhất).
     Mục "Contact" cấp 1 có 2 thẻ <span> cùng chữ (hiệu ứng hover) là đúng markup gốc, không phải lỗi.
   - "Home AI Tech" trỏ chính nó (/demo-aitech); "Home <niche khác>" trỏ /demo-<niche>: niche CHƯA làm sẽ 404 cho tới
     khi làm tới — dự kiến, chỉ liệt kê, KHÔNG sửa.
   Cách làm: (a) đọc src/data/demo-corporate/menu.ts, src/data/demo-aitech/menu.ts, components/layout/demo-aitech/ (Header,
   MobileNav, HeaderSection); (b) in BẢNG TRƯỚC (nhãn | href hiện tại | route đích | khác không) — mục trỏ "#", route không
   tồn tại như /demo-aitech/about, Detail không slug, hay còn ".html" đều phải sửa; (c) sửa dữ liệu menu theo bảng, ưu tiên
   MỘT NGUỒN (import mảng của corporate nếu có export, không thì copy href kèm comment `// mirrors demo-corporate/menu.ts`);
   KHÔNG đổi cấu trúc menu corporate; giữ mega-menu Demos, class, hover, accordion mobile; (d) cả BA nơi render menu (header
   cố định/thường, offcanvas mobile) đọc cùng dữ liệu; dùng <Link>. KHÔNG tạo route /demo-aitech/about... KHÔNG sửa FOOTER
   (footer aitech có 6 link về corporate đã được làm/sửa ở đợt Footer trước).
8. Tên file dữ liệu: src/data/demo-aitech/features.ts, services.ts, process.ts, pricing.ts, testimonials.ts, faqs.ts.

## NHÓM 1 — HERO + FEATURES
### Hero `hero-banner-6` (NGOÀI main-content)
- `div.parallax-video.thumbs-video > video.video-inner` (muted autoplay loop playsinline) nguồn video-techai.mp4. ĐÃ
  XÁC MINH: trang này KHÔNG có `.parallax-container` nên JS gốc imageParallax KHÔNG chạy cho video này (class
  parallax-video chỉ là style) -> KHÔNG thêm parallax khi cuộn.
- `.content > .tf-container > .col-lg-7`: `div.title.fw-6.font-2.split-text.split-words-scale` "AI That Understands You"
  (là <div>, không phải h1); `form.form-newsletter.style-5` (action="#"): p.text_white.text-body-2.split-text.
  split-lines-transform "Our natural language models help your systems speak, listen, and learn just like humans."; rồi
  `div.position-relative.wow.fadeInUp.input-animate-container` chứa `fieldset.position-relative` > input[type=email]
  .input-field.animated-input placeholder=" " (MỘT DẤU CÁCH) data-placeholders="Enter your email" + `div.placeholder-wrapper`
  > span.placeholder-text.typing-animation + span.cursor; nút `button[name=submit][type=submit].tf-btn.btn-hover-animate-2.
  btn-bg-primary-3` > span.text-body-1.fw-6 "Try For Free". Cuối: `.trust.d-flex.align-items-center.gap_12.wow.fadeInUp`:
  `.group` 4 avatar 48x48 (group-avatar-3-1..4.jpg, wow fadeInLeft, delay 0.1/0.2/0.3/0.4s) + p "Trusted by 50k+ users".
  onSubmit preventDefault.
- PLACEHOLDER GÕ CHỮ (main.js animateInput) — PORT NGUYÊN VĂN, kể cả quirk, chỉ thêm dọn dẹp khi unmount: placeholders =
  data-placeholders tách bằng "|" (ở đây 1 chuỗi), interval = data-interval || 100ms; `typeIn()`: isTyping=true, đặt text
  = placeholders[i], class của span = "placeholder-text typing-animation typing-in", sau 2000ms isTyping=false;
  `typeOut()`: nếu isTyping thì thoát; đặt class "placeholder-text typing-animation typing-out"; sau 800ms: i=(i+1)%n rồi
  typeIn(); khởi động: typeIn() một lần rồi `setInterval(()=>{ if(!isTyping) typeOut(); }, interval)`. (Quirk gốc: trong 800ms
  typing-out, interval 100ms có thể gọi typeOut lặp lại nhiều lần — GIỮ NGUYÊN, đừng "sửa cho gọn" để hành vi giống hệt.)
  CSS .typing-in/.typing-out/.cursor/ẩn placeholder khi input có chữ đều đã có trong SCSS gốc, chỉ cần đúng class và
  markup (span placeholder-wrapper phải là PHẦN TỬ KỀ SAU input trong fieldset). Component TypingPlaceholderInput
  (client), clearInterval/clearTimeout khi unmount.
- Ảnh trang trí: `div.item.position-absolute.wow.fadeInRight.slide-ttb-animated` > img images/hero-1.png (907x981).
  `slide-ttb-animated` là CSS THUẦN (_animation.scss: `animation: slide-to-slide 10s linear infinite`, biến
  --pxl-translate-y: 70px) -> chỉ cần đúng class.
### `section-feature tf-spacing-10`
- heading-section style-default d-grid gap_14 text-center mb_60: sub "Our Features" (text-label text_primary-color
  split-text effect-up text-uppercase lh-20 fw-4), h2.title.split-text.effect-blur-fade "Key Features", p.text-body-2.
  split-text.split-lines-transform "From automation to deep learning discover how our AI transforms your business."
- 2 hàng `row-feature d-flex gap_20` (hàng 1 có mb_20): mỗi `project-item style-1 hover-image` có `data-ns-animate
  data-duration="1"` (+ data-delay): hàng 1: "Smart Automation" ("Automate tasks with speed and precision.", project-1.png
  675x443, delay rỗng) và "Intelligent Suggestions" ("Personalized recommendations powered by AI.", project-2.png 675x443,
  delay 0.2s); hàng 2: "Real-Time Insights" ("Instant insights to drive decisions.", project-3.png 443x443, delay rỗng) và
  "Scalable System" ("Grows with your business, from startup to enterprise.", project-4.png 907x443, delay 0.2s). Cấu trúc:
  a.img-style.mb_32 (href "#") > img loading lazy + `.content` > a.title.link.h4.font-3.mb_8.line-clamp-1 + p.text-body-2.
  SỬA lỗi class: item "Scalable System" gốc ghi `hover-imagen` (lỗi gõ, mất hiệu ứng hover của riêng item này) ->
  `hover-image` như 3 item còn lại (ghi vào báo cáo).

## NHÓM 2 — BANNER 2 + SERVICES + PROCESS
### `section-banner-2`
`div.d-flex.gap_20` với 2 `.banner-item` (data-ns-animate data-direction="left"/"right" data-duration="1"
data-delay="0.2s"): mỗi cái `.img-style` (img 890x890 banner-1.png / banner-2.png) + `.content`.
 - Item 1: a.h2.link.fw-5.wow.fadeInUp "Experience The Power Of Real AI"; p.text-body-2.mb_28.wow.fadeInUp "Try our interactive
   demo and see how AI can simplify your workflow in seconds."; a.tf-btn.btn-hover-animate-2.btn-bg-white.wow.fadeInUp
   > span "Demo Now" + <span></span>.
 - Item 2: a.tf-btn.btn-hover-animate-2.btn-bg-white.wow.fadeInUp > span "Setches 3D" -> SỬA lỗi gõ thành "Sketches 3D"
   (+ <span></span>); a.h2.link.fw-5.mb_40.wow.fadeInUp "Start your journey with intelligent automation tailored to your
   business goals."; a.link.text_primary-color.hover-underline-link.text-button.wow.fadeInUp "Demo Now". Mọi href "#".
### `section-service-6 tf-spacing-10`
- `.wrap-heading > heading-section d-flex align-items-center justify-content-between gap_16 flex-wrap mb_60`: bên trái
  d-grid gap_16: sub "Our Services" (split-text effect-up), h2.split-text.effect-blur-fade "Our Core Services", p
  split-lines-transform "Delivering AI solutions that make a real difference."; bên phải `.box-right.wow.fadeInRight`:
  `.trust.d-flex.align-items-center.gap_12.mb_32` (4 avatar như hero + "Trusted by 50k+ users") + a.tf-btn.
  btn-hover-animate-2.btn-bg-primary-3.w-full "Get in Touch" (+ <span></span>), href "#".
- `tf-grid-layout md-col-3`: 3 `project-item style-1 hover-image` (data-ns-animate duration 1; delay rỗng/0.2s/0.3s), ảnh
  443x443 project-5/6/7.png, a.img-style.mb_40; tiêu đề a.title.link.h4.font-3.mb_8 + p.text-body-default: "Custom AI
  Solutions" ("We design and deploy AI models tailored to your business needs."), "Automation Integration" ("Connect AI with
  your tools to streamline complex workflows."), "Data-Driven Insights" ("Transform raw data into clear, actionable intelligence.").
### `section-process-2` (không có tf-spacing)
- `.tf-container > .wrap > .row.tabs-hover-wrap.tab-effect-blur.align-items-center`: col-lg-6: heading-section style-default
  d-grid gap_12 mb_48 [sub "Our Process" (text-label-2 lh-20 text_primary-color text-uppercase), h2.split-text.effect-blur-fade
  "How It Works", p.split-lines-transform "We guide you through every phase of AI transformation with clarity, strategy, and
  hands-on support from start to finish."] + `.box` 3 `.box-process.item.wow.fadeInLeft` (data-tab tab1/tab2/tab3): h3.number.
  font-main > span "01"/"02"/"03", `.content`: h5.mb_8 "Discover Needs" / "Build & Integrate" / "Deploy & Optimize" + p.
  text-body-default.line-clamp-2 "We analyze your goals and identify the best AI opportunities." / "Our team develops and
  connects custom AI into your systems." / "We launch, monitor, and refine your AI for real-world results.".
  col-lg-6: `.tab-content-wrap` 3 `.tab-content#tab1..3`, mỗi cái là `.atropos.my-atropos` > ... > `.atropos-inner` > `.img-style.
  text-center` > img process-1/2/3.png 595x595.
- HOVER TAB (main.js hoverTabs) — làm đúng: mỗi `.item` có data-tab; mouseenter -> sau 100ms (huỷ nếu mouseleave trước đó) nếu item
  chưa active thì bỏ active ở mọi item và mọi `.tab-content`, thêm active cho item đó và `#tabN` tương ứng; mouseleave khỏi
  CẢ wrapper (`.tabs-hover-wrap`) -> bỏ active mọi item/tab-content rồi chỉ thêm active cho `.tab-content` ĐẦU TIÊN
  (KHÔNG item nào active). Lúc khởi tạo: không item nào active, tab-content đầu active. Hiệu ứng chuyển ảnh `tab-effect-blur`
  là CSS theo class active (đã có trong SCSS). Nếu agency đã có hook hover-tab giống hệt thì tái dùng.
- ATROPOS: 3 phần tử `.my-atropos` (kể cả ảnh đang ẩn): `Atropos({ el, shadow: true, highlight: true })` (nếu chưa có hook
  useAtropos thì tạo; `npm i atropos@2.0.2` + thêm src/styles/vendor/atropos.scss từ assets/css/atropos.min.css vào chuỗi
  vendor như các thư viện khác); destroy khi unmount.

## NHÓM 3 — PRICING + TESTIMONIAL
### `section-pricing-2 flat-animate-tab tf-spacing-10 pricing-container`
- SỬA NỘI DUNG (HTML gốc dùng NHẦM heading của khối blog + câu của niche AI Content Writer cho phần giá; mặc định áp dụng
  cách xử lý đã dùng ở các niche trước: viết lại cho hợp niche — nếu người dùng muốn giữ nguyên thì dùng nguyên văn
  cột "gốc"). Heading-section d-grid gap_16 text-center mb_48:
  sub  gốc "News & Insights"                 -> "Our Pricing"
  h2   gốc "Latest News & Insights"           -> "Simple, Transparent Pricing"
  p    gốc "Say goodbye to writer’s block. Generate blog posts, product descriptions, social media captions, and more"
       -> "Choose the plan that fits your needs — upgrade anytime as you grow."
  (giữ nguyên class: sub split-text effect-up, h2 split-text effect-blur-fade, p split-text split-lines-transform).
- `.tab-slide.style-5.d-flex.justify-content-center.mb_48 > ul.menu-tab` (data-ns-animate data-duration="1") có
  `<li class="item-slide-effect">` + 2 tab: nhãn gốc "Standard Plan" (active, data-pricing="monthly") và "Premium Plan"
  (data-pricing="year") — thực chất là công tắc Monthly/Yearly (KHÔNG có tab-pane, 2 gói luôn hiện cạnh nhau) nên nhãn bị
  gắn nhầm -> SỬA thành "Monthly" và "Yearly" (giữ id #standard-plan/#premium-plan nếu cần, data-pricing như gốc).
- `.tab-content > .row > 2 × .col-md-6 > .pricing-item.style-2` (data-ns-animate duration 1; gói 2 delay 0.2s):
  Gói 1 "Standard Plan" có tag `.tag.d-inline-flex.align-items-center.gap_4.text-button-small.text_white` ảnh
  ../assets/images/shape/Lightning-2.png (20x21) + "Best Value"; giá data-monthly=29 data-yearly=69; 4 tính năng: "Includes
  initial consultation", "up to 15 hours of consulting", "Weekly check-ins", "Email & Phone support".
  Gói 2 "Premium Plan" (không tag): 59 / 99; "Includes initial consultation", "up to 15 hours of consulting", "Weekly
  check-ins", "24/7 support". Nút `tf-btn btn-hover-animate-border style-border w-full` "Choose Your Plan" (+ <span></span>), href
  "#". Cấu trúc giá: h2.price.text_white.mb_26.price-value > "$" + span.wrap-price > span > (span.price-month + span.price-year)
  + span.price-period "/ month". (Nội dung gói — consulting giờ/tuần — hợp niche, giữ nguyên.)
- CƠ CHẾ (đã đọc main.js — làm đúng): (a) initSwitchPriceValue trong `.pricing-container`: mỗi `.price-value` điền text cho
  .price-month (= data-monthly) và .price-year (= data-yearly); tab "monthly" -> .price-month có class active, .price-year
  bỏ active, `.price-period` = "/ month"; tab khác (data-pricing="year") -> ngược lại và "/ year"; mặc định "monthly" (29/59);
  (b) tabSlide: `.item-slide-effect` width = outerWidth của li.active, translateX(left của li) khi click, resize và lúc khởi tạo
  (transition 0.5s trong SCSS). Tái dùng hook đã làm ở corporate/medical nếu có.
### `section-testimonial-5` (không có tf-spacing)
- `.tf-container > .wrap > .row`: col-lg-6 heading-section d-grid gap_12 [sub "Testimonial" (text-label-2 …
  split-text effect-up), h3.title.split-text.effect-blur-fade "What Our Clients Say", p.split-lines-transform "Trusted by
  innovators, startups, and enterprises transforming with AI."]; col-lg-6 `.wrap-testimonial > .infiniteslide`
  data-clone="2" data-style="up" chứa 4 `.testimonial-item.style-4` (p.h5.fw-5.font-main.mb_12 + `.author.d-flex.gap_12` avatar
  48x48 avatar-6/7/8/9.jpg + a.text-button.d-block.link tên + span.text-caption-1 chức danh): (1) "Their AI integration cut our
  manual workload by over 50%. It felt like adding a superpower to our team" — Aisha Malik, CEO at FlowEdge; (2) "AI has never
  felt this seamless. We plugged it in, and things just started working smarter." — Tony Nguyen, Head of Operations at Avitex;
  (3) "As a growing tech company, we needed more than just hype — we needed AI that delivers measurable impact. Their team took
  the time to understand our systems, trained a custom model, and integrated it without interrupting our workflow. In under two
  months, we reduced operational costs and improved customer satisfaction scores by 23%. Truly transformational" — Aisha
  Malik, CEO at FlowEdge (trùng tên với (1), avatar khác — lỗi demo, giữ nguyên); (4) "Before working with this team, we
  struggled to turn our data into action. Within weeks, they deployed a model that gave us real-time insights and automated
  reports that used to take hours." — Sarah Nguyen, Product Manager at NexaTech. Nội dung đúng niche.
- MARQUEE DỌC `data-style="up"`: main.js gọi `.infiniteslide({speed: data-speed||50, direction: "up", clone: 2})` (plugin
  infinityslide.js). Cơ chế direction up: cha `.infiniteslide_wrap` overflow hidden; phần tử là flex column nowrap, children
  flex:none block; nhân bản `clone` lần; chiều cao num = tổng chiều cao 1 bộ item gốc; đặt chiều cao wrap = num;
  keyframes `from translate3d(0,0,0) to translate3d(0,-{num}px,0)`; thời lượng = num/speed GIÂY (speed 50 px/s), `linear
  infinite`; pause khi mouseenter, chạy lại khi mouseleave; tính lại khi resize. Kiểm tra useInfiniteSlide đã hỗ trợ
  hướng "up" chưa; chưa thì mở rộng đúng như trên (đọc assets/js/infinityslide.js). Khung hiển thị giới hạn chiều cao +
  lớp mờ `&::after` gradient đã có trong SCSS (.section-testimonial-5 .wrap-testimonial).
- Trang trí: `div.item.scroll-transform.lg-hide` data-direction="left" > img images/item-1.png (735x753), là con của `.wrap`.

## NHÓM 4 — FAQS + CTA
### `section-faqs-2 tf-spacing-10`
- heading-section d-grid gap_12 text-center mb_60: sub "FAQs" (text-label lh-20 text_primary-color text-uppercase mb_8),
  h2.split-text.effect-blur-fade "Frequently Asked Questions", p.text-body-2.split-text.split-lines-transform: gốc "Subscribe to
  get the latest company news, expert insights, and industry trends delivered straight to your inbox — no spam, just value."
  (câu của khối newsletter đặt nhầm làm mô tả FAQ) -> SỬA thành "Everything you need to know before getting started with our AI
  solutions."
- `.row.justify-content-center > .col-lg-10 > ul.accordion-wrap.d-grid.gap_16#accordion-faq` (data-ns-animate
  data-direction="left" data-duration="1") gồm 5 `li.accordion-item.action_click.style-3` (câu 1 có thêm `active`): a.accordion-title.action >
  .heading > h5.title.text-capitalize (chữ "Q1: …" nằm TRONG tiêu đề) + span.icon; panel `.collapse` (câu 1 `.collapse.show`)
  > .accordion-faqs-content > p.text-body-default.text_white. Câu hỏi: "Q1: What types of businesses can benefit from your AI
  solutions?" / "Q2: Do I need technical expertise to use your AI tools?" / "Q3: How long does it take to implement a custom
  AI solution?" / "Q4: Is my business data secure with you?" / "Q5: Do you offer post-launch support and maintenance?". CẢ 5 câu
  trả lời gốc GIỐNG HỆT NHAU ("Simply fill out our online form or contact us directly — we’ll send you a personalized quote
  within 24 hours.") — lỗi demo, GIỮ NGUYÊN (đã áp dụng như FAQ của insurance).
- Hành vi gốc: accordionActive (main.js): click `.action` -> bỏ `active` ở các `.action_click` khác, toggle `active` trên li chứa nó,
  chặn click trong 500ms sau mỗi lần (isProcessing); Bootstrap collapse với data-bs-parent => CHỈ 1 MỤC MỞ. Dùng hook accordion
  1-mục-mở + collapse transition chuẩn của dự án, đồng thời toggle class `active` trên li (SCSS dùng .active cho icon) và giữ
  debounce 500ms.
### `section-cta-2 tf-spacing-10 pt-0`
- `.tf-container > .content-inner > .row.align-items-center`: col-lg-6 `.heading`: h2.mb_16.title.text_primary.text-capitalize.
  split-text.split-lines-rotation-x "Let’s build something intelligent together." + `.trust.d-flex.align-items-center.gap_12.
  wow.fadeInUp` (4 avatar + p.text_primary "Trusted by 50k+ users"); col-lg-6 `.content`: p.text-body-2.mb_32.text_primary.
  split-text.split-lines-transform: gốc "Say goodbye to writer’s block. Generate blog posts, product descriptions, social media
  captions, and more" (câu của niche AI Content Writer, lặp lại đúng câu đã dùng nhầm ở Pricing) -> SỬA thành "Tell us about
  your goals and we’ll design, train, and deploy the right AI solution for your business."; nút a.tf-btn.btn-hover-animate-2.
  btn-bg-primary-3.btn-bg-dark.w-full.wow.fadeInUp "Get Started" (+ <span></span>), href "#".

## VERIFY (Playwright; mở HTML gốc qua server tĩnh và Next ở cùng độ rộng; nếu đã cài scripts/viora-check.mjs và viora-links.mjs
## thì dùng; KHÔNG dùng Claude in Chrome)
- Test ở 1919, 1440, 1199, 1025, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font, link không gạch chân, nền tối
  (computed background của #wrapper và màu chữ body khớp bản gốc), không ảnh lỗi/404, KHÔNG có #smooth-wrapper.
- Rò rỉ CSS (Bước 0.3): đã đo và báo cáo các niche khác không bị đổi màu/font so với HTML gốc, cả khi điều hướng client-side
  /demo-aitech ↔ / ↔ /demo-agency.
- Hero: video chạy (paused=false, muted, loop), KHÔNG parallax khi cuộn; tiêu đề chạy split-words-scale; placeholder gõ chữ lặp
  đúng nhịp (ghi lại các lần đổi class typing-in/typing-out trong ~8 giây ở bản gốc và bản Next, so thời điểm); khi nhập chữ vào ô
  email thì placeholder ẩn như gốc; ảnh hero-1 trôi theo slide-ttb-animated.
- data-ns-animate: trước khi cuộn tới, phần tử mờ + blur(16px) + lệch 60px; cuộn qua mốc "top 90%" thì chạy 1 lần với đúng
  duration/delay (feature delay 0/0.2s, banner x:±60 theo direction left/right...).
- Hover-tab process: mặc định không item nào active, ảnh 1 hiện; rê vào item 2 -> sau ~100ms đổi sang ảnh 2; rời khỏi cả khối
  -> quay lại ảnh 1 và bỏ active; Atropos 3 ảnh có .atropos-shadow/.atropos-highlight và nghiêng theo chuột.
- Pricing: nhãn "Monthly"/"Yearly"; mặc định 29/59 "/ month"; bấm Yearly -> 69/99 "/ year"; thanh trượt tab đúng vị trí, 0.5s.
- Marquee dọc: chạy lên, thời lượng = chiều cao 1 bộ item / 50 giây, dừng khi hover, không giật khi resize.
- FAQ: câu 1 mở sẵn, chỉ 1 mục mở, có transition, click liên tiếp <500ms bị bỏ qua.
- Menu: quét link từ /demo-aitech (desktop hover dropdown + mobile ≤1199px offcanvas, accordion, bấm từng mục): MỌI link Pages /
  Services / Project / Blog / Contact -> 200 và vào đúng trang corporate; liệt kê riêng 404 chỉ do niche chưa làm; không còn ".html".
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả Bước 0.3 (file CSS đã bọc [data-niche], niche nào từng bị rò và đã sửa);
hook/component mới (useRevealElements, split-words-scale, TypingPlaceholderInput, hỗ trợ infiniteslide "up", useAtropos...);
thư viện cài thêm (atropos@2.0.2 nếu chưa có); nội dung đã sửa (pricing heading + nhãn Monthly/Yearly, FAQ intro, CTA, 2 lỗi gõ,
class hover-imagen); kết quả đo từng điểm trên; việc chưa xong.