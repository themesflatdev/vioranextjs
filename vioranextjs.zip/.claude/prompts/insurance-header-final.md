Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "insurance" (route group (demo-insurance),
route "/demo-insurance"). Chi tiết dưới đây đã XÁC MINH bằng đọc trực tiếp
demo-insurance/index.html (không suy đoán).

## 1. Cấu trúc DOM (GSAP ScrollSmoother — giống corporate/agency)

demo-insurance/index.html dùng gsap.min.js + ScrollSmoother + ScrollTrigger +
SplitText (script tag xác nhận, KHÔNG có splitting.min.js — giống mọi niche
khác, chỉ CSS opacity fade khi hover chữ, KHÔNG cài package splitting).

2 header "style-3 header-fixed" (ngoài #smooth-wrapper) và "style-3" (trong
#smooth-wrapper/#smooth-content) — ĐÃ DIFF: nội dung giống hệt nhau, CHỈ 1
khác biệt thật sự: bản fixed có `<div class="header-inner px-0">`, bản
thường là `<div class="header-inner">` (không có "px-0") — giữ đúng khác
biệt này qua prop `fixed`.

KHÁC corporate/agency: `<header>` KHÔNG có `<div class="tf-container">` bọc
ngoài `header-inner` (style-3 tự set max-width/margin auto qua CSS, không
cần container). Component components/layout/demo-insurance/Header.tsx nhận
prop `fixed?: boolean`.

## 2. Breakpoint responsive — KHÁC corporate/agency: mốc "xl" (1199/1200)

ĐÃ XÁC NHẬN qua class thật trong HTML: `nav class="main-menu xl-hide"` và
`mobile-button d-xl-none` (không phải d-lg-none). `.xl-hide` là utility có
sẵn trong _reset.scss (`@include res(xl) { display:none !important }`) —
tự động ẩn main-menu ở ≤1199px nhờ CSS đã copy sẵn, KHÔNG cần JS đo
viewport. Nút CTA "Get Your Consult!" có class riêng `lg-hide` (ẩn ở
≤991px) — ẨN SỚM HƠN main-menu, y hệt cơ chế "Get In Touch ẩn ở md" của
corporate nhưng mốc khác (lg thay vì md) — giữ đúng class, không tự đổi.

## 3. Header scroll: `header-fixed` (ngưỡng 300px) — TÁI DÙNG hook có sẵn

Class "header-fixed" xác nhận trong HTML → dùng lại `useHeaderFixed`
(src/hooks/useHeaderFixed.ts) y hệt corporate/agency, không viết lại.

## 4. Header-right — có header-contact (SMS/phone box), KHÁC corporate/agency

Thứ tự trong `.header-right`:
1. `.header-contact.sm-hide` — icon `icon-PhoneCall` + text "Have any
   Question?" (class `font-3`) + số điện thoại "1-555-678-8888" (class
   `font-3`) — ẨN ở ≤575px (sm-hide), HIỆN ở mọi breakpoint lớn hơn kể cả
   mobile view (≤1199px vẫn hiện, chỉ ẩn ở sm).
2. Nút CTA `<a class="tf-btn btn-hover-animate-2 style-border-2 lg-hide">
   Get Your Consult!</a>` (không phải "Get In Touch") — ẨN ở ≤991px.
3. `.mobile-button.d-xl-none`.

## 5. Sửa lỗi nội dung đã phát hiện (không cần hỏi lại — chỉ 1 cách sửa hợp lý)

Mobile offcanvas, nhóm Blog: mục "Blog List" đang trỏ NHẦM vào
`blog-grid.html` (trùng với mục "Blog Grid" ngay phía trên) — trong khi
desktop submenu Blog list đúng 3 link riêng biệt (blog-grid.html,
blog-list.html, blog-detail.html). → sửa mobile "Blog List" thành đúng
`/demo-insurance/blog-list`.

## 6. Menu (giữ nguyên nội dung, đã xác nhận đầy đủ)

Desktop:
- Demos (mega-menu, class `submenu mega-menu menu-rounded` — bo góc nhiều
  hơn so với corporate/agency, giữ class "menu-rounded"): ĐÚNG 12 demo,
  THỨ TỰ y hệt corporate/agency (Corporate, Agency, Insurance, Medical,
  Restaurant, AI Tech, AI Content Writer, SaaS, Health Coach, Spa Salon,
  Lawyer, Charity). "Home Insurance" trỏ "/demo-insurance" (active tại
  trang này), "Home Corporate" trỏ "/". Không có bug link nào ở desktop
  (khác agency). + nút "View all demos (20)".
- Pages (dropdown): About Us→/about-us, Our Team→/our-team, Team
  Detail→/team-detail, Testimonials→/testimonials, Pricing→/pricing,
  FAQs→/faqs. BỎ mục "404 Error" (trỏ chéo sang
  ../demo-corporate/404.html trong HTML gốc) — Next.js dùng not-found.tsx
  tự động, giống quyết định đã áp dụng ở corporate.
- Services (dropdown): Services→/services, Services Detail→/service-detail
- Project (dropdown): Porfolio→/porfolio (giữ đúng lỗi chính tả gốc theo
  master-workflow mục 2), Portfolio Detail→/porfolio-detail
- Blog (dropdown): Blog Grid→/blog-grid, Blog List→/blog-list, Blog
  Detail→/blog-detail
- Contact→/contact

Mobile — ĐỦ 20 niche, thứ tự y hệt corporate/agency (Corporate, Agency,
Insurance, Medical, Restaurant, AI Tech, AI Content Writer, SaaS, Health
Coach, Spa Salon, Construction, Coworking Space, Garden Landscaping, Car
Service, Charity, Architechture, Logistics, Solar Energy, Agriculture
farming, Lawyer). 5 nhóm accordion: Demos/Pages/Services/Project/Blog
(CÓ Blog, khác agency không có Blog) — Contact là link thẳng cuối danh
sách, không nằm trong accordion.

Phần "support" cuối mobile nav — icon social dùng icon-XLogo-2/
icon-InsLogo-fill (giống corporate/agency mobile, khác desktop
header-right của insurance không có social icon nào — insurance desktop
dùng header-contact thay vì social).

Tách data vào src/data/demo-insurance/menu.ts, 2 mảng riêng
`desktopDemosFeatured` (12) và `mobileDemosFull` (20), TẤT CẢ link nội bộ
niche phải có tiền tố `/demo-insurance/...` (route root niche này là
"/demo-insurance", không phải "/").

## 7. Modal "View all demos"

Có `#modalDemo` riêng trong trang này. Dùng lại giải pháp đã áp dụng ở
corporate/agency: link đơn giản "/landing#demos" (landing chưa có
DemoQuickModal thật để tái dùng).

## Sau khi xong — checklist verify

- ≥1200px: main-menu hiện, mobile-button ẩn; 992–1199px: main-menu ẩn,
  mobile-button hiện, CTA "Get Your Consult!" vẫn hiện; ≤991px: CTA cũng
  ẩn theo (đo cả 3 vùng bằng Playwright, không chỉ 1 kích thước)
- header-contact (icon phone + số điện thoại) ẩn ở ≤575px, hiện ở mọi nơi
  khác
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover thuần)
- Cuộn qua 300px: header ngoài nhận "is-fixed" đúng lúc (test với nội dung
  đủ cao để có thể cuộn thật, tránh lặp lại nhầm lẫn đã gặp ở agency)
- Mobile: Demos đủ 20, Blog List đã trỏ đúng /demo-insurance/blog-list
  (không còn trùng Blog Grid)
- Hover chữ chỉ fade đơn giản, không xoay 3D (không có .char)
- Không còn phụ thuộc jQuery/Bootstrap JS
