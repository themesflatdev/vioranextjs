Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

CHỈ làm 2 trang trong dropdown "Project" của agency (KHÔNG làm Contact ở
bước này — để sau), báo cáo xong trang nào rồi mới sang trang tiếp theo:

=====================================================================
TRANG 1 — /demo-agency/portfolio (portfolio.html)
=====================================================================

section-portfolio-5 v2: 6 portfolio-item bố cục masonry (hàng 1: 4/8
cột, hàng 2: 8/4, hàng 3: 8/4), MỖI ITEM CÓ CUSTOM CURSOR "View" — TÁI
DÙNG THẲNG cơ chế đã build ở Our Project (Home Agency), KHÔNG viết lại.

Data 6 item, tách vào src/data/demo-agency/portfolio.ts (title, category,
image, slug — sinh slug từ title):
1. (đọc lại 2 item đầu trong HTML gốc — đã đọc được 4 item cuối, tự đọc
   lại 2 item đầu còn thiếu)
2. ...
3. ...
4. E-Commerce — Web Design
5. Montreal Canada — UI/UX Design
6. Portfolio Freelancer — Develop

TẤT CẢ hiện đang link tĩnh "portfolio-detail.html" → đổi thành
"/portfolio-detail/${slug}".

Cuối trang: section-contact-3 (dựng cấu trúc, CHƯA sửa nội dung — để
prompt riêng /contact sau).

=====================================================================
TRANG 2 — /demo-agency/portfolio-detail/[slug] (portfolio-detail.html) — ROUTE ĐỘNG + VIẾT LẠI NỘI DUNG
=====================================================================

ĐÃ XÁC NHẬN với người dùng: nội dung gốc thực chất là 1 bài blog về văn
hoá công ty (có meta Author/Post Date/Comment, nói về "People First",
"Optimizing Process") — KHÔNG phải case-study dự án thật. VIẾT LẠI toàn
bộ thân bài thành case-study portfolio, giữ nguyên SỐ LƯỢNG block/cấu
trúc kỹ thuật (1 đoạn intro, 2 khối "passive" có heading h4 + đoạn văn +
danh sách, ảnh thumb ở giữa), chỉ đổi NỘI DUNG:

- Meta: đổi 3 mục "Author/Post Date/Comment" thành "Client/Year/Role" —
  giá trị demo tĩnh dùng chung: Client "Confidential Client", Year
  "2025", Role (lấy theo category của portfolio item tương ứng slug, vd
  "Web Design" hoặc "UI/UX Design")
- Tag: lấy theo category của portfolio item (tra portfolio.ts theo slug)
- Title: lấy theo title của portfolio item (tra portfolio.ts theo slug)
- Đoạn mở đầu: "Every successful project starts with understanding what
  truly matters to the client. Behind every polished interface and
  seamless experience lies a clear strategy — one built on research,
  collaboration, and a deep understanding of the brand's goals. In this
  project, we partnered closely with the client to turn an ambitious
  vision into a cohesive, high-impact digital experience."
- Block 1 — heading "1. Understanding the Challenge": "Before any design
  work began, we took time to understand the client's goals, audience,
  and the obstacles standing in their way. Our discovery phase focused
  on:" + danh sách: "Auditing the existing brand and digital presence",
  "Identifying key user pain points through research and interviews",
  "Aligning stakeholders around a shared vision for the project" +
  "We don't just design — we listen first, then build with intention."
- Block 2 — heading "2. Crafting the Right Solution": "With a clear
  understanding of the challenge, we moved into strategy and design —
  balancing creativity with usability to deliver a solution that truly
  serves the client's goals." + danh sách: "Developed a cohesive visual
  identity aligned with the brand", "Designed intuitive user flows
  backed by iterative testing", "Built a scalable system ready to grow
  with the client's business"

NẾU HTML gốc còn thêm block/quote/outcome nào nữa phía sau (tự đọc lại
toàn bộ file để xác nhận đủ, đoạn mình phân tích có thể chưa đọc hết tới
cuối file) — viết tiếp nội dung case-study phù hợp theo đúng SỐ LƯỢNG và
CẤU TRÚC HTML của các block đó (quote khách hàng, số liệu kết quả...),
không bỏ sót block nào, không tự thêm/bớt số lượng so với HTML gốc.

Cột social icon sticky bên trái (giữ nguyên, tái dùng cơ chế sticky đã
làm ở các trang detail trước).

Route "/portfolio-detail/[slug]/page.tsx", generateStaticParams theo 6
slug trong portfolio.ts. Cuối trang: section-contact-3 (dựng cấu trúc,
chưa sửa nội dung).

=====================================================================
SAU KHI XONG CẢ 2 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Custom cursor "View" hoạt động đúng (tái dùng, không lỗi)
- Bấm từ card portfolio → đúng route /portfolio-detail/[slug], title/tag
  đổi đúng theo item
- Nội dung case-study mới hiển thị đúng, không còn dấu vết nội dung blog
  văn hoá công ty cũ
- Cột sticky bên trái hoạt động đúng khi cuộn
- Slug không tồn tại → 404
- Không phụ thuộc jQuery/Bootstrap JS, build production pass

LƯU Ý: Trang Contact của agency SẼ LÀM SAU trong 1 prompt riêng — KHÔNG
tự ý làm thêm ở bước này.