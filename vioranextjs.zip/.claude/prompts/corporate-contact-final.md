Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Convert ../viora/viora/demo-corporate/contact.html thành route "/contact"
(route group (demo-corporate), Header/Footer đã có sẵn). Trang có 2
section, ĐÃ ĐỌC ĐỦ.

## 1. Section "team-purpose-showcase" (gallery ảnh masonry)

5 ảnh xếp 3 cột không đều nhau (col-image-1: 2 ảnh xếp dọc 382x287 +
276x276; col-image-2: 1 ảnh dọc lớn 606x808; col-image-3: 2 ảnh xếp dọc
276x276 + 382x509), mỗi ảnh có class "hover-image" (hiệu ứng zoom nhẹ khi
hover — đọc đúng CSS gốc để lấy chính xác scale/transition, không áng
chừng). Heading "Contact Us" / "Everything You Need to Know Before
Getting Started with Us".

## 2. Section Contact (info + form)

- Bên trái: heading "Got Questions? We'd Love To Hear From You!" + mô tả
  (SỬA LẠI đoạn mô tả — đã xác nhận với người dùng, HTML gốc dán nhầm nội
  dung niche y tế "patient-centered care..." không hợp corporate, dùng
  đoạn thay thế: "We are deeply committed to delivering strategic,
  results-driven solutions that prioritize your business growth, backed
  by expertise, transparency, and unwavering integrity at every step of
  your journey with us.")
- "Reach Out To Us": 3 mục icon (Address, Phone, Email) — địa chỉ "101 E
  129th St, East Chicago, 2nd Floor, NY", phone "1-555-678-8888", email
  "themesflat@gmail.com" (href="#", giữ nguyên không phải mailto thật)
- Bên phải: form "Get In Touch" — First Name, Last Name, Email, Phone
  Number (type="number"), Message (textarea), nút "Send Message"
  (onSubmit preventDefault)

KHÔNG có bản đồ/iframe trong trang này (khác với dự án Agentra trước đây
có Google Maps — trang contact của Viora corporate không có phần đó).

## Data

Tách địa chỉ/phone/email vào src/data/demo-corporate/contactInfo.ts (để
Footer có thể tái dùng nếu trùng thông tin — kiểm tra lại Footer đã build
xem có cùng địa chỉ/phone/email không, nếu trùng thì tái dùng chung 1
nguồn data).

## Component

- ShowcaseGallery.tsx (components/othersPages/demo-corporate/)
- ContactSection.tsx (info list + form)

## Trang

Route "/contact" (page.tsx), ráp: ShowcaseGallery + ContactSection.

## Sau khi xong

Chạy npm run dev, Playwright so sánh với HTML gốc:
- Bố cục masonry 5 ảnh đúng, hover zoom đúng hiệu ứng
- Form đủ field, validate required cơ bản (HTML required attribute)
- Không phụ thuộc jQuery, build production pass