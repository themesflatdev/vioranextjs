Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

CHỈ làm 2 trang trong dropdown "Services" của agency (KHÔNG làm Contact,
Portfolio, Portfolio Detail ở bước này — để sau), báo cáo xong trang nào
rồi mới sang trang tiếp theo:

=====================================================================
TRANG 1 — /demo-agency/services (services.html)
=====================================================================

section-service-3: TÁI DÙNG THẲNG ServicesNumbered.tsx đã build ở Home
Agency (data services.ts đã có sẵn — Brand Strategy/Web Design &
Development/Digital Marketing/UI/UX Design), KHÔNG viết lại.

Cuối trang có "section-testimonial-2" (tái dùng teaser đã build ở Home)
+ "section-contact-3" (dựng đúng cấu trúc HTML gốc, CHƯA cần sửa nội
dung mô tả/dropdown — việc đó để làm ở prompt riêng cho trang /contact
sau này, ở ĐÂY chỉ cần component không lỗi khi hiển thị).

=====================================================================
TRANG 2 — /demo-agency/service-detail/[slug] (service-detail.html) — ROUTE ĐỘNG
=====================================================================

2 section riêng: section-strategy v2, section-expected-outcomes v2 —
nội dung (Business Strategy, Market Research, Business Model Innovation...)
PHÙ HỢP agency, GIỮ NGUYÊN không cần sửa gì.

LƯU Ý: giống mọi trang detail đã làm trước — HTML gốc CHỈ CÓ 1 bản nội
dung demo duy nhất, dùng chung cho cả 4 dịch vụ. Title/breadcrumb lấy
đúng theo slug (tra services.ts — 4 dịch vụ: Brand Strategy, Web Design
& Development, Digital Marketing, UI/UX Design), phần thân bài dùng
chung tĩnh.

Ảnh có parallax (data-speed=".8" — tái dùng cách đã làm ở AboutSection
Home Agency nếu cùng cơ chế, kiểm tra lại cho chắc trước khi tái dùng).

Cuối trang: section-contact-3 (dựng cấu trúc, chưa sửa nội dung, giống
Trang 1).

Route "/service-detail/[slug]/page.tsx", generateStaticParams theo 4
slug trong services.ts.

=====================================================================
SAU KHI XONG CẢ 2 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- ServicesNumbered hiển thị đúng, không lỗi khi tái dùng lần nữa (đã
  dùng ở Home + About + đây là lần thứ 3)
- Bấm từ /services vào từng dịch vụ → đúng route /service-detail/[slug]
  tương ứng, title đổi đúng theo dịch vụ
- Parallax ảnh hoạt động đúng
- Thử slug không tồn tại → 404
- Không phụ thuộc jQuery/Bootstrap JS, build production pass

LƯU Ý: 3 trang còn lại của agency (Contact, Portfolio, Portfolio Detail)
SẼ LÀM SAU trong 1 prompt riêng — KHÔNG tự ý làm thêm ở bước này.