Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "medical" (route group (demo-medical),
route "/demo-medical"). Chi tiết dưới đây đã XÁC MINH bằng đọc trực tiếp
demo-medical/index.html.

## 1. Cấu trúc DOM (GSAP ScrollSmoother — giống các niche trước)

demo-medical/index.html dùng gsap.min.js + ScrollSmoother + ScrollTrigger +
SplitText (script tag xác nhận, KHÔNG có splitting.min.js — hover chữ chỉ
CSS opacity fade, không cài package splitting).

2 header "style-4 header-sticky" (ngoài #smooth-wrapper) và "style-4"
(trong #smooth-wrapper/#smooth-content) — ĐÃ DIFF: nội dung giống hệt
nhau, chỉ khác class header-sticky và `<div class="header-inner px-0">`
(bản fixed) vs `<div class="header-inner">` (bản thường) — giống hệt kiểu
khác biệt đã gặp ở insurance, giữ đúng qua prop `fixed`.

## 2. Cơ chế scroll — KHÁC corporate/agency/insurance: `header-sticky`

Class "header-sticky" xác nhận trong HTML → dùng hook `useHeaderSticky`
(src/hooks/useHeaderSticky.ts, ĐÃ CÓ SẴN — direction-aware, threshold
400px, delta 10px, class "is-sticky"), KHÔNG dùng `useHeaderFixed`.

## 3. Breakpoint responsive — mốc "lg" (991/992), giống corporate/agency

Class thật trong HTML: `mobile-button d-lg-none` (không có "xl-hide" hay
"d-xl-none" nào) — main-menu ẩn/mobile-button hiện ở ≤991px, dùng CSS có
sẵn, không cần JS đo viewport.

## 4. Header-right — chỉ 1 CTA, KHÔNG có social/contact-box

`<a href="#" class="tf-btn btn-hover-animate-border style-border
sm-hide">Call Us Now</a>` rồi tới mobile-button. CTA có href="#" (không
trỏ đi đâu trong HTML gốc) — giữ nguyên, KHÔNG tự gán link. Class
"sm-hide" chỉ ẩn ở ≤575px (gần như luôn hiện, kể cả ở view mobile-button).

## 5. Menu (giữ nguyên nội dung, đã xác nhận đầy đủ — LƯU Ý điểm khác biệt)

Desktop:
- Demos (mega-menu, class thường `submenu mega-menu`, KHÔNG có
  "menu-rounded" như insurance): ĐÚNG 12 demo, thứ tự y hệt các niche
  trước. "Home Medical" trỏ "/demo-medical", "Home Corporate" trỏ "/".
  Không phát hiện bug link nào (khác agency). + "View all demos (20)".
- Pages (dropdown, 9 mục — NHIỀU hơn các niche trước vì medical có nhiều
  trang đặc thù): About Us→/about, Our Doctor→/our-doctor, Doctor
  Detail→/doctor-detail, Testimonials→/testimonials, Pricing→/pricing,
  Working Hours→/workinghours, Make An Appointment→/appointment, Cost
  Calculator→/costcalculator, FAQs→/faqs.
- Services (dropdown): Services→/service (LƯU Ý: slug thật là "service"
  số ít, không phải "services" — đúng theo danh sách trang thật ở
  master-workflow.md mục 2), Services Detail→/service-detail
- Project (dropdown): Porfolio→/portfolio (giữ nguyên label lỗi chính tả
  gốc "Porfolio", slug thật "portfolio" viết đúng), Portfolio
  Detail→/portfolio-detail
- Blog (dropdown) — LƯU Ý ĐẶC BIỆT: nhãn hiển thị dùng từ ngữ kiểu
  corporate ("Blog Full Width", "Blog With Sidebar") nhưng slug thật lại
  là kiểu insurance (bloggrid/bloglist/blogdetail, không phải
  blog-full-width/blog-with-sidebar) — ĐÃ XÁC NHẬN giống hệt nhau ở CẢ
  desktop lẫn mobile (không phải lỗi gõ 1 chỗ, là cách đặt tên nhất quán
  trong HTML gốc) → giữ NGUYÊN VĂN theo đúng rule 4 CLAUDE.md (giữ lỗi
  nội dung gốc, không tự "sửa cho hợp lý" vì đây không phải link hỏng):
  "Blog Full Width"→/bloggrid, "Blog With Sidebar"→/bloglist, "Blog
  Detail"→/blogdetail.
- Contact→/contact

Mobile — ĐỦ 20 niche, thứ tự y hệt các niche trước. 5 nhóm accordion
(Demos/Pages/Services/Project/Blog) — nội dung khớp 100% với desktop, agrep
KHÔNG phát hiện bug href nào (khác agency/insurance).

Tách data vào src/data/demo-medical/menu.ts, 2 mảng riêng
desktopDemosFeatured (12) và mobileDemosFull (20). TẤT CẢ href nội bộ
niche phải có tiền tố `/demo-medical/...`.

## 6. Modal "View all demos"

`#modalDemo` riêng trong trang, dùng lại giải pháp đã áp dụng: link đơn
giản "/landing#demos".

## Sau khi xong — checklist verify

- ≥992px: main-menu hiện, mobile-button ẩn; ≤991px: ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover thuần)
- Không có `.char` nào (Splitting.js không chạy)
- Mobile: offcanvas mở/đóng đúng, đủ 20 demo, 5 nhóm accordion, mọi href
  đúng (kể cả Blog Full Width→bloggrid, Blog With Sidebar→bloglist)
- Cơ chế scroll `header-sticky` ĐÚNG THEO HƯỚNG: cuộn xuống liên tục qua
  400px → is-sticky KHÔNG xuất hiện (ẩn); cuộn NGƯỢC LÊN một đoạn (>10px)
  → is-sticky XUẤT HIỆN (hiện lại) — test khác hẳn kiểu ngưỡng đơn giản
  của header-fixed, không được test nhầm công thức
- Không còn phụ thuộc jQuery/Bootstrap JS
