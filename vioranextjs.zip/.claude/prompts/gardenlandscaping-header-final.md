Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "gardenlandscaping" (route
"/demo-gardenlandscaping"). Đã XÁC MINH bằng đọc trực tiếp
demo-gardenlandscaping/index.html — niche này có BUG NỘI DUNG NGHIÊM
TRỌNG cần sửa (không phải suy đoán, đã đọc kỹ cả 2 khối header).

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (KHÔNG
splitting.min.js). Có #smooth-wrapper/#smooth-content. LƯU Ý: header
THƯỜNG (bản trong #smooth-content) nằm LỒNG trong 1 `<div class="wrap-
header-hero parallax-container">` cùng với ảnh hero parallax phía sau
(`.thumbs.parallax-image`) — đây là cấu trúc gắn liền TRANG CHỦ (Bước 3,
hiệu ứng parallax hero), KHÔNG dựng ở bước Header này. HeaderSection.tsx
CHỈ render header thường trực tiếp (không bọc wrap-header-hero) — khi làm
trang chủ sau này sẽ cần cân nhắc lại cấu trúc để chèn đúng ảnh hero
parallax bọc quanh header, ghi chú lại cho bước đó.

2 header "style-12 header-sticky bg-white pt-0" (ngoài) / "style-12"
(trong) — cơ chế scroll: header-sticky → `useHeaderSticky` (đã có sẵn),
ĐÚNG như bảng. Breakpoint: `<nav class="main-menu xl-hide">` → mốc "xl"
(1199/1200), ĐÚNG như bảng.

## 2. BUG NGHI�êM TRỌNG: nội dung "medicare" bị dính nhầm vào CẢ 2 bản header

Đã đọc kỹ cả 2 khối `<header>` — PHÁT HIỆN không giống các niche trước
(2 bản KHÔNG giống hệt nhau về nội dung menu, chỉ giống cấu trúc):

- **Pages submenu**: bản header-fixed (ngoài) có nội dung ĐÚNG chuẩn
  index-only-niche (About Us/Our Team/Team Detail/Carrer/Carrer
  Detail/FAQs, trỏ `../demo-corporate/...`) — NHƯNG "About Us" bị thừa 1
  KÝ TỰ TRẮNG đầu href (`href=" ../demo-corporate/about-us.html"`, có
  space trước "..").
  Bản header THƯỜNG (trong #smooth-content) có nội dung HOÀN TOÀN KHÁC —
  9 mục kiểu phòng khám y tế không liên quan gì tới garden landscaping:
  "About Us/Our Doctor/Doctor Detail/Testimonials/Pricing/Working
  Hours/Make An Appointment/Cost Calculator/FAQs", tất cả trỏ file cục bộ
  `demo-medicare-*.html` KHÔNG TỒN TẠI trong thư mục demo-gardenlandscaping/
  (rõ ràng là nội dung copy-paste sót lại từ niche "medical"/"medicare"
  chưa được dọn, không có file nào trong 9 link này tồn tại thật).
- **Services submenu**: CẢ 2 bản header đều bị lỗi
  `demo-medicare-service.html` và
  `demo-medicare-../demo-corporate/service-detail.html` (prefix
  "demo-medicare-" rác dính vào cả URL tương đối, cú pháp hỏng).
- **Contact link**: CẢ 2 bản header đều bị lỗi
  `demo-medicare-../demo-corporate/contact.html`.
- **Project, Blog**: CẢ 2 bản ĐÚNG, không có bug (trỏ đúng
  ../demo-corporate/portfolio*.html, blog-*.html).

Mobile offcanvas (`#menu-mobile`) HOÀN TOÀN SẠCH, không dính bug
"demo-medicare-" nào — Pages/Services/Project/Blog/Contact ở mobile đều
trỏ đúng `../demo-corporate/...` bình thường như các niche khác. Bug CHỈ
xảy ra ở desktop (cả 2 bản).

→ CÁCH SỬA (chỉ có 1 cách hợp lý, khớp với chính mobile của trang này và
đúng pattern chung mọi niche chỉ-có-index): dùng ĐÚNG 1 bộ nội dung Pages/
Services/Project/Blog/Contact giống mobile — route thật corporate
(`/about-us`, `/our-team`, `/team-detail`, `/carrer`, `/carrer-detail`,
`/faqs`, `/services`, `/service-detail`, `/portfolio`, `/portfolio-
detail`, `/blog-full-width`, `/blog-with-sidebar`, `/blog-detail`,
`/contact`) cho CẢ 2 bản header (fixed + thường) — bỏ hẳn nội dung
"medicare" (không thuộc niche này), bỏ "404 Error" (theo quy ước chung).

## 3. Header-right: search + cart icon + CTA

`.nav-icon-list`: icon search (`icon-MagnifyingGlass`, `#search`, chỉ
render markup tĩnh, không cần hoạt động — ngoài phạm vi Header) + icon
giỏ hàng (`icon-Handbag` + badge "24", `#shoppingCart`, chỉ render tĩnh).
CTA `<a class="tf-btn btn-hover-animate btn-bg-primary-2 sm-hide">Call Us
Now</a>` (href="#", ẩn ở ≤575px) rồi `.mobile-button.d-xl-none`.

`tf-container large`, `header-inner position-relative`. Mega-menu submenu
có class "menu-rounded". Logo: `logo-garden-scaping.svg`.

## 4. Menu (giữ nguyên phần đúng, sửa đúng phần bug ở mục 2)

12 demo mega-menu thứ tự y hệt các niche trước, gardenlandscaping KHÔNG
có mặt trong 12 demo featured của chính nó (không có card tự-trỏ). Mobile
đủ 20 niche, 5 nhóm accordion Demos/Pages/Services/Project/Blog, Contact
link thẳng cuối (mobile hoàn toàn sạch, dùng làm chuẩn đối chiếu).

Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover), verify
  ĐÚNG href sau khi sửa bug (không còn "demo-medicare-" hay khoảng trắng
  thừa ở bất kỳ đâu, cả bản fixed lẫn bản thường)
- search/cart icon hiện đúng (không cần chức năng)
- CTA "Call Us Now" ẩn ở ≤575px
- Cơ chế header-sticky: kiểm tra scrollHeight trước khi test cuộn, dùng
  page.mouse.wheel()
- Mobile: Demos đủ 20, mọi link đúng route corporate (đối chiếu lại với
  chính mobile gốc, vốn đã sạch)
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
