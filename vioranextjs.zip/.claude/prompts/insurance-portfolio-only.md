Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

CHỈ làm 2 trang trong dropdown "Project" của insurance (KHÔNG làm
Contact, Blog ở bước này), báo cáo xong trang nào rồi mới sang trang
tiếp theo. LƯU Ý: tên file gốc là "porfolio.html"/"porfolio-detail.html"
(thiếu chữ "t", lỗi chính tả CÓ THẬT trong tên file — giữ nguyên route
khớp đúng tên file, KHÔNG tự sửa thành "portfolio").

=====================================================================
TRANG 1 — /demo-insurance/porfolio (porfolio.html) — SỬA NỘI DUNG
=====================================================================

section-portfolio-6: tab filter (View All/Business/Insurance/Cardiology,
dùng Bootstrap tab data-bs-toggle="tab" — thay bằng React state đơn giản
chọn tab active, KHÔNG dùng Bootstrap JS). CHỈ CÓ 4 project THẬT (Property
Insurance, Business Insurance, Renters Insurance, Personal Accident), bị
LẶP LẠI giống hệt trong cả 4 tab (lỗi demo content — mỗi tab hiện y hệt 4
project này, không lọc theo category thật). GIỮ ĐÚNG hành vi này (4 tab
đều hiện đủ 4 project giống nhau, không cần tự chế thêm project khác
theo từng category).

SỬA LỖI CẤU TRÚC: ảnh đang link "service-detail.html" (sai), tiêu đề
link "porfolio-detail.html" (đúng hướng nhưng thiếu slug) — ĐỒNG BỘ cả
2 link cùng trỏ "/porfolio-detail/${slug}".

SỬA NỘI DUNG mô tả + danh sách bullet (đã xác nhận với người dùng — gốc
dùng nội dung web development/business consulting không hợp insurance):

**Property Insurance**: "We help protect your home and belongings from
unexpected damage, theft, or natural disasters, so you can feel secure
no matter what happens."
- Comprehensive property damage coverage
- Fast, hassle-free claims process
- Coverage options for natural disasters

**Business Insurance**: "From property damage to liability claims, our
business insurance plans are built to protect what you've worked so
hard to build."
- Liability and property coverage for businesses
- Tailored plans for small to large enterprises
- 24/7 claims support for business owners

**Renters Insurance**: "Affordable coverage designed to protect your
personal belongings and give you peace of mind, wherever you call
home."
- Protection for personal belongings
- Liability coverage for renters
- Flexible plans that fit any budget

**Personal Accident**: "Life is unpredictable — our personal accident
plans provide financial support and peace of mind when you need it
most."
- Coverage for accidental injury and disability
- Fast claims processing after an incident
- Add-on options for extended family coverage

Data 4 project tách vào src/data/demo-insurance/portfolio.ts (title,
desc, 3 bullet, image, slug). Cuối trang: section-faqs-1 (tái dùng).

=====================================================================
TRANG 2 — /demo-insurance/porfolio-detail/[slug] (porfolio-detail.html) — ROUTE ĐỘNG + VIẾT LẠI NỘI DUNG
=====================================================================

ĐÃ XÁC NHẬN với người dùng: nội dung gốc Y HỆT nội dung xây dựng/tư vấn
đã gặp ở corporate's portfolio-detail (Baruch Construction, Highland
Office Complex, Nexora tech summit — hoàn toàn không liên quan bảo
hiểm). VIẾT LẠI toàn bộ thành case-study bảo hiểm thật, giữ nguyên cấu
trúc kỹ thuật (Overview + 4 số liệu, Our Approach + Scope of Work 5 mục,
Quote, Outcome):

- Overview: "Our team partnered with a growing property management
  company to design a comprehensive business insurance package covering
  multiple commercial properties across 3 states. The project involved
  a full risk assessment, policy customization, and ongoing claims
  support — all delivered within a tight 60-day renewal deadline."
- 4 số liệu: Duration "60 Days", Category "Business Insurance", Client
  (giữ nguyên tên đang có trong HTML gốc), Date (giữ nguyên ngày đang có).
- Our Approach: "We began with a full risk assessment across all
  properties, reviewing existing coverage gaps and identifying areas of
  exposure. Through close collaboration with the client's leadership
  team, we designed a tailored policy structure built around their
  specific operational risks."
- Scope Of Work (5 mục): "Comprehensive multi-property risk assessment",
  "Custom policy structuring across 3 states", "Liability and property
  damage coverage bundling", "Dedicated claims support team assignment",
  "Ongoing policy review and renewal planning"
- Quote: "\"Working with this team gave us real peace of mind. They
  took the time to understand our business and built a policy that
  actually protects what matters most.\"" — giữ nguyên tên người nói
  trong HTML gốc, đổi chức danh thành "Property Portfolio Manager" (thay
  vì "CEO Avitex" không hợp ngữ cảnh khách hàng mua bảo hiểm).
- Outcome: "The new coverage was finalized ahead of the renewal
  deadline, with zero gaps in protection during the transition. The
  client reported increased confidence in their risk management and
  significantly faster claims turnaround in the following year."

NẾU HTML gốc còn block/số liệu nào sau đoạn Outcome mà chưa đọc hết (tự
đọc lại toàn bộ file để xác nhận đủ), viết tiếp nội dung phù hợp bảo
hiểm theo đúng SỐ LƯỢNG/CẤU TRÚC của các block đó, không bỏ sót, không
tự thêm/bớt.

Title/breadcrumb + category hiển thị: lấy theo slug tương ứng (tra
portfolio.ts). Route "/porfolio-detail/[slug]/page.tsx",
generateStaticParams theo 4 slug.

=====================================================================
SAU KHI XONG CẢ 2 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Tab filter chuyển đúng (dù nội dung 4 tab giống nhau, đúng theo HTML
  gốc), không dùng Bootstrap JS
- Ảnh + tiêu đề đều link đúng cùng 1 route /porfolio-detail/[slug]
- Nội dung case-study mới hiển thị đúng, không còn dấu vết xây dựng/
  Nexora/brand audit
- Slug không tồn tại → 404
- Không phụ thuộc jQuery/Bootstrap JS, build production pass

LƯU Ý: Contact và Blog của insurance SẼ LÀM SAU trong prompt riêng —
KHÔNG tự ý làm thêm ở bước này.