Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "coworkingspace" (route
"/demo-coworkingspace"). Đã XÁC MINH bằng đọc trực tiếp
demo-coworkingspace/index.html + _header.scss (cùng gốc style-9 với
spasalon).

## 1. Cấu trúc DOM + breakpoint 1300px — XÁC NHẬN GIỐNG SPASALON

class "style-9 v2 header-sticky" (ngoài) / "style-9 v2" (trong) — LƯU Ý:
coworkingspace dùng `header-sticky` (KHÁC spasalon dùng header-fixed) →
dùng `useHeaderSticky` (đã có sẵn), không phải `useHeaderFixed`.

Đã đọc trực tiếp `_header.scss`: block `&.style-9 { ... &.v2 { margin-top
...} }` — `.v2` CHỈ chỉnh margin, KHÔNG override breakpoint, nên mốc
1300px hardcode (`.header-center { @media(max-width:1300px)
{ .main-menu{display:none} .mobile-button{display:flex} } }`) áp dụng Y
HỆT spasalon — bảng master-workflow.md mục 1 ghi "xl (1199/1200) — CHƯA
VERIFY" đã XÁC NHẬN SAI, ĐÚNG là custom 1300px giống spasalon. Cần sửa lại
bảng.

Cấu trúc logo-giữa/2-main-menu Y HỆT spasalon: `.header-center` chứa
`<nav class="main-menu">` #1 (trái: Demos mega-menu, Pages, Services) →
`<a class="site-logo">` (giữa) → `<nav class="main-menu">` #2 (phải:
Project, Blog, Contact). `.header-left.md-hide` bên trái header-inner: box
điện thoại `icon-PhoneCall` + "1-333-345-6868" (ẩn ở ≤767px).

## 2. Khác biệt THẬT giữa 2 bản (đã diff) — 4 điểm, KHÁC spasalon (chỉ 2 điểm)

- Bản fixed CÓ `<div class="tf-container w-1840">` bọc ngoài header-inner;
  bản thường KHÔNG CÓ (header-inner nằm trực tiếp trong `<header>`).
- `header-inner` bản fixed có thêm `px-0` (class: "rounded-0 px-0"), bản
  thường chỉ "rounded-0".
- Phone: bản fixed dùng thẻ `<h6 class="phone ... text_white ...">`, bản
  thường dùng `<div class="phone ... text-white h6 ...">` (khác TAG + tên
  class trắng viết khác nhau "text_white" vs "text-white" — giữ đúng y hệt
  từng bản, không tự đồng bộ).
- Logo: bản fixed dùng `logo-coworking-space-2.svg`, bản thường dùng
  `logo-coworking-space.svg` (2 file khác nhau, cả 2 đã có sẵn trong
  public/assets/images/logo/) — giữ đúng qua prop `fixed`, giống pattern
  đã gặp ở spasalon.

Class `<header>` ngoài còn có thêm "px-0" ngay trên chính nó (khác
spasalon không có): `class="header style-9 v2 header-sticky px-0"`.

## 3. BUG PHÁT HIỆN: "About Us" desktop trỏ SAI (link nội bộ hỏng)

Desktop Pages submenu, mục "About Us" trỏ `href="about-us.html"` (link
tương đối cục bộ) — ĐÃ XÁC NHẬN `demo-coworkingspace/` KHÔNG có file
about-us.html nào (chỉ có index.html), nên link này 404 trên bản gốc thật.
Mọi mục Pages khác (Our Team, Team Detail, Carrer...) VÀ mục "About Us" ở
MOBILE offcanvas đều trỏ đúng `../demo-corporate/about-us.html` — xác
nhận đây là lỗi gõ thiếu tiền tố, CHỈ xảy ra ở đúng 1 chỗ (desktop). → sửa
thành `/about-us` (route thật corporate) trong menu.ts, khớp với mọi chỗ
khác.

## 4. PATTERN chung: Pages/Services/Project/Blog/Contact còn lại TRỎ SANG CORPORATE

Như mọi niche chỉ-có-index khác (xem memory
index-only-niches-reuse-corporate-pages) — route thật corporate, KHÔNG
tiền tố `/demo-coworkingspace`. Bỏ "404 Error".

## 5. Header-right: social icon (không CTA)

`ul.tf-social.style-4.sm-hide` (4 icon: icon-Linkedin, icon-XLogo-2,
icon-InsLogo-fill, icon-Youtube) rồi `.mobile-button` (KHÔNG có class
d-lg-none/d-xl-none — ẩn/hiện tự động qua CSS `.header-center` ở mục 1,
giống spasalon).

## 6. Menu (giữ nguyên nội dung, trừ bug đã nêu ở mục 3)

12 demo mega-menu thứ tự y hệt các niche trước: Corporate/Agency/Insurance/
Medical/Restaurant/AI Tech/AI Content Writer/SaaS/Health Coach/Spa Salon/
Lawyer/Charity — coworkingspace KHÔNG có mặt trong 12 demo featured của
chính nó (mega-menu liệt kê đủ 12 demo chuẩn, không có card tự-trỏ-chính-
mình), giữ đúng y hệt danh sách chuẩn không thêm bớt.

Mobile — đủ 20 niche, offcanvas "style-dark", 5 nhóm accordion
Demos/Pages/Services/Project/Blog (Pages "About Us" ở mobile trỏ ĐÚNG,
không có bug). Active tại "Coworking Space" khi ở route
"/demo-coworkingspace".

Tách data vào src/data/demo-coworkingspace/menu.ts.

## 7. Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥1301px: 2 main-menu (trái+phải) hiện đồng thời, mobile-button ẩn;
  ≤1300px: ngược lại (đo đúng mốc 1300, KHÔNG dùng nhầm 1199/1200)
- header-left (phone) ẩn ở ≤767px (md-hide)
- Logo đổi đúng file theo trạng thái fixed/thường
- Hover Pages/Services (trái) và Project/Blog (phải) xổ đúng submenu (CSS
  hover)
- Cơ chế header-sticky: kiểm tra scrollHeight trước khi chọn giá trị test
  cuộn, dùng page.mouse.wheel() thay vì window.scrollTo() nếu nghi ngờ
  scroll-behavior:smooth ảnh hưởng kết quả
- Mobile: Demos đủ 20, "About Us" trỏ đúng /about-us (verify bug đã sửa)
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
