Sửa cảnh báo Sass deprecation trong src/styles/abstracts/_mixin.scss
dòng 66 (mixin "res", dùng để tính breakpoint responsive toàn dự án).

Hiện tại:
  $breakpoint: if(
      $type==min,
      map.get($breakpoints-min, $size),
      map.get($breakpoints, $size)
  );

Đổi sang cú pháp if() mới (named-argument) theo đúng gợi ý của Sass
compiler:
  $breakpoint: if(
      condition: $type==min,
      if-true: map.get($breakpoints-min, $size),
      if-false: map.get($breakpoints, $size)
  );

CHỈ sửa đúng cú pháp, KHÔNG đổi logic/giá trị breakpoint (vẫn phải cho
ra đúng kết quả như cũ — $type==min thì lấy map breakpoints-min, ngược
lại lấy map breakpoints thường).

Sau khi sửa, chạy npm run build, xác nhận:
- Không còn cảnh báo "Sass if() syntax is deprecated" xuất hiện
- Toàn bộ breakpoint responsive vẫn hoạt động đúng như trước (kiểm tra
  nhanh 1 trang bất kỳ đã làm, vd /demo-corporate, resize qua breakpoint
  lg xem còn đúng không)