Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "agriculturefarming" (route
"/demo-agriculturefarming"). Đã XÁC MINH bằng đọc trực tiếp
demo-agriculturefarming/index.html — niche này có CẤU TRÚC KHÁC HẲN mọi
niche đã làm trước đó (không phải bug, là thiết kế thật của theme cho
demo này), đọc kỹ mục 2 trước khi code.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc phần còn lại của
trang + footer.

## 2. QUAN TRỌNG: Header KHÔNG chứa logo — logo nằm ở 1 topbar riêng

Khác TẤT CẢ niche trước (nơi mỗi `<header>` tự chứa logo + nav + icons),
ở đây:

- **2 khối `<header class="header style-17...">`** (ngoài: thêm
  `header-sticky`; trong: không có) — CẢ 2 chỉ chứa `mobile-button` (xếp
  TRƯỚC nav trong DOM, giữ đúng thứ tự này) + `nav.main-menu.style-2` +
  `header-right` (`nav-icon-list` search/cart, KHÔNG có CTA nào) —
  KHÔNG CÓ site-logo ở cả 2 bản header. Xác nhận bằng đọc code, không phải
  thiếu sót do đọc lướt.
- **1 khối `<div class="topbar-3">` RIÊNG BIỆT**, nằm NGAY TRONG
  #smooth-content, PHÍA TRÊN header thường (không lặp lại cho bản
  fixed/ngoài #smooth-wrapper — chỉ xuất hiện ĐÚNG 1 LẦN). Chứa:
  ```
  <div class="topbar-3">
    <div class="tf-container d-flex justify-content-between align-items-center">
      <a class="site-logo"><img class="logo_header" .../></a>
      <div class="tb-right d-flex align-items-center">
        <ul class="list-info xl-hide">  <!-- 3 mục: phone/email/address -->
          ...
        </ul>
        <a class="tf-btn btn-hover-animate-2 btn-bg-secondary btn-hover-animate-2">Get A Quote</a>
      </div>
    </div>
  </div>
  ```
  `topbar-3` KHÔNG sticky/fixed (đã xác nhận trong _header.scss, chỉ
  `display:flex` thường, cuộn theo trang bình thường) — nghĩa là khi cuộn
  qua khỏi topbar, thanh header-sticky nổi lên chỉ có nav+icon, KHÔNG có
  logo — đây là hành vi CHỦ Ý của theme cho demo này, giữ đúng, KHÔNG tự ý
  thêm logo vào header sticky.

Breakpoint: `mobile-button` dùng `d-lg-none` → mốc "lg" (991/992), ĐÚNG
như bảng mục 1. RIÊNG `list-info` trong topbar dùng `xl-hide` (ẩn ở
≤1199px) — mốc KHÁC với mobile-button, giữ đúng 2 mốc khác nhau này,
không gộp chung.

## 3. Component — tách 2 component riêng (khác các niche trước)

Vì cấu trúc khác biệt, tạo:
- `TopBar.tsx`: render đúng topbar-3 (logo + list-info 3 mục phone/email/
  address + CTA "Get A Quote" href="#"), dùng CHUNG (không có prop
  fixed/variant, chỉ render 1 lần trong HeaderSection).
- `Header.tsx`: CHỈ render mobile-button + nav + header-right (nav-icon-list
  search/cart, badge cart "24"), KHÔNG có logo, nhận prop `fixed?: boolean`
  giống pattern các niche khác.
- `HeaderSection.tsx`: `<Header fixed .../>` NGOÀI #smooth-wrapper, rồi
  bên trong #smooth-content: `<TopBar /><Header .../>{children}`.

## 4. Menu nội dung — không có bug ở Services/Project/Blog/Contact

12 demo mega-menu đúng thứ tự chuẩn, agriculturefarming KHÔNG có mặt
trong 12 demo featured của chính nó. Services/Project/Blog/Contact đúng
route corporate, KHÔNG bug.

LƯU Ý NHỎ: submenu "Pages" có 1 KÝ TỰ TRẮNG thừa đầu href
(`href=" ../demo-corporate/about-us.html"`, giống hệt lỗi đã gặp ở
corporate gốc) — CHỈ là lỗi cú pháp HTML gốc, không ảnh hưởng khi convert
sang route Next.js (route "/about-us" bình thường, không có khoảng
trắng), không cần xử lý gì thêm.

Mobile offcanvas (`#menu-mobile`, KHÔNG có class "style-dark") đủ 20
niche, đúng thứ tự chuẩn, "Agriculture farming" tự active đúng vị trí. 5
nhóm accordion, Contact link thẳng cuối. Modal "View all demos": link
"/landing#demos".

Logo: `logo-agriculture-farming-1.svg` (167x52 topbar VÀ 193x44 mobile).

## Sau khi xong — checklist verify

- ≥992px main-menu hiện/mobile-button ẩn; ≤991px ngược lại (mốc LG)
- topbar-3 (logo + info + CTA) hiện ở đầu trang, list-info 3 mục ẩn đúng ở
  ≤1199px (xl)
- Cuộn xuống quá topbar: header-sticky nổi lên CHỈ có nav+icon, KHÔNG có
  logo (đúng theo thiết kế, không phải thiếu sót)
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- search/cart icon hiện đúng, badge "24"
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: Demos đủ 20, mọi link đúng route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
