Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng
con số, không áng chừng. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-healthcoach/index.html (route "/demo-healthcoach", route group (demo-healthcoach)).
Header/Footer ĐÃ CÓ SẴN (header style-7 header-sticky, mốc menu mobile lg 991/992; footer style-default v2). Niche này CHỈ
có index.html, không có trang con. Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS), hero, rồi 10 block main-content (ĐÃ ĐỌC ĐỦ),
THEO 4 NHÓM; verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Đặc điểm: CÓ ScrollSmoother (`#wrapper` > `#smooth-wrapper` > `#smooth-content`), nền SÁNG (--Bg-light), font h1…h6 = Instrument
Sans (--font-main2), font body = Plus Jakarta Sans (--font-main). Không dùng data-ns-animate, Atropos, hay marquee dọc.

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-healthcoach)/layout.tsx: wrapper `data-niche="healthcoach"`; cấu trúc #wrapper > #smooth-wrapper > #smooth-content;
   HeaderSection gọi useScrollSmoother() + useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE: demo-healthcoach/css/health-coach.css (88 dòng) có selector TOÀN CỤC: `body {color}`, `#smooth-wrapper
   {background-color: var(--Bg-light)}`, `h1,.h1…h6,.h6 {font-family: var(--font-main2); font-weight: 500; color: var(--Primary)}`,
   `.font-main`, `.text_primary`, `.text_secondary-color`, `.main-menu …`, `.navigation …`, `.tf-btn` và nhiều variant btn, `.section-cta-3
   {z-index:2}`, `.text-caption-1 {font-size…}`. Với src/styles/demo-healthcoach.scss: BỌC TOÀN BỘ trong `[data-niche="healthcoach"] { ... }`
   (SCSS nesting): `:root {…}` -> biến trên chính `[data-niche="healthcoach"]` (dùng `&`); `body {color}` -> `color` trên
   `[data-niche="healthcoach"]`; `#smooth-wrapper {…}` -> `#smooth-wrapper {…}` lồng bên trong; mọi rule còn lại lồng nguyên văn.
   KHÔNG đổi giá trị/thứ tự. Đo lại sau khi bọc: màu/font h2 + màu body ở / và /demo-healthcoach khớp HTML gốc tương ứng, cả khi điều
   hướng client-side.
3. Font: h1…h6 = `Instrument Sans` (assets/font/fonts.css có sẵn @font-face). Xác nhận computed font-family của h2 đúng sau khi bọc CSS.
4. `ls src/hooks src/components/common` và tái dùng: useSplitTextReveal, useWow, useScrollSmoother, useSwiperControls, useCountUp, hook
   accordion 1-mục-mở + collapse transition, hook scroll-transform, magnific popup, tf-animateCLP. Kiểm tra/bổ sung:
   a. useSplitTextReveal có chế độ `effect-scale` (MỚI nếu chưa có): `Object.assign(settings, { opacity: 0, scale: 0.5 })` (đọc từ
      gsapAnimate.js dòng 308 — cùng cơ chế SplitText + GSAP scrollTrigger như các chế độ khác, chỉ khác giá trị from). Kiểm tra và bổ
      sung vào hook nếu thiếu.
   b. `data-background` + `data-speed`: getDataImage() trong main.js gán `background-image: url(data-background)` lên phần tử; rồi
      ScrollSmoother `effects: true` TỰ ĐỌC `data-speed` và áp parallax. Không cần hook riêng. Việc cần làm: đảm bảo `useScrollSmoother`
      trong dự án truyền `effects: true` khi tạo smoother (kiểm tra; đây là điều kiện để parallax data-speed chạy); và gắn đúng thuộc tính
      `data-background` + `data-speed` trên phần tử — sau đó phần còn lại là GSAP lo. Phần tử phải có `style={{ backgroundImage: 'url(...)' }}`
      (hoặc gán qua useEffect giống getDataImage) để ảnh hiện khi JS chưa tải; giá trị là đường dẫn public. `data-lag="0"` (chỉ có ở banner-2)
      là tham số của ScrollSmoother lag (mặc định 0, không cần thêm gì đặc biệt).
   c. useSwiperControls: KHÔNG dùng navigation={true}/pagination={true}; nút và dots của theme buộc bằng ref.
   d. magnific popup (thư viện jQuery `magnificPopup`): trang này dùng `class="popup-youtube"` + `href="https://youtube.com/..."` ->
      click mở iframe YouTube trong lightbox. Trang KHÔNG nạp magnific-popup CSS (`../assets/css/magnific-popup.min.css` không có trong danh
      sách `<link>`) → thực tế không chạy. Thêm `@use` vào chuỗi vendor cho CSS này nếu chưa có, hoặc tạo component đơn giản mở YouTube
      trong `<iframe>` modal (z-index cao, click ngoài để đóng, dùng hook state), đảm bảo các `popup-youtube` href đúng format YouTube embed.
      Nếu đã có MagnificPopup component từ niche khác thì tái dùng.
   e. Text circle SVG quay: `div.text-circle > svg.textcircle` (chữ chạy theo path tròn SVG). ĐÃ XÁC MINH: CSS thuần `animation: rotation2
      20s infinite linear` trong _animation.scss lên class `.textcircle` (kiểm tra xem keyframes `rotation2` có trong bundle) -> chỉ cần đúng
      markup, không cần JS.
   f. useScrollTransform cho `.scroll-transform`: gsapAnimate.js scrollTransform: `gsap.to(element, { x/y: ±distance, scrollTrigger: { trigger:
      element, start: "top bottom", end: "bottom top", scrub: 1 } })`; direction = data-direction || "up"; distance = data-distance || "10%".
      Ở trang này: `div.item.scroll-transform` data-distance="40%" direction mặc định "up" -> y = -40% khi cuộn hết trang. Tái dùng hook đã có
      nếu có; tạo mới nếu chưa.
5. Tên file dữ liệu: src/data/demo-healthcoach/programs.ts, testimonials.ts, faqs.ts, blogPosts.ts, instaPosts.ts.
6. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, KHÔNG chỉ kiểm tra; làm ngay ở bước này). Đã đọc HTML: niche này KHÔNG có trang con; trong
   header và offcanvas mobile `#menu-mobile`, MỌI mục ngoài "Demos" (Pages, Services, Project, Blog, Contact) đều trỏ sang trang CORPORATE
   (`../demo-corporate/*.html`; tập link đã so với restaurant/aitech/saas: GIỐNG HỆT). Corporate chạy ở route GỐC:
   | Nhãn menu                  | Route Next                      |
   | Home Corporate             | /                               |
   | Pages > About Us           | /about-us                       |
   | Pages > Our Team           | /our-team                       |
   | Pages > Team Detail        | /team-detail/{slug}             |
   | Pages > Carrer             | /carrer                         |
   | Pages > Carrer Detail      | /carrer-detail/{slug}           |
   | Pages > FAQs               | /faqs                           |
   | Services > Services        | /services                       |
   | Services > Services Detail | /service-detail/{slug}          |
   | Project > Porfolio         | /portfolio                      |
   | Project > Portfolio Detail | /portfolio-detail/{slug}        |
   | Blog > Blog Full Width     | /blog-full-width                |
   | Blog > Blog With Sidebar   | /blog-with-sidebar              |
   | Blog > Blog Detail         | /blog-detail/{slug}             |
   | Contact                    | /contact                        |
   {slug}: LẤY từ src/data/demo-corporate/menu.ts (slug đầu tiên của từng mục "...Detail"). "Home Health Coach" -> /demo-healthcoach.
   "Porfolio" -> "Portfolio" nếu còn. Cách làm: (a) đọc menu.ts của cả 2 niche, components/layout/demo-healthcoach/; (b) in BẢNG TRƯỚC;
   (c) sửa dữ liệu theo bảng, comment `// mirrors demo-corporate/menu.ts`; (d) cả 3 nơi render dùng chung dữ liệu; dùng <Link>.
   KHÔNG tạo route /demo-healthcoach/about... KHÔNG sửa FOOTER.

## NHÓM 1 — HERO + ABOUT + PROGRAM
### Hero `hero-banner-9` (nằm TRONG smooth-content, trước main-content)
`.tf-container.w-1840 > .wrap-content.tf-grid-layout.lg-col-2.align-items-center.gap-0`: `.box` (col trái) + `.thumbs.tf-animateCLP-right`
(col phải, img hero-1.jpg 920x680 lazy + class `tf-animateCLP-right` = clip-path reveal từ phải).
- `.box > .heading.mb_40`: h2.title.text_secondary-color.mb_20.split-text.split-lines-rotation-x "Unlock Your Fullest Best Self With
  Expert Health Coaching"; p.text-body-2.text_white.split-text.split-lines-transform "We create personalized plans for your health journey,
  combining nutrition, and habits to help you feel great inside."
- a.tf-btn.style-3.btn-bg-secondary.btn-hover-animation-switch.mb_40.wow.fadeInUp data-wow-delay="0.4s" (href "#"): span > i.icon-ArrowRight2.arr-1
  + span.btn-text.text_primary-color "Book A Free Consultation" + i.icon-ArrowRight2.arr-2; + span.bg-effect.
- `.trust.d-flex.align-items-center.gap_12`: `.group` 3 avatar 48x48 group-avatar-1-1/2/3.jpg (wow fadeInLeft delay 0.1/0.2/0.3s) +
  p.text-body-default.text_white.wow.fadeInUp data-wow-delay="0.2s" "Trusted by 50k+ users".
### `section-about-5 tf-spacing-1`
`.tf-container.medium > .row`: col-lg-5 `.wrap-thumb.position-relative` + col-lg-7 `.content`.
- wrap-thumb: `.thumbs.img-style.tf-animateCLP-left > .image` data-speed="0.7" data-background="images/about-1.jpg" (ảnh nền + parallax qua
  ScrollSmoother effects: true; thêm inline style backgroundImage khi mount; div trống, không có img). Cạnh đó: `.item.scroll-transform`
  data-distance="40%" (direction "up" mặc định, cuộn y = -40%) > `.text-circle > svg.textcircle` (animation CSS `rotation2 20s infinite linear`,
  chữ "REAL TALK - REAL GROWTH -" chạy theo path tròn) + `i.icon-ArrowUpRight`.
- content: heading-section.mb_28 [sub "About Us" (text-label text-uppercase text_primary-color split-text effect-up mb_12), h3.title.
  text_primary-color.mb_16.split-text.effect-scale "Empowering You Through Mind-Body Wellness", p.desc.text-body-default.wow.fadeInUp
  "At Viora, we are dedicated professionals..."] + a.tf-btn.btn-hover-animate-2.btn-bg-secondary-2.btn-px-28.wow.fadeInUp data-wow-delay="0.4s"
  (href "#") "About Us". `.wrap-counter.d-flex.justify-content-between` 3 `.counter-item` (tái dùng useCountUp data-count, data-duration 700):
  10 + span "Years" / sub "Professional Experience" | +350 / "Trusted Happy Clients" | 92% / "Client Success Rate". (Lưu ý cấu trúc h3 counter: số
  thứ 1 là `span.numberCounter + span.sub-counter "Years"` bên phải; số thứ 2 là `span.sub-counter "+"` TRƯỚC + `span.numberCounter`; số thứ 3 là
  `span.numberCounter + span.sub-counter "%"`.)
### `section-program` (KHÔNG có tf-spacing)
`.tf-container.medium > .box-program.flat-animate-tab`: `.content-1` (tiêu đề + 4 tab link + nút) và `.tab-content` (4 pane).
- content-1: heading-section.mb_48 [sub "HEALTH IN MOTION" (split-text effect-up text_primary-color), h2.title.text_primary-color.split-text.
  effect-scale "My Fitness Programs"]; `.tab-slide.d-flex > ul.menu-tab.mb_48[role=tablist]` 4 `li.nav-tab-item` (li thứ 2 "Strength" ACTIVE mặc
  định) > `a.tab-link[data-bs-toggle=tab] > span.hover-line-text.h5.link.text_primary`: "1/ Balanced Nutrition Plan" (#balanced), "2/ Strength &
  Flexibility Plan" (#strength, active), "3/ Holistic Lifestyle Program" (#holistic), "4/ Emotional Balance Plan" (#emotional). KHÔNG có
  `.item-slide-effect` (không có thanh trượt). Tab bằng useState, giữ class active/show để CSS gốc hoạt động. Nút: a.tf-btn.btn-hover-animate-2.
  btn-bg-secondary-2.btn-px-28.wow.fadeInUp data-wow-delay="0.8s" "Book Now" (href "#").
- tab-content 4 pane (balanced / strength active show / holistic / emotional): ĐÃ XÁC MINH cả 4 pane có CÙNG nội dung (Strength & Flexibility,
  program-1.jpg 434x579, cùng đoạn mô tả — lỗi demo, GIỮ NGUYÊN, đổi tab chỉ đổi pane hiện). Mỗi pane: `.wrap > .hover-image-2 > .thumbs.img-style.
  tf-animateCLP-up.text-center > img program-1.jpg 434x579 lazy` + `.content-2`: `.tag.text-button.text_primary-color.mb_24.wow.fadeInUp "03 Month"`;
  h3.text_primary-color.mb_12 "Strength & Flexibility Plan"; p.text-body-2.mb_24 "Unlock your full physical potential with a guided program designed
  to improve muscular strength, joint mobility, and overall body flexibility. This plan blends functional training."; a.text-button.hover-underline-link.
  text_primary-color "View Details" (href "#").

## NHÓM 2 — CTA + WHY CHOOSE + BANNER + SUPPORT
### `section-cta-4 tf-spacing-1`
`.tf-container.w-1840 > .wrap > .content-inner.tf-container.medium > .row.align-items-center`: col-lg-6 `.heading` [h2.title.text_primary-color.
split-text.effect-scale "Support That Meets You Where You Are"]; col-lg-6 `.content` [p.text-body-2.mb_32.split-text.split-lines-transform "Let's
chat about helping you feel stronger and in control."; `.wrap-btn.d-flex.gap_20.wow.fadeInUp`: a.tf-btn.btn-px-32.btn-hover-animate-2.btn-bg-primary-2
"Schedule A Free Consultation" + a.tf-btn.btn-hover-animate-border.style-border.btn-px-32 "Call Us: 315-666-6688" (href "#")].
### `section-why-3` (KHÔNG có tf-spacing)
`.tf-container.medium`: heading-section.d-grid.gap_14.text-center.mb_48 [sub "Why choose us?" (split-text effect-up text_primary-color), h2.title.
text_primary-color.split-text.effect-scale "What Makes Us Different"]. `.row`: col-lg-6 `.wrap-box.d-grid.gap_20` 3 `.tf-box-icon.style-5.wow.
fadeInLeft` (delay "", ".2s", ".4s"): h4.heading.d-flex.align-items-center.gap_20.font-main > i.icon + chữ; p.text-body-2.text_secondary:
(icon-UserSound) "Understand Your Needs" / "We take time to truly listen understanding your lifestyle, goals, and challenges before designing any plan."
(icon-ReadCvLogo) "Create Personalized Programs" / "From fitness routines to nutrition plans, everything is tailored to your body, your pace, and your vision of health."
(icon-Barbell) "Support Your Real Progress" / "We stay with you throughout offering ongoing guidance, encouragement, and adjustments for real, lasting results."
col-lg-6 `.thumbs`: img.img-1.wow.zoomIn 450x600 whychoose-1.jpg + img.img-2.wow.zoomIn 300x400 whychoose-2.jpg (cả 2 không có data-wow-delay).
### `section-banner-3 tf-spacing-1`
`.tf-container.w-1840.position-relative > .banner > .bg-img` data-speed="0.8" data-lag="0" data-background="images/banner-2.jpg" (nền parallax, div
trống — xử lý như about-1.jpg). `.content.text-center > div`: h2.text_white.mb_40.title.split-text.effect-right "Support Your Body, The Right Way.";
a.tf-btn.btn-hover-animate-2.btn-bg-white-2.mx-auto.btn-px-32.wow.fadeInUp data-wow-delay="0.4s" "Get The Right Plan" (href "#").
### `section-support tf-spacing-1 pt-0`
`.tf-container.medium > heading-section.text-center.d-grid.gap_16.mb_48` [sub "SUPPORT FOR EVERY STEP" (split-text effect-up text_primary-color),
h2.title.text_primary-color.split-text.effect-scale "Guided Wellness Videos"]. `.tf-grid-layout.md-col-3.gap_30` 3 `.video-item.widget-video`:
Item 1 (tf-animateCLP-left, chỉ có ảnh): `.img-style > img 410x700 video-1.jpg + .btn-video > a.popup-youtube`
  href="https://www.youtube.com/watch?v=XHOmBV4js_E" > i.icon-Play2.
Item 2 (content BÊN DƯỚI img, hình vuông): `.img-style.tf-animateCLP-down > img 410x410 video-2.jpg + .btn-video > a.popup-youtube`; `.content`:
  `.tag.text-button.text_primary-color "Stress Relief"`; `.heading > h4.title.mb_12 > a.hover-line-text "Unwind With Gentle Evening Routine"` +
  p.text-body-default.text_primary-color "Relax your body and quiet mind."
Item 3 (content BÊN TRÊN img): `.content` rồi `.img-style.tf-animateCLP-up > img 410x410 video-3.jpg + .btn-video > a.popup-youtube`; content:
  `.tag "Energy Surge"` + `.heading > h4 > a "Kickstart Your Morning Energy Flow"` + p "Wake up with movement and focus."
YouTube popup (Bước 0.4.d): click `a.popup-youtube` mở iframe YouTube. Dùng component YouTube modal đã có hoặc tạo mới.

## NHÓM 3 — TESTIMONIAL (SWIPER LOOP) + FAQS
### `section-testimonial-8 sw-layout tf-spacing-1` (nằm trong `.tf-container.w-1840`)
`.tf-container.medium > heading-section.style-2.mb_48 > .row.align-items-center`: col-lg-7 [sub "REAL STORIES, REAL RESULTS" (split-text effect-up
text_white letter-spacing-1), h2.title.text_white.split-text.effect-scale "Trusted Voices"]; col-lg-5 [p.text-body-2.text_white.split-text.
split-lines-transform "Discover how coaching with Viora has helped others live stronger, more balanced lives."].
`.position-relative`: `.swiper.wow.fadeInLeft` data-preview=3 data-tablet=2 data-mobile=1 data-space-lg=30 data-space-md=20 data-space=15
data-loop="true" (loop=true — đọc carousel.js: cần `loop: true`, giữ nguyên các bản sao loop của Swiper khi init). Dots `.sw-dots.style-white.
sw-pagination-layout.justify-content-center.text-center.mt_24.d-flex` là CON TRỰC TIẾP của `.swiper` sau .swiper-wrapper (đã xác minh); prev
`.sw-button.style-1.nav-prev-layout` và next `.sw-button.style-1.nav-next-layout` là NGOÀI `.swiper`, trong `.position-relative` (xác nhận bằng
phân tích DOM). Buộc dots vào Swiper bằng ref; buộc prev/next đúng vị trí tương ứng.
4 slide (loop nên clone thêm) testimonial-item.style-7: p.text-body-2.text_primary-color (lời nhận xét trong dấu "…"); `.author.d-flex.gap_12.
align-items-center > .avatar > img 48x48 + div > a.text-button.d-block.link.text_primary-color.font-main tên (href "#") + span.text-caption-1.
text_secondary chức danh`:
  1 avatar-16.jpg — Jamie L — Content Marketer — "Working with Viora has completely shifted how I take care of myself. I have more energy, better focus,
    and feel truly in control of my health."
  2 avatar-12.jpg — Alex Johnson — Content Marketer — "Viora didn't just give me a plan — they gave me confidence. I feel stronger, calmer, and more
    balanced than ever before."
  3 avatar-10.jpg — Rebecca M — Marketing Consultant — "I've tried so many programs, but Viora is the first that actually stuck. Everything was
    personalized, realistic, and supportive."
  4 avatar-16.jpg — Jamie L — Content Marketer (trùng slide 1 — lỗi demo, giữ nguyên).
### `section-faqs-4 tf-spacing-1`
`.tf-container.medium > .row`: col-lg-5 heading-section.style-default [sub "FAQs" (split-text effect-up text_primary-color), h2.title.text_primary-color.
split-text.effect-scale "What Makes Us Different", p.desc.text-body-2.text_secondary.mt_4.split-text.split-lines-transform "Everything you need to know
before getting started."]; col-lg-7 `ul.accordion-wrap#accordion-faq` 5 `li.accordion-item.style-1.v2.wow.fadeInRight` (delay "", "0.2", "0.4", "0.6", "0.8"
— LƯU Ý: delay 2-5 là số thuần "0.2", "0.4"... KHÔNG có "s" — giữ đúng như gốc): a.accordion-title (aria-expanded true/false, câu 2-5 có class
collapsed) > .heading > h5.title.text-capitalize.text_primary-color (chữ "Q1: …" TRONG tiêu đề) + span.icon; panel `.collapse` (câu 1 `.collapse.show`,
data-bs-parent="#accordion-faq") > .accordion-faqs-content > p.text-body-default.text_primary. Câu hỏi:
  Q1: What does a health coach actually do? | Q2: Is this program suitable for beginners? | Q3: How are the sessions delivered?
  Q4: Can I choose what to focus on? | Q5: How long before I see results?
CẢ 5 câu trả lời GIỐNG HỆT nhau ("Absolutely. Each plan is customized to match your current lifestyle, experience level, and health goals — no prior
knowledge needed.") — lỗi demo, GIỮ NGUYÊN (cùng quyết định đã áp dụng cho FAQ của các niche trước).
Hành vi: Bootstrap collapse, data-bs-parent => 1 mục mở, câu 1 mở sẵn. li KHÔNG có class action_click/active; trạng thái icon do class/aria của
`a.accordion-title`. Dùng hook accordion 1-mục-mở + collapse transition chuẩn của dự án.

## NHÓM 4 — INSIGHTS (SWIPER) + INSTAGRAM (SWIPER)
### `section-insights sw-layout` (KHÔNG có tf-spacing)
`.tf-container.medium > heading-section.d-flex.justify-content-between.gap_16.flex-wrap.align-items-center.mb_48`: bên trái [sub "Latest News"
(split-text effect-up text_primary-color mb_16), h2.title.text_primary-color.split-text.effect-scale "Tips And Insights"]; bên phải `.d-flex.gap_12.wow.
fadeInRight` [`.sw-button.style-3.nav-prev-layout > i.icon-CaretLeft` + `.sw-button.style-3.nav-next-layout > i.icon-CaretRight`].
`.swiper.wow.fadeInUp` data-preview=2 data-tablet=2 data-mobile=1 data-space-lg=30 data-space-md=20 data-space=15 (KHÔNG loop; không dots; nav
prev/next ở ngoài swiper trong heading — đã xác minh: nav_prev_parent=['d-flex','gap_12','wow','fadeInRight']). 4 slide `.blog-item.style-3.hover-image`:
a.img-style (href từng bài → /blog-detail/{slug của corporate}) + img 630x440 + `.content > h4.mb_11.title > a.hover-line-text.text_white.font-main.fw-6
tên bài` + `ul.meta-post > li.text-label > div > a.link.text-uppercase.text-label.lh-16 tag` + li.text-label.text-uppercase ngày`:
  Bài 1: blog-item-1.jpg, "NutritionTips", "February 12, 2025", "Simple Habits to Boost Your Energy Naturally"
  Bài 2: blog-item-2.jpg, "CareDaily", "February 12, 2025", "Why Your Diet Isn't Working And What To Do Instead."
  Bài 3: blog-item-1.jpg, "NutritionTips", "February 12, 2025", "Why Your Diet Isn't Working And What To Do Instead." (trùng tên bài 2, ảnh bài 1)
  Bài 4: blog-item-2.jpg, "CareDaily", "February 12, 2025", "Why Your Diet Isn't Working And What To Do Instead." (trùng)
SỬA LINK: gốc trỏ `../demo-corporate/blog-detail.html` -> đổi thành `/blog-detail/{slug bài đầu tiên của corporate}` (lấy từ
src/data/demo-corporate/blogPosts.ts, KHÔNG hard-code). GIỮ NGUYÊN nội dung bài.
### `setion-instagrams tf-spacing-1` (class gõ thiếu 'c' — là tên class thật trong HTML gốc, giữ nguyên; wrapper là `.tf-container.w-1840.
tf-spacing-1.pb-0.sw-layout`)
heading-section.text-center.mb_48 [sub "@Viora_HealthCoach" (text-label text_white text-uppercase lh-16 mb_16 split-text effect-up), h2.title.text_white.
split-text.effect-scale "Follow Us On Instagram"]. `.tf-container.medium > .swiper` data-preview=5 data-tablet=4 data-mobile-sm=3 data-mobile=2
data-space-lg=30 data-space-md=20 data-space=15 (5/4/3/2 slide theo breakpoint, không loop, không nav; dots `.sw-dots.style-white.sw-pagination-layout.
justify-content-center.text-center.mt_24.d-flex` là con trực tiếp của `.swiper` sau .swiper-wrapper). 5 slide `a.ins-item` href="#" >
`.img-style > img 234x234 ins-1..5.jpg + i.icon-instagram-logo`.

## VERIFY (Playwright; mở HTML gốc qua server tĩnh và Next ở cùng độ rộng; cổng KHÔNG dùng 5060/5061)
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font (Instrument Sans cho h2), link không gạch chân, nền sáng đúng,
  không ảnh lỗi/404.
- Rò rỉ CSS: màu/font h2 ở / và /demo-healthcoach khớp HTML gốc tương ứng, cả khi điều hướng client-side.
- About: ảnh nền parallax (data-speed="0.7") di chuyển đúng khi cuộn; text-circle SVG quay (CSS rotation2); `.scroll-transform` item dịch y=-40% khi cuộn hết trang.
- effect-scale: h3 "Empowering You..." xuất hiện từ scale(0.5) lên scale(1), đúng như các h2 khác dùng effect-scale trên trang.
- Program: mặc định tab 2 "Strength" active; đổi tab đổi pane; tf-animateCLP-up chạy khi pane mới được hiển thị.
- YouTube popup: click icon Play mở iframe YouTube embed đúng video, click ngoài hoặc phím Esc để đóng.
- Testimonial loop: đủ 4 slide + bản clone loop; prev/next ở ngoài .swiper; dots ở trong .swiper; click dots đổi slide; không có `.swiper-button-*` mặc định.
- Insights: nav prev/next ở heading, không dots; 4 bài, link đúng route corporate blog-detail.
- Instagram: 5/4/3/2 slide theo breakpoint; dots hoạt động.
- Menu: quét link từ /demo-healthcoach (desktop hover dropdown + mobile ≤991px): MỌI link Pages/Services/Project/Blog/Contact -> 200 và vào đúng trang corporate;
  liệt kê riêng 404 chỉ do niche chưa làm; không còn ".html".
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả bọc CSS (rò rỉ đã kiểm tra); hook mới (effect-scale trong useSplitTextReveal, YouTube popup nếu mới); nội dung đã sửa
(link blog 4 bài); kết quả đo từng điểm; việc chưa xong.