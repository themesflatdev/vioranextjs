Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "carservices" (route "/demo-carservices").
Đã XÁC MINH bằng đọc trực tiếp demo-carservices/index.html — niche này
KHÔNG có bug nội dung (khác gardenlandscaping), 2 bản header giống hệt
nhau.

## 1. Cấu trúc DOM

gsap.min.js + ScrollTrigger + SplitText + ScrollSmoother (không
splitting.min.js). Có #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer, header "header-sticky" (bản ngoài) nằm NGOÀI, không
lồng trong wrap nào khác (khác gardenlandscaping — ở đây không có
`wrap-header-hero`).

2 header "style-13 header-sticky" (ngoài) / "style-13" (trong) — NỘI DUNG
GIỐNG HỆT NHAU (đã diff xác nhận, không lệch — Pages/Services/Project/
Blog/Contact đều đúng route corporate, KHÔNG có bug "medicare" như
gardenlandscaping). Dùng 1 component Header.tsx nhận prop `fixed?:
boolean`.

Cơ chế scroll: header-sticky → dùng `useHeaderSticky` (đã có sẵn ở
src/hooks/, TÁI DÙNG, không viết lại). Breakpoint: `<nav class="main-menu
xl-hide">` → mốc "xl" (1199/1200), ĐÚNG như bảng mục 1 master-workflow.

## 2. Header-right: search + cart + CTA

`.nav-icon-list`: icon search (`icon-MagnifyingGlass`) + icon giỏ hàng
(`icon-Handbag` + badge **"2"**, KHÁC các niche khác thường là "24" — giữ
đúng số "2" theo HTML gốc, không tự sửa). CTA:
`<a href="../demo-corporate/portfolio.html" class="tf-btn btn-bg-primary-2
btn-hover-animate-2 md-hide">Get A Quote</a>` — LƯU Ý: href trỏ tới
portfolio (không phải contact, hành vi lạ nhưng ĐÚNG theo HTML gốc, giữ
nguyên → route "/portfolio"). CTA ẩn ở breakpoint "md" (≤767px, class
`md-hide`), KHÁC gardenlandscaping dùng `sm-hide` (≤575px) — xác nhận
đúng class trong code, không giả định giống niche trước.

`tf-container` (không phải "large" hay "w-1840"). Mega-menu submenu class
"menu-rounded". Logo: `logo-car-service.svg` (167x52 header, 193x44
mobile).

## 3. Menu nội dung (không có bug, giữ nguyên toàn bộ)

12 demo mega-menu thứ tự y hệt các niche trước, carservices KHÔNG có mặt
trong 12 demo featured của chính nó. Pages/Services/Project/Blog/Contact
— dùng đúng route corporate (`/about-us`, `/our-team`, `/team-detail`,
`/carrer`, `/carrer-detail`, `/faqs`, `/services`, `/service-detail`,
`/portfolio`, `/portfolio-detail`, `/blog-full-width`, `/blog-with-sidebar`,
`/blog-detail`, `/contact`), bỏ "404 Error" (theo quy ước chung).

Mobile offcanvas (`#menu-mobile`, class thêm "style-dark" — LƯU Ý giữ
class này trên wrapper offcanvas, ảnh hưởng theme màu tối của riêng
carservices) đủ 20 niche, đúng thứ tự chuẩn (xem menu.ts các niche trước
để lấy đúng thứ tự 20 mục — carservices tự active ở đúng vị trí "Car
Service"). 5 nhóm accordion Demos/Pages/Services/Project/Blog, Contact
link thẳng cuối. Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- search/cart icon hiện đúng, badge cart = "2" (không phải "24")
- CTA "Get A Quote" trỏ đúng `/portfolio`, ẩn ở ≤767px (md), không phải
  ≤575px
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: offcanvas có class "style-dark", Demos đủ 20, mọi link đúng
  route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
