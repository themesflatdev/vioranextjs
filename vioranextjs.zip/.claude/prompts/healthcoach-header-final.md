Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "healthcoach" (route "/demo-healthcoach").
Đã XÁC MINH bằng đọc trực tiếp demo-healthcoach/index.html.

## 1. Cấu trúc DOM

Dùng gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (KHÔNG có
splitting.min.js, giống mọi niche). CÓ #smooth-wrapper/#smooth-content
(không có class phụ nào, khác restaurant). 2 header "style-7 header-sticky"
/ "style-7" — ĐÃ DIFF: giống hệt nhau (chỉ khác class + line-wrap).

Cơ chế scroll: header-sticky → dùng `useHeaderSticky` (đã có sẵn).
Breakpoint: `mobile-button d-lg-none` → mốc "lg" (991/992).

## 2. PATTERN chung: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

Xác nhận lại đúng pattern (xem memory index-only-niches-reuse-corporate-pages):
mọi link trỏ `../demo-corporate/<page>.html` → dùng route thật corporate
(`/about-us`, `/our-team`, `/team-detail`, `/carrer`, `/carrer-detail`,
`/faqs`, `/services`, `/service-detail`, `/portfolio`, `/portfolio-detail`,
`/blog-full-width`, `/blog-with-sidebar`, `/blog-detail`, `/contact`),
KHÔNG tiền tố `/demo-healthcoach`. Bỏ "404 Error".

## 3. Chi tiết markup riêng

- `tf-container` có thêm class `w-1840` (`class="tf-container w-1840"`).
- `<nav class="main-menu style-2">` (main-menu có thêm class "style-2").
- Mega-menu submenu KHÔNG có "menu-rounded" (khác insurance/aitech).
- Nút "View all demos" có class `tf-btn btn-mega-2`.
- header-right: `class="header-right d-flex align-items-center gap_24 font-main"`
  (có thêm "font-main") — chứa: Login link (`class="link text-button
  text_primary-color"`, href="#") → CTA `<a class="tf-btn style-border
  btn-hover-animate-border sm-hide">Get Started</a>` (href="#", ẩn ở
  ≤575px) → `.mobile-button.d-lg-none`.
- Offcanvas mobile-nav-wrap KHÔNG có class "style-dark" (nền sáng mặc
  định, khác restaurant/aitech).
- Logo: `logo-health-coach-1.svg`.

## 4. Menu (giữ nguyên, không phát hiện bug link nào)

12 demo mega-menu thứ tự y hệt các niche trước, "Home Health Coach" trỏ
"/demo-healthcoach" (active). Mobile đủ 20 niche, 5 nhóm accordion
Demos/Pages/Services/Project/Blog, Contact link thẳng cuối danh sách.

Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥992px main-menu hiện/mobile-button ẩn; ≤991px ngược lại
- Hover 4 submenu mở đúng (CSS hover)
- Login + Get Started hiện đúng, Get Started ẩn ở ≤575px
- Cơ chế header-sticky: kiểm tra scrollHeight trang trước khi chọn giá trị
  test cuộn (tránh lặp lỗi test đã gặp ở restaurant/aitech — dùng giá trị
  trong phạm vi cuộn thực tế)
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
