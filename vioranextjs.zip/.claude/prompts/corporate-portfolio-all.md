Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Làm 2 trang, THEO ĐÚNG THỨ TỰ, báo cáo xong trang nào rồi mới sang trang
tiếp:

=====================================================================
TRANG 1 — /portfolio (portfolio.html)
=====================================================================

3 section, ĐÃ ĐỌC ĐỦ:

1. section-portfolio: heading "Case Studies"/"Our Portfolio" ở cột trái
   (class "fixed-thumb" — heading DÍNH CỐ ĐỊNH khi cuộn qua danh sách
   bên phải, giống cơ chế cột sticky đã gặp ở blog-detail — dùng CSS
   position: sticky). Cột phải: 5 portfolio-item, MỖI ITEM CÓ HIỆU ỨNG
   CUSTOM CURSOR "View" — TÁI DÙNG THẲNG cơ chế/component đã build ở
   CaseStudiesSection của trang chủ corporate, KHÔNG viết lại.
2. section-cta-5: heading + avatar nhóm "Trusted by 50k+ users" + mô tả
   + nút "Get Started" (href="#")
3. wrap-partner: marquee logo đối tác (6 logo, data-clone="2") — TÁI
   DÙNG cơ chế marquee đã có từ trước (Footer hoặc trang khác), KHÔNG
   viết lại.

## Data

5 portfolio item, tách vào src/data/demo-corporate/portfolio.ts (title,
category, image, slug — sinh slug từ title). TẤT CẢ ĐỀU LINK
"portfolio-detail.html" trong HTML gốc → khi làm Trang 2 (route động),
cập nhật lại link ở đây trỏ đúng "/portfolio-detail/${slug}".

=====================================================================
TRANG 2 — /portfolio-detail/[slug] (portfolio-detail.html) — ROUTE ĐỘNG
=====================================================================

LƯU Ý: giống service-details/project-details/blog-detail đã gặp trước —
HTML gốc CHỈ CÓ 1 bản nội dung chi tiết duy nhất (demo dùng chung cho cả
5 item, nội dung có phần không nhất quán giữa các đoạn — đoạn Overview
nói về dự án xây dựng "Baruch Construction/Highland Office Complex",
đoạn Our Approach lại nói về rebranding "Nexora" — ĐÂY LÀ ĐẶC ĐIỂM CỦA
DEMO GỐC, giữ nguyên y hệt, không tự sửa cho nhất quán).

- Title/breadcrumb: lấy đúng theo item tương ứng slug (tra portfolio.ts
  theo slug, không tìm thấy thì notFound())
- Toàn bộ nội dung thân bài (Overview, 4 số liệu thống kê, ảnh, Our
  Approach, Scope of Work, Quote, Outcome, 2 ảnh cuối) dùng CHUNG 1 bộ
  nội dung tĩnh cho MỌI slug — copy đúng y hệt HTML gốc.
- section-cta-5 + wrap-partner: TÁI DÙNG y hệt component đã build ở
  Trang 1 (không viết lại).

## Trang

Route "/portfolio-detail/[slug]/page.tsx", generateStaticParams theo 5
slug trong portfolio.ts.

## Sau khi xong cả 2 trang

Playwright so sánh với HTML gốc:
- Cột heading Trang 1 dính cố định (sticky) khi cuộn đúng
- Custom cursor "View" hoạt động (tái dùng đúng, không lỗi)
- Marquee đối tác chạy mượt
- Bấm từ card portfolio → đúng route /portfolio-detail/[slug] tương ứng
- Slug không tồn tại → 404
- Không phụ thuộc jQuery, build production pass