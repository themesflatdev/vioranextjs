Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng con số,
không áng chừng. Không chắc -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-lawyer/index.html (route "/demo-lawyer", route group (demo-lawyer)).
Header/Footer ĐÃ CÓ SẴN. Niche này CHỈ có index.html, không có trang con (Pages/Services/Project/Blog/Contact
đều dùng của corporate). Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS), hero+thumbs, rồi 8 block main-content,
THEO 4 NHÓM; verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Đặc điểm: CÓ ScrollSmoother, nền TỐI (--Secondary #1B263B), font h1-h6 = Merriweather (--font-main2, serif).

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-lawyer)/layout.tsx: wrapper data-niche="lawyer"; cấu trúc #wrapper > #smooth-wrapper >
   #smooth-content; HeaderSection gọi useScrollSmoother() + useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE: demo-lawyer/css/lawyer.css (75 dòng) có selector TOÀN CỤC: body {color},
   h1-h6 {color; font-family: Merriweather; font-weight:400}, .font-main, .main-menu/navigation (nhiều rule
   màu trắng cho menu tối), .tf-btn.style-border-2. Bọc vào [data-niche="lawyer"] { ... } trong
   src/styles/demo-lawyer.scss. Đo lại sau khi bọc: màu/font h2 ở / và /demo-lawyer khớp HTML gốc.
3. Font: h1-h6 = Merriweather (assets/font/fonts.css đã có @font-face). Xác nhận computed font-family đúng.
4. Tái dùng: useSplitTextReveal (effect-right, effect-scale, effect-up), useWow, useScrollSmoother,
   useSwiperControls, hook tab giá Monthly/Yearly + tabSlide, hook tf-sw-mobile (Swiper ≤575px only), hook
   accordion nếu cần, parallax data-background + ScrollSmoother effects:true (đã xác nhận ở healthcoach).
5. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, ngay bước này). Niche THUẦN CORPORATE (đã đo: 13 niche nhóm C),
   tất cả mục Pages/Services/Project/Blog/Contact trỏ sang corporate:
   | Pages > About Us           | /about-us                   | Pages > Our Team     | /our-team              |
   | Pages > Team Detail        | /team-detail/{slug}         | Pages > Carrer       | /carrer                |
   | Pages > Carrer Detail      | /carrer-detail/{slug}       | Pages > FAQs         | /faqs                  |
   | Services > Services        | /services                   | Services > Detail    | /service-detail/{slug} |
   | Project > Portfolio        | /portfolio                  | Project > Detail     | /portfolio-detail/{slug}|
   | Blog > Blog Full Width     | /blog-full-width            | Blog > With Sidebar  | /blog-with-sidebar     |
   | Blog > Blog Detail         | /blog-detail/{slug}         | Contact              | /contact               |
   {slug}: từ src/data/demo-corporate/menu.ts. "Home Lawyer" -> /demo-lawyer. "Porfolio" -> "Portfolio".
   Cách làm: đọc menu.ts của 2 niche, in BẢNG TRƯỚC, sửa theo bảng, comment mirrors demo-corporate/menu.ts,
   cả 3 nơi render (header cố định/thường, offcanvas mobile) dùng chung; dùng <Link>.
   KHÔNG sửa FOOTER.
6. Data: src/data/demo-lawyer/services.ts (4 dịch vụ), pricing.ts (3 gói), blogPosts.ts (3 bài),
   testimonials.ts (3 slide), processSteps.ts (4 bước).

## NHÓM 1 — HERO (SWIPER THUMBS) + ABOUT

### Hero `.tf-slider-7` (NGOÀI main-content, trước nó)
Cấu trúc: `.swiper.sw-single.effect-content-slide` data-parallax="true" data-autoplay="true" + `.wrap-nav >
.swiper.sw-thumbs-pagi` (thumbs điều hướng đồng bộ).

**Main swiper (.sw-single)**: `effect-content-slide` là CSS thuần theo class `swiper-slide-active`; `data-parallax`
kích hoạt hiệu ứng `data-swiper-parallax` trên phần tử trong slide (ảnh nền trượt); autoplay=true.
3 slide, mỗi slide: `.tp-showcase-slider-bg` data-background="images/hero-banner-N.jpg" data-swiper-parallax="1152"
(ảnh nền được gán qua getDataImage bởi main.js, và data-swiper-parallax = 1152px tạo hiệu ứng ken-burns khi chuyển
slide). Bên trong: `.hero-banner-19 > .content-inner > .tf-container > .row > .col-lg-5 > .content.mb_40`:
- h1.text-white.mb_16.effect-item.effect-left.delay-2: slide 1 "Trusted Legal Experts" / 2 "Strong Legal Defense"
  / 3 "Protect Your Rights"
- p.text-body-2.text_white.effect-item.effect-left.delay-3: slide 1 "Comprehensive legal solutions designed to
  protect your rights and long-term interests." / 2 "Experienced attorneys committed to supporting you through
  every challenging situation." / 3 "Dedicated legal services providing effective solutions for your most
  critical cases."
- a.tf-btn.btn-hover-animate-2.btn-bg-white-4.rounded-0.effect-item.effect-left.delay-4 "Our Services" (href "#").

**Cơ chế (đã đọc carousel.js — làm đúng)**: khởi tạo `sw-thumbs-pagi` trước (loop=true, preview=3, mobile-sm=3,
spaceBetween=16, freeMode, watchSlidesProgress), rồi `sw-single` với `thumbs: { swiper: pagiSwiper }`. Khi
parallax=true: trong mỗi slide, tìm phần tử có `data-swiper-parallax` và truyền giá trị đó vào Swiper parallax
config (Swiper tự xử lý animation). Không cần JS riêng ngoài cấu hình Swiper.

**Thumbs swiper (.sw-thumbs-pagi)** (trong `.wrap-nav`): 3 slide, mỗi slide `.thumbs-pagi > img 120x60`
(pagi-thumb-1.jpg / hero-banner-2.jpg / hero-banner-3.jpg). Slide active trong thumbs hiển thị đường viền
(CSS theo class `swiper-slide-thumb-active`). Cấu hình React: dùng `Swiper` + module Thumbs + `useSwiperControls`,
tạo ref cho cả 2 swiper và truyền thumbs.swiper qua onSwiper. KHÔNG có dots hay nav riêng cho main swiper (chỉ
có thumbs).

### `section-about-15 tf-spacing-18`
`.tf-container > .row`: col-lg-6 `.box-left` + col-lg-6 `.wrap-box-icon`.
- box-left: heading-section.mb_48 [sub "WHO WE ARE" (text-label text-uppercase text_muted split-text effect-up
  mb_17 lh-16 wow fadeInUp), h2.title.mb_16.split-text.effect-right "Trusted Legal Experts For Your <span
  class='text_primary-color'>Peace Of Mind</span>", p.desc.text-body-2.wow.fadeInUp data-wow-delay="0.2s" mô tả];
  `.quote.mb_48.wow.fadeInUp` data-wow-delay="0.4s" [p.desc.h5.mb_24.font-2.text-capitalize lời trích dẫn;
  `.author` > h6.text_primary.mb_4 "Aisha Malik" + div.text-caption-1.text_primary "CEO at FlowEdge"];
  a.tf-btn.btn-hover-animate-2.btn-bg-secondary.rounded-0.wow.fadeInUp data-wow-delay="0.6s" "About Us" href "#".
- wrap-box-icon: 4 `.box-icon.wow.fadeInRight` (delay "", ".2s", ".4s", ".6s"): icon + h5 + p + số thứ tự h4:
  1 icon-Scroll / "Proven Experience" / "With more than 10 years of managing diverse legal matters, we deliver
  proven results."
  2 icon-Handshake / "Committed to Clients" / "We carefully listen and thoughtfully design strategies to safeguard
  your best interests."
  3 icon-Coins / "Fair & Open Pricing" / "Transparent pricing with no unexpected fees — built on trust and
  professionalism."
  4 icon-Scales / "Strong Commitment" / "Always committed to securing the strongest possible outcomes for every
  valued client."

## NHÓM 2 — SERVICES + PROCESS + PRICING

### `section-service-16`
`.tf-container.large > heading-section-5.mb_60`: `.row.align-items-end` [col-lg-5: sub "Our Services" (text-label
text-uppercase text_muted mb_12 lh-16 letter-spacing-1 mb_16 wow fadeInUp), h2.title.text_white.split-text.
effect-right "Comprehensive Legal Solutions For <span>Every Need</span>"; col-lg-7 `.right`: p.text-body-2.mb_20.
text_muted.wow.fadeInUp + a.hover-underline-link.py-1.text-button.text_white "View All Services" href "#"].
`tf-grid-layout.lg-col-4.sm-col-2` 4 `.service-item.style-9.hover-image.wow.fadeInLeft` (delay "", ".2s", ".4s",
".6s"): a.img-style.mb_26 (img 412x308) + .content [h4.title.text_white.mb_12.line-clamp-2 > a.hover-line-text +
p.text_muted.text-body-2.mb_20.line-clamp-2 + a.hover-underline-link.text_white.text-button "View Services"]:
1 service-1.jpg / "Civil Law and Family Legal Issues" / "Trusted guidance for family, civil disputes, and
  inheritance matters."
2 service-2.jpg / "Firm Law and Corporate Legal Matters" / "Reliable solutions for contracts, compliance, and
  corporate governance."
3 service-3.jpg / "Property Law and Real Estate Solutions" / "Expert legal advice for safe, transparent real
  estate transactions."
4 service-4.jpg / "Criminal Law and Strong Legal Defense" / "Dedicated defense to protect your rights in
  criminal cases."
Mọi href="#". Nội dung đúng niche, không sửa.

### `section-process-8 tf-spacing-1`
`.tf-container > heading-section.mb_60`: `.heading-section.style-default.text-center.mb_47` [sub "Working Process"
(text-label text_muted text-uppercase wow fadeInUp), h2.title.split-text.effect-right "Our Trusted <span
class='text_primary-color'>Process</span>", p.text-body-2.wow.fadeInUp data-wow-delay="0.2s"]. `.wrap-box-process.
wow.fadeInUp` 4 `.process-item`: `.icon.mb_40 > i.icon-CalendarCheck + span.number` + `.content.text-center >
h5.mb_12 > a.hover-line-text + p.text-body-default.text_secondary`:
LỖI: cả 4 bước dùng CÙNG icon `icon-CalendarCheck` (lỗi demo — giữ nguyên). 4 bước:
1 "Case Consultation" / "We discuss your case and understand your legal needs."
2 "Legal Strategy" / "We craft a personalized legal plan to achieve the best results."
3 "Court Handling" / "We efficiently manage your case while keeping you updated."
4 "Final Resolution" / "Achieve the best outcome and receive ongoing support."

### `section-pricing-9.pricing-container`
heading-section.text-center.d-grid.gap_16.mb_40 [sub "Our Pricing" (letter-spacing-1 text-label lh-16 text_secondary
text-uppercase wow fadeInUp), h2.split-text.effect-right "Choose Your <span>Legal Plan</span>", p.text-body-2.wow.
fadeInUp]. `.tab-slide.style-1.d-flex.justify-content-center.mb_48 > ul.menu-tab.d-inline-flex`: `li.item-slide-effect`
+ "Pay Monthly" (active, data-pricing="monthly") + "Pay Yearly" (data-pricing="year"). Tab giá + tabSlide (tái dùng
hook đã có). `.tab-content.wow.fadeInUp.sw-layout > .swiper.tf-sw-mobile` data-screen-xl="3" data-preview="2"
data-tablet="2" data-mobile="1" data-space-lg="30" data-space-md="20" data-space="15":
Swiper chỉ bật ≤575px (tf-sw-mobile — tái dùng useMobileSwiper đã có). Dots con trực tiếp của .swiper sau
.swiper-wrapper. 3 slide `.pricing-item.style-7`:
1 Starter (icon-stars-shape-5): "Perfect for freelancers needing a flexible desk to work a few days weekly." (nội
  dung coworking lọt vào — lỗi demo, GIỮ NGUYÊN); 199/499; style-border-2 nút; 4 tính năng: "Email support" /
  "Access to legal resources" / "Initial consultation (1 hr/month)" / "Document review ( 3 documents)".
2 Pro (icon-stars-shape-6, tag "Popular" + Lightning-2.png 20x21): "Ideal for small businesses or individuals
  requiring legal support."; 499/899; btn-bg-secondary nút; "Unlimited consultations" / "Contract drafting & review"
  / "Legal advice on compliance" / "Priority response legal team".
3 Business (icon-stars-shape-7): "Comprehensive legal solutions crafted for companies."; 999/1999; style-border-2;
  "24/7 priority support" / "Full legal representation" / "Compliance audits" / "Unlimited contract drafting".
Dots `.sw-dots.style-1.position-relative.z-5.sw-pagination-layout.text-center.mt_24` là con trực tiếp của .swiper
(đã xác minh pattern); buộc bằng ref. Cơ chế đổi giá: tái dùng hook tab giá đã có (initSwitchPriceValue).

## NHÓM 3 — BANNER + TESTIMONIAL

### `section-banner-12 tf-spacing-1`
`.wrap.overflow-hidden > div.banner` data-speed="0.7" data-background="images/banner-1.jpg" (nền parallax, div
trống, xử lý như healthcoach: ScrollSmoother effects:true + inline backgroundImage khi mount) + `.tf-container >
.box > heading-section.d-grid.gap_16.mb_40` [sub "Professional Legal Help" (letter-spacing-1 text-label lh-16
text_muted text-uppercase wow fadeInUp), h3.split-text.effect-right "Speak Directly With Our <span>Legal Team</span>",
p.text-body-2.wow.fadeInUp data-wow-delay=".2s": gốc "Stay ahead with expert car care tips" (nội dung carservices
lọt vào) -> SỬA thành "Get straight answers from our experienced legal team — no jargon, no delays."];
a.tf-btn.btn-hover-animate-2.btn-bg-secondary.rounded-0.btn-px-28.wow.fadeInUp data-wow-delay=".4s" "Contact Us"
href "#".

### `section-testimonial-17.sw-layout`
`.tf-container > .row`: col-lg-6 `.box-left` + col-lg-6 Swiper fade autoplay.
- box-left: heading-section.mb_44 [sub "Real Experiences" (text-label text-uppercase text_muted split-text effect-up
  mb_16 lh-16 wow fadeInUp), h2.title.mb_16.split-text.effect-right "Uncover Stories From Our <span>Trusted
  Clients</span>", p.desc.text-body-2.wow.fadeInUp]; `.d-flex.align-items-center.gap_28.wrap-review.mb_44.wow.fadeInUp`
  [img gg-review.svg + img trustpilot.svg (ảnh dùng chung images/)]; a.tf-btn "Read All Review" href "#".
- Swiper.wow.fadeInRight data-effect="fade" data-autoplay="": 3 slide `.testimonial-item.style-15.v2`:
  `.icon.mb_20 > i.icon-Quote-2` + p.h5.font-main.fw-4 lời nhận xét + `.author > h6.mb_4 > a.link + span`:
  1 "Our experience with this law firm was outstanding. Their professionalism and constant support gave us
    confidence throughout every step, ensuring fair solutions and results exceeding expectations." —
    Michael Johnson / "Business Owner, New York" (đúng niche, giữ nguyên).
  2 gốc "The dedicated team combines innovation with care for the land, consistently delivering results that truly
    make a difference for farmers like us." (farming lọt vào) -> SỬA: "The team's dedication and deep legal
    knowledge helped us resolve our corporate matter swiftly and professionally. We couldn't have asked for
    better representation." — Cheyenne Mango / "Corporate Client" (đổi chức danh từ "Organic Farm Owner").
  3 Slide 3 GIỐNG HỆT slide 2 trong HTML gốc (lỗi demo, giữ nội dung đã sửa của slide 2 — GIỮ NGUYÊN lặp).
  Swiper: effect fade, autoplay, KHÔNG loop, KHÔNG dots; nav `.wrap-sw-button.d-flex.gap_12 > .sw-button.style-7.
  nav-prev-layout + nav-next-layout` nằm TRONG col-lg-6 bên phải (cùng cấp với .swiper trong div col-lg-6).
  Buộc nav bằng useSwiperControls.

## NHÓM 4 — INSIGHTS (SWIPER) + CONTACT (FORM)

### `section-insights-7.sw-layout.tf-spacing-1`
`.tf-container > heading-section.style-default.text-center.mb_47` [sub "News & Insights" (text-label text_muted
text-uppercase split-text effect-up lh-16 wow fadeInUp), h2.title.split-text.effect-right "Latest Legal <span>
Updates</span>", p.text-body-2.wow.fadeInUp data-wow-delay=".2s"]. `.swiper` data-preview="3" data-tablet="2"
data-mobile="1" data-mobile-sm="2" data-space-lg="30" data-space-md="20" data-space="15": 3 slide `.swiper-slide.
wow.fadeInLeft` (delay "", "0.2s", "0.4s") > `.blog-item.style-8.hover-image-translate`: a.img-style.mb_23 >
img 450x540 blog-1/2/3.jpg + tag text-label position-absolute; `.content > ul.meta-post.mb_12.font-3` [li tác giả
+ li ngày] + h4.title.line-clamp-2 > a.link.hover-line-text.
SỬA LINK: gốc trỏ `../demo-corporate/blog-detail.html` -> dùng route corporate `/blog-detail/{slug đầu tiên của
corporate}` (lấy từ src/data/demo-corporate/blogPosts.ts, KHÔNG hard-code).
Dots `.sw-dots.style-1.sw-pagination-layout.text-center.mt_24` là con trực tiếp của .swiper; buộc bằng ref.
3 bài: 1 blog-1.jpg / "Property Law" / Sarah Mitchell / June 12, 2025 / "Navigating Property Law Disputes
Effectively." | 2 blog-2.jpg / "Corporate Law" / David Harrison / June 12, 2025 / "Corporate Legal Trends
Businesses Should Know." | 3 blog-3.jpg / "Civil Law" / Emily Carter / June 12, 2025 / "Understanding Civil
Rights In Modern Society."

### `section-contact-4.tf-spacing-1.pt-0`
`.tf-container > .wrap.tf-grid-layout.lg-col-2.gap-0`: `.left` (info) + `form.form-legal-consultation`.
- left: heading-section.d-grid.gap_16 [sub "Free Consultation" (text-label text_muted letter-spacing-1 text-uppercase
  lh-16 wow fadeInUp), h4.split-text.effect-right "Comprehensive Expert Legal Solutions For <span>Every Case</span>",
  p.text-body-default.wow.fadeInUp data-wow-delay=".2s"]; ul.list-check.d-grid.gap_8.wow.fadeInUp data-wow-delay="0.4s"
  3 li (icon-Check): "Comprehensive Legal Case Strategy." / "Expert Legal Litigation Guidance." / "Precise Legal
  Contract Preparation."; ul.list.mb_12.d-grid.gap_12.wow.fadeInUp data-wow-delay="0.6s" 3 li (icon-MapPinLine +
  icon-PhoneCall + icon-Envelope): địa chỉ, phone, email; div.wow.fadeInUp data-wow-delay="0.8s" > a.hover-underline-link
  "Open Map" href "#".
- form: h4.text-center.text_white.mb_20.split-text.effect-right "Free Legal Consultation"; tf-grid-layout.md-col-2.gap_20.mb_20
  [Name (text) + Email (email)]; tf-grid-layout.md-col-2.gap_20.mb_20 [Phone (number) + Date (type="date" + icon-CalendarBlank)];
  NiceSelect "Type of Legal Issue" (SỬA option: gốc "tireRotation/brakeCheck" là carservices lọt vào -> đổi
  thành: "Civil & Family Law" / "Corporate & Business Law" / "Criminal Defense"); textarea "Additional Notes" 4 rows;
  button.tf-btn.btn-hover-animate-2.btn-bg-white-3.rounded-0.w-full.btn-px-32 "Get A Free Quote" (+ span.bg-effect).
  onSubmit preventDefault. NiceSelect bằng state React (component NiceSelect.tsx đã có).

## VERIFY (Playwright, cổng KHÔNG dùng 5060/5061)
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, ảnh, font Merriweather cho h2, nền tối đúng.
- Hero: 3 slide autoplay; thumbs đồng bộ (slide active làm thumb active); parallax ảnh nền cuộn lệch; effect-content-
  slide chạy lại khi đổi slide; KHÔNG có .swiper-button-* mặc định.
- Pricing tf-sw-mobile: ≤575px bật Swiper (1 slide, dots), ≥576px tắt Swiper (3 cột CSS); đổi tab
  Monthly/Yearly đổi giá đúng; thanh trượt tab đúng vị trí.
- Testimonial: nav prev/next nằm trong col-lg-6 phải; fade autoplay; slide 2-3 hiện nội dung đã sửa.
- Banner: nội dung đã sửa ("Get straight answers..."); parallax ảnh nền khi cuộn.
- Insights: 3 bài, link trỏ đúng /blog-detail/{slug}, dots bấm được.
- Contact: NiceSelect có 3 option luật pháp, input date có icon, submit không load trang.
- Rò rỉ CSS: màu/font h2 ở / và /demo-lawyer khớp HTML gốc tương ứng.
- Menu: quét link /demo-lawyer depth 1: Pages/Services/Project/Blog/Contact -> 200 đúng trang corporate;
  không còn ".html"; Home <niche khác> = 404 dự kiến.
- npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả bọc CSS; hook/component mới (thumbs Swiper, tf-sw-mobile nếu chưa
có); nội dung đã sửa (banner "car care" -> legal, testimonial slide 2-3 farming -> legal, dropdown "tireRotation"
-> legal options); kết quả đo từng điểm; việc chưa xong.