Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "corporate" (route "/"). Toàn bộ chi
tiết dưới đây đã được XÁC MINH bằng cách đọc trực tiếp CSS/JS gốc và đo
bằng Playwright trên chính file HTML gốc — không phải suy đoán. Làm ĐÚNG
theo các con số/hành vi này.

## 1. Cấu trúc DOM bắt buộc (GSAP ScrollSmoother)

demo-corporate/index.html dùng gsap.min.js + ScrollSmoother.min.js +
ScrollTrigger.min.js + SplitText.min.js (xác nhận qua script tag, không
phải đoán). Cấu trúc bắt buộc:
- header "style-default header-fixed" — NẰM NGOÀI #smooth-wrapper
- #smooth-wrapper > #smooth-content chứa: header "style-default" (bản
  thường) + toàn bộ nội dung trang + footer



2 header có NỘI DUNG GIỐNG HỆT NHAU (đã diff xác nhận, không lệch 1 ký
tự) — dùng 1 component components/layout/demo-corporate/Header.tsx nhận
prop `fixed?: boolean`, KHÔNG viết trùng 2 lần.

layout.tsx của route group (demo-corporate) dựng đúng cấu trúc
#smooth-wrapper/#smooth-content này bọc {children}.

## 2. Breakpoint responsive header (ĐÃ ĐO THẬT bằng Playwright)

- Tại width ≥ 992px: `.main-menu` (nav desktop) hiện, `.mobile-button`
  (hamburger) ẩn.
- Tại width ≤ 991px: `.main-menu` ẩn hẳn (display:none — không phải chỉ
  che khuất), `.mobile-button` hiện.
- Đây CHÍNH XÁC là mốc "lg" (991px max / 992px min) trong bảng breakpoint
  ở master-workflow.md — dùng CSS media query thuần
  `@media (max-width: 991px)` để ẩn nav desktop, KHÔNG cần JS đo
  window.innerWidth để làm việc này (khác với trường hợp
  horizontal-accordion phức tạp ở dự án Agentra).
- Riêng nút "Get In Touch" (.tf-btn) ẨN THÊM ở breakpoint "md" (≤767px),
  ẩn sớm hơn cả main-menu — đây là hành vi RIÊNG của style-default, giữ
  đúng.

## 3. Dropdown submenu desktop — CSS THUẦN, không cần JS

Đã xác nhận trong _header.scss: submenu mở bằng CSS `:hover` thuần
(transform: scaleY(1); opacity:1; visibility:visible khi hover vào `<li>`
cha). KHÔNG cần state React, KHÔNG cần onClick — giữ nguyên cấu trúc
HTML lồng nhau (li.has-child > ul.submenu), CSS gốc tự động xử lý hover.

## 4. Header scroll behavior (header-fixed) — ĐÚNG CÔNG THỨC TỪ main.js

Hàm `headerFixed` trong assets/js/main.js (áp dụng vì header có class
"header-fixed"):
```
if (scrollTop > 300) → thêm class "is-fixed" vào .header
else → gỡ class "is-fixed"
```
Đây là ngưỡng đơn giản (threshold), KHÔNG phải kiểu direction-aware
(hiện/ẩn theo hướng cuộn) như hàm `headerSticky` (dùng cho các niche
khác có class "header-sticky", KHÔNG áp dụng cho corporate).

Viết hook `useHeaderFixed.ts` (đặt trong src/hooks/, dùng chung được cho
niche khác nếu sau này gặp lại đúng cơ chế "header-fixed" — kiểm tra
trước khi tái dùng, không giả định): dùng useState + useEffect lắng nghe
scroll, threshold 300px, trả về boolean `isFixed` để thêm/bớt class
"is-fixed" vào header ngoài (bản fixed).

KHÔNG nhầm với hàm `headerSticky` (dùng class "is-sticky", direction-aware)
— đó là cơ chế của NICHE KHÁC, không áp dụng ở đây.

## 5. Hiệu ứng hover đổi chữ menu (Splitting.js) — CẦN JS THẬT, không phải CSS suông

Đã xác minh: CSS trong _header.scss dùng class `.char` với biến CSS
`--char-index` (transition-delay stagger theo từng ký tự) — các phần tử
`.char` này CHỈ được tạo ra khi thư viện Splitting.js thực sự chạy trên
phần tử có `data-splitting` (nó tự bọc từng ký tự vào `<span class="char">`).
Nếu không chạy Splitting, hiệu ứng opacity đổi qua lại vẫn chạy (vì đó là
CSS trên `.text` cha) nhưng KHÔNG có hiệu ứng xoay 3D so le từng ký tự
(vì thiếu `.char`).

Cài package `splitting` (npm), import CSS `splitting/dist/splitting.css`
nếu cần. Trong component Header, dùng useEffect gọi
`Splitting({ target: '.toggle .text[data-splitting]' })` sau khi mount
(client component, "use client"). Giữ đúng markup gốc: mỗi link menu có
2 `<span class="text" data-splitting>` chứa CÙNG 1 text (bản để hiện +
bản để hiện khi hover).

## 6. Nội dung Menu (giữ nguyên, đã xác nhận đầy đủ)

Desktop:
- Demos (mega-menu): ĐÚNG 12 demo sau, theo ĐÚNG thứ tự này (đã xác nhận
  từ HTML gốc, KHÔNG phải 12 demo đầu của danh sách mobile 20 — đây là 1
  tập chọn lọc riêng, có nhảy cóc bỏ qua nhiều niche ở giữa):
  1. Home Corporate → "/" (ảnh home-demo-1.jpg)
  2. Home Agency → "/demo-agency" (home-demo-2.jpg)
  3. Home Insurance → "/demo-insurance" (home-demo-3.jpg)
  4. Home Medical → "/demo-medical" (home-demo-4.jpg)
  5. Home Restaurant → "/demo-restaurant" (home-demo-5.jpg)
  6. Home AI Tech → "/demo-aitech" (home-demo-6.jpg)
  7. Home AI Content Writer → "/demo-aicontentwriter" (home-demo-7.jpg)
  8. Home SaaS → "/demo-saas" (home-demo-8.jpg)
  9. Home Health Coach → "/demo-healthcoach" (home-demo-9.jpg)
  10. Home Spa Salon → "/demo-spasalon" (home-demo-10.jpg)
  11. Home Lawyer → "/demo-lawyer" (home-demo-11.jpg)
  12. Home Charity → "/demo-charity" (home-demo-12.jpg)
  + nút "View all demos (20)" → tái dùng DemoQuickModal đã build ở trang
  landing nếu hợp lý, hoặc link đơn giản "/landing#demos" nếu phức tạp.
- Pages (dropdown): About Us→/about-us, Our Team→/our-team, Team
  Detail→/team-detail, Carrer→/carrer, Carrer Detail→/carrer-detail,
  FAQs→/faqs. BỎ mục "404 Error" khỏi menu (Next.js dùng not-found.tsx
  tự động, không cần link).
- Services (dropdown): Services→/services, Services Detail→/service-detail
- Project (dropdown): Portfolio→/portfolio, Portfolio Detail→/portfolio-detail
- Blog (dropdown): Blog Full Width→/blog-full-width, Blog With
  Sidebar→/blog-with-sidebar, Blog Detail→/blog-detail
- Contact→/contact
- Nút "Get In Touch"→/contact

Mobile (offcanvas "menu-mobile") — ĐỦ 20 niche (KHÁC hẳn danh sách
desktop ở trên, không phải tập con/superset đơn giản), ĐÚNG THỨ TỰ sau
(đã xác nhận từ HTML gốc, mục id="dropdown-menu-one"):
  1. Corporate → "/" (active mặc định)
  2. Agency → "/demo-agency"
  3. Insurance → "/demo-insurance"
  4. Medical → "/demo-medical"
  5. Restaurant → "/demo-restaurant"
  6. AI Tech → "/demo-aitech"
  7. AI Content Writer → "/demo-aicontentwriter"
  8. SaaS → "/demo-saas"
  9. Health Coach → "/demo-healthcoach"
  10. Spa Salon → "/demo-spasalon"
  11. Construction → "/demo-construction"
  12. Coworking Space → "/demo-coworkingspace"
  13. Garden Landscaping → "/demo-gardenlandscaping"
  14. Car Service → "/demo-carservices"
  15. Charity → "/demo-charity"
  16. Architechture → "/demo-architechture"
  17. Logistics → "/demo-logistics"
  18. Solar Energy → "/demo-solarenergy"
  19. Agriculture farming → "/demo-agriculturefarming"
  20. Lawyer → "/demo-lawyer"

  Pages/Services/Project/Blog trong mobile: cùng nội dung desktop ở
  trên, dạng accordion (chỉ 1 mục mở tại 1 thời điểm hoặc mở độc lập —
  kiểm tra lại class "collapse"/"show" ban đầu trong HTML gốc để xác
  định đúng hành vi mặc định, dùng hook useAccordion).

Tách data vào src/data/demo-corporate/menu.ts, có ít nhất 2 mảng riêng:
`desktopDemosFeatured` (12) và `mobileDemosFull` (20) — KHÔNG dùng
chung/cắt bớt 1 mảng cho cả 2 nơi vì nội dung thực sự khác nhau.

## 7. Offcanvas mobile — thay Bootstrap JS bằng React state

`data-bs-toggle="offcanvas"` / `data-bs-toggle="collapse"` gốc dùng
Bootstrap JS thuần — thay bằng useState (open/close cho offcanvas, và
Set/index cho từng accordion item con).

## Sau khi xong — checklist verify (dùng Playwright nếu nghi ngờ, đừng chỉ nhìn 1 kích thước)

- Ở ≥992px: main-menu hiện, mobile-button ẩn, hover Pages/Services/
  Project/Blog xổ đúng submenu (CSS hover, không cần click)
- Ở ≤991px: main-menu ẩn hẳn, mobile-button hiện, bấm mở đúng offcanvas
- Nút "Get In Touch" biến mất khi ≤767px (riêng biệt với mốc menu)
- Cuộn trang xuống quá 300px: header ngoài (bản fixed) nhận class
  "is-fixed" đúng lúc, cuộn lên trên 300px thì gỡ — test bằng cách cuộn
  qua lại nhiều lần, không bị giật/nhấp nháy
- Hover vào menu chữ thấy hiệu ứng chữ xoay 3D so le từng ký tự (không
  chỉ đổi mờ/tỏ đơn giản) — xác nhận Splitting.js đã chạy đúng
  (inspect DOM thấy có `<span class="char">` bên trong `.text`)
- Mobile: Demos hiện đủ 20 niche, Pages/Services/Project/Blog accordion
  mở/đóng đúng
- Không còn phụ thuộc jQuery/Bootstrap JS