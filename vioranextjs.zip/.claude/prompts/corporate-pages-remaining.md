Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Làm 6 trang còn lại của corporate, THEO ĐÚNG THỨ TỰ, báo cáo xong trang
nào rồi mới sang trang tiếp. Nhiều component/hook TÁI DÙNG được từ các
trang đã làm (Case Studies cursor, marquee, ShowcaseGallery, uncover
reveal effect) — kiểm tra trước khi viết mới.

=====================================================================
TRANG 1 — /about-us (about-us.html) — 8 section
=====================================================================

1. section-about: 2 counter + box ảnh giữa lưới, nút "Get in Touch"→/contact.
   SỬA nội dung (đã xác nhận với người dùng — gốc dính chữ "licensed"
   không hợp corporate): đoạn "With a team of licensed experts and a
   commitment to transparency..." → "With a team of experienced
   professionals and a commitment to transparency, we're here to support
   you every step of the way."
2. section-video: video popup (tái dùng cơ chế đã build ở trang chủ) +
   marquee "Work Together/Start Now/Design Smart/Grow Faster/Build Bold"
   lồng trong section (tái dùng marquee, KHÔNG viết lại).
3. section-why: ảnh parallax (data-speed=".8") + 3 box icon. SỬA 2 box
   (đã xác nhận — gốc dính ngôn ngữ bảo hiểm):
   - Box 2: "Fast & Fair Claims" / "Streamlined process with 24/7
     support..." → "Rapid Response" / "Streamlined workflows with
     dedicated support whenever you need it."
   - Box 3: "Licensed advisors ready to guide you every step of the
     way." → "Seasoned consultants ready to guide you every step of the
     way."
   Box 1 giữ nguyên.
4. section-overview: 3 cột (counter+testimonial quote, Mission, Vision)
   — nội dung tĩnh, giữ nguyên.
5. section-service: 4 service card, TÁI DÙNG data services.ts đã tạo ở
   corporate-services-all.md (không tạo data trùng).
6. section-resume: ảnh + 4 giải thưởng/thành tích (Awwwards, CSS Design
   Awards, Clutch, 30+ Global Brands) — nội dung phù hợp, giữ nguyên.
7. section-team: 3 thành viên đầu (Maria Torres-CEO, David Cho-CTO, Amira
   Hassan-Head of Strategy) — ĐÂY LÀ SUBSET của 7 người đầy đủ sẽ có ở
   Trang 2, dùng chung data teamMembers.ts (tạo ở Trang 2), lấy 3 người
   đầu.
8. wrap-partner: marquee logo — tái dùng.

=====================================================================
TRANG 2 — /our-team (our-team.html) — 3 section
=====================================================================

1. section-about-team: heading + đoạn mô tả (giữ nguyên, phù hợp
   corporate) + ảnh có hiệu ứng "uncover" (3 lát cắt mở dần khi cuộn —
   TÁI DÙNG cơ chế đã build ở service-detail.html trước đó) + 1 counter
   "120+ Expertise Employees".
2. section-team: ĐỦ 7 thành viên (Maria Torres-CEO, David Cho-CTO, Amira
   Hassan-Head of Strategy, Sofia Almeida-Director of Product, Elena
   Park-CMO, Kenji Sato-Director of Engineering, Isabelle Laurent-Head
   of People). Tạo src/data/demo-corporate/teamMembers.ts (name, role,
   image, slug) — DÙNG CHUNG cho cả Trang 1 (subset 3 người) và Trang 3
   (team-detail).
3. team-purpose-showcase: GIỐNG HỆT gallery đã build ở trang /contact
   (ShowcaseGallery.tsx) — TÁI DÙNG THẲNG, không viết lại.
4. wrap-partner: tái dùng.

=====================================================================
TRANG 3 — /team-detail/[slug] (team-detail.html) — ROUTE ĐỘNG
=====================================================================

LƯU Ý: giống các trang detail trước, chỉ 1 bản nội dung demo dùng chung.
PHÁT HIỆN LỖI: tiêu đề hiển thị "Chief Executive Officer" nhưng đoạn mô
tả lại viết "Maria Torres is the Chief Marketing Officer" — mâu thuẫn
chức danh ngay trong demo gốc. SỬA: bỏ hẳn cụm "Chief Marketing Officer"
khỏi đoạn mô tả, đổi thành chung chung không nêu chức danh cụ thể: "...
where they lead strategic initiatives, cross-functional collaboration,
and drive measurable impact across the organization. With over 12 years
of experience in B2B technology and enterprise communications, they have
a proven track record of building high-performing teams and launching
campaigns that drive measurable business impact." (đổi "she/her" thành
"they/their" vì giờ dùng chung cho mọi thành viên, không riêng Maria).

- Title/role/ảnh: lấy đúng theo slug (tra teamMembers.ts)
- Ảnh có "fixed-thumb" sticky khi cuộn (data-startoffset="450" — đọc
  đúng cơ chế offset này trong CSS/JS gốc)
- Quote, thông tin liên hệ (địa chỉ/whatsapp/linkedin — href="#" giữ
  nguyên), "Areas of Expertise" (5 mục) — dùng CHUNG demo tĩnh cho MỌI
  slug (đúng thực tế nguồn).
- wrap-partner: tái dùng.

Route "/team-detail/[slug]/page.tsx", generateStaticParams theo 7 slug
trong teamMembers.ts.

=====================================================================
TRANG 4 — /carrer (carrer.html)
=====================================================================

- section-carrer: heading (SỬA LỖI GÕ THẬT trong HTML gốc: "Oin The Team
  Behind Industry-Changing Work" → "Join The Team Behind
  Industry-Changing Work") + ảnh "uncover" (tái dùng cơ chế reveal) + đoạn
  "Why Work With Us?" + 5 job listing (số thứ tự 01-05, tên vị trí,
  phòng ban, "(02 Open Roles)", link → /carrer-detail/[slug]).
- section-cta-5: tái dùng.

Data: src/data/demo-corporate/jobs.ts — 5 job (title, department, slug).
Job titles: Senior Product Manager (Product), Full-Stack Developer
(Engineering), Strategy & Insights Analyst (Business Strategy), Brand &
Communications Specialist (Marketing), Customer Success Manager (kiểm
tra lại phòng ban thật của job thứ 5 trong HTML gốc, đọc kỹ trước khi
điền).

=====================================================================
TRANG 5 — /carrer-detail/[slug] (carrer-detail.html) — ROUTE ĐỘNG
=====================================================================

LƯU Ý: 1 bản demo dùng chung cho cả 5 job (nội dung "Full Stack
JavaScript Developer" — GIỮ NGUYÊN y hệt cho mọi slug, không tự viết
riêng cho từng job, đúng thực tế nguồn).

- Title: lấy theo slug (tra jobs.ts) — CHỈ đổi title/breadcrumb, phần
  thân bài (About The Role, What You'll Do, What We're Looking For, Why
  Join Us, How To Apply) dùng chung tĩnh.
- Ảnh nền có hiệu ứng parallax (class "parallax-container"/
  "parallax-image" — đọc đúng cơ chế parallax.js gốc, có thể khác cơ chế
  "data-speed" đã dùng ở nơi khác, kiểm tra kỹ).
- Sidebar bên phải: thông tin cố định (Experience/Working Hours/
  Workdays/Salary/Openings/Apply By) — dùng chung tĩnh.
- section-cta-5: SỬA nội dung (đã xác nhận — gốc dính chữ AI Content
  Writer "Say goodbye to writer's block..."): đổi đoạn mô tả thành "Ready
  to bring your talent and ambition to a team that values impact?
  Explore this opportunity and take the next step in your career."

Route "/carrer-detail/[slug]/page.tsx", generateStaticParams theo 5 slug
trong jobs.ts.

=====================================================================
TRANG 6 — /faqs (FAQs.html)
=====================================================================

Nội dung SẠCH, không có lỗi niche — giữ nguyên 100%.

- Cột trái: heading "fixed-thumb" (sticky khi cuộn qua danh sách bên
  phải — TÁI DÙNG cơ chế sticky đã dùng ở portfolio.html/blog-detail).
- Cột phải: accordion 9 câu hỏi, CHỈ 1 CÂU MỞ TẠI 1 THỜI ĐIỂM (khác
  Footer — đây cùng cơ chế FAQ single-open đã có pattern từ dự án Agentra
  trước, TÁI DÙNG hook useAccordion single-open nếu đã có, tạo mới nếu
  viora chưa có). Câu 1 (Q1) mở sẵn mặc định.

Data 9 câu hỏi tách vào src/data/demo-corporate/faqs.ts.

=====================================================================
SAU KHI XONG CẢ 6 TRANG
=====================================================================

Playwright so sánh với HTML gốc cho từng trang:
- Nội dung đã sửa (about-us x3, team-detail x1, carrer x1 lỗi gõ,
  carrer-detail x1) hiển thị đúng bản mới, không còn dấu vết nội dung
  sai niche
- Hiệu ứng uncover/parallax/sticky hoạt động đúng ở từng trang dùng
- FAQ accordion chỉ 1 câu mở tại 1 thời điểm, Q1 mở sẵn
- 7 team member card link đúng team-detail/[slug] tương ứng
- 5 job link đúng carrer-detail/[slug] tương ứng
- Không phụ thuộc jQuery/Bootstrap JS, build production pass