Đọc CLAUDE.md và .claude/prompts/master-workflow.md (mục 8) trước khi
bắt đầu. Làm ĐỦ CẢ 3 PHẦN dưới đây, THEO ĐÚNG THỨ TỰ (phần 1 trước vì có
thể tự sửa luôn nhiều lỗi ở phần 3).

=====================================================================
PHẦN 1 — SỬA TẬN GỐC LỖI CASCADE CSS (Bootstrap đè lên theme)
=====================================================================

NGUYÊN NHÂN: src/app/layout.tsx nạp Bootstrap CSS (và swiper/animate/
icomoon) qua thẻ <link> THƯỜNG trong <head>:
  bootstrap.css, bootstrap-select.min.css, swiper-bundle.min.css,
  animate.css, icomoon/style.css

Trong khi src/styles/app.scss (chứa reset.scss, component...) được
Next.js tự bundle theo cơ chế riêng. THỨ TỰ THẬT giữa 2 nguồn này KHÔNG
ĐƯỢC ĐẢM BẢO → Bootstrap có sẵn `a { text-decoration: underline }` có
thể đè lên `a { text-decoration: none }` của theme, và tương tự với
nhiều phần tử khác (h1-h6 margin, button, ul/li...).

BẰNG CHỨNG: app.scss đã có 1 đoạn vá tạm (`body { ... !important }` với
comment nói rõ vấn đề thứ tự load) nhưng CHỈ vá cho body, chưa vá cho
các phần tử khác — cách vá này không triệt để.

SỬA TẬN GỐC:
1. Copy các file CSS trên (trong public/assets/css/ và
   public/assets/icons/icomoon/style.css) vào src/styles/vendor/, đổi
   đuôi .css → .scss, giữ nguyên nội dung.
2. Trong app.scss, @use các file vendor này ĐẦU TIÊN (trước "abstracts"
   và "reset"), để đảm bảo Bootstrap luôn load TRƯỚC theme reset theo
   đúng thứ tự source code — khớp đúng thứ tự trong HTML gốc (bootstrap
   load trước styles.css).
3. Xóa các thẻ <link> tương ứng đã chuyển sang SCSS khỏi layout.tsx.
4. Xóa đoạn vá !important tạm cho body (không cần nữa).
5. Rà soát xem còn <link> CSS nào khác trong layout.tsx cần chuyển
   tương tự không.

=====================================================================
PHẦN 2 — CHUẨN HOÁ TRANSITION CHO MỌI ACCORDION/COLLAPSE
=====================================================================

Rà soát TOÀN BỘ dự án tìm mọi nơi có hành vi accordion/collapse:
`grep -rln "useState.*[Oo]pen\|Accordion\|Collapse\|collapse" src/`
(mobile nav offcanvas ở cả 20 niche, Footer accordion, FAQ nếu có...)

Chuẩn hoá TẤT CẢ về 1 kỹ thuật CSS DUY NHẤT (tạo 1 class/hook dùng
chung, không để mỗi niche viết riêng):
  .collapse-content {
    display: grid;
    grid-template-rows: 0fr;
    transition: grid-template-rows 0.3s ease;
    overflow: hidden;
    &.is-open { grid-template-rows: 1fr; }
    > * { min-height: 0; overflow: hidden; }
  }

Giữ đúng hành vi logic gốc (single-open hay multi-open độc lập tuỳ loại
— KHÔNG đổi hành vi, CHỈ thêm transition mượt).

Ghi vào master-workflow.md tên hook/class chuẩn để các niche làm SAU tự
động dùng đúng, không lặp lại lỗi thiếu transition.

=====================================================================
PHẦN 3 — AUDIT TOÀN BỘ SECTION TRANG CHỦ ĐÃ LÀM (corporate + agency)
=====================================================================

ĐÂY LÀ PHẦN QUAN TRỌNG NHẤT — không chỉ sửa CSS, phải ĐỐI CHIẾU TỪNG
SECTION đã code với HTML gốc bằng Playwright (mở cả 2 bên song song,
đúng viewport, đợi animation/lazy-load xong), liệt kê CHÍNH XÁC từng
khác biệt, không phỏng đoán.

Với /demo-agency (route "/demo-agency") và / (corporate), kiểm tra ĐỦ
TỪNG SECTION theo đúng danh sách đã định nghĩa lúc phân tích:

corporate (8 section): Hero slider, About (video+parallax+counter),
Services grid, Case Studies (custom cursor), CTA, Testimonial (Swiper
thumbs đồng bộ), Insights/Blog (Swiper responsive), Newsletter.

agency (6 section): Hero banner (ảnh tĩnh+parallax), About (đổi màu
chữ+counter), Services numbered (hover-reveal ảnh), Our Project (Swiper+
custom cursor), Resume (tab hover+marquee lồng), Testimonial (Swiper
thumbs đồng bộ).

Với MỖI section, kiểm tra và báo cáo cụ thể (không chung chung):
- Bố cục (grid/flex, khoảng cách, thứ tự phần tử) có khớp không
- Ảnh có đúng, đúng kích thước, không vỡ không
- Animation/hiệu ứng có chạy đúng không (fade, parallax, counter,
  custom cursor, hover đổi ảnh, Swiper thumbs đồng bộ...)
- Responsive ở vài breakpoint chính (giống bảng mục 3 master-workflow)
- Text/nội dung có khớp không (kể cả những chỗ có lỗi content cố ý giữ
  nguyên như tên trùng lặp — xác nhận vẫn đúng như quyết định trước)

SỬA từng lỗi tìm được, không chỉ liệt kê rồi để đó.

=====================================================================
SAU KHI XONG CẢ 3 PHẦN
=====================================================================

- Build production pass
- Playwright xác nhận: link không gạch chân, accordion mượt, section
  khớp HTML gốc ở cả corporate và agency
- Báo cáo tổng kết: đã sửa bao nhiêu lỗi, còn lỗi nào chưa sửa được (kèm
  lý do) — không tự nhận "xong hoàn toàn" nếu còn nghi ngờ