Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "charity" (route "/demo-charity"). Đã
XÁC MINH bằng đọc trực tiếp demo-charity/index.html — KHÔNG có bug nội
dung, 2 bản header giống hệt nhau.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer.

2 header "style-14 header-sticky bg-white" (ngoài) / "style-14" (trong) —
NỘI DUNG GIỐNG HỆT NHAU. Cơ chế scroll: header-sticky → `useHeaderSticky`
(TÁI DÙNG, đã có sẵn). Breakpoint: `<nav class="main-menu style-2
xl-hide">` → mốc "xl" (1199/1200), ĐÚNG như bảng mục 1.

LƯU Ý cấu trúc DOM RIÊNG của style-14 (khác các niche trước): header-inner
KHÔNG bọc trong `tf-container` (chỉ có `<div class="header-inner">` trực
tiếp — layout padding riêng xử lý trong `_header.scss &.style-14`). Có 1
`<div class="wrap d-flex align-items-center">` bọc CẢ nav VÀ header-right
lại với nhau (khác cấu trúc thường thấy nav/header-right là 2 sibling
trực tiếp của header-inner) — giữ đúng div "wrap" này khi dựng JSX.

## 2. Header-right — KHÔNG có search/cart icon, có box điện thoại

KHÁC các niche trước: `.nav-icon-list` KHÔNG tồn tại ở style-14. Thay vào
đó `.header-right` chỉ có:
```
<div class="header-contact sm-hide">
  <div class="icon"><i class="icon-PhoneCall"></i></div>
  <div>
    <div class="text-button text_white">Or Call Us:</div>
    <div class="text-button text_white">1-555-678-8888</div>
  </div>
</div>
```
ẩn ở breakpoint "sm" (≤575px, class `sm-hide`) — KHÔNG phải CTA button,
chỉ là block text tĩnh, không cần Link/onClick. Không có CTA nút bấm nào
khác trong style-14 header (không giống các niche khác có "Get In
Touch"/"Get A Quote").

## 3. Menu nội dung — TỰ TRỎ VỀ CHÍNH MÌNH ở demo #12 (không phải bug)

12 demo mega-menu: 11 demo đầu y hệt thứ tự chuẩn các niche khác
(Corporate...Lawyer), NHƯNG demo #12 "Home Charity" trỏ `index.html`
(tương đương route "/demo-charity", TỰ TRỎ VỀ CHÍNH NÓ) thay vì thường là
"../demo-charity/index.html" như khi xem từ niche khác — đây là hành vi
ĐÚNG/mong đợi (giống cách "Home Corporate" tự trỏ "/" khi đứng ở chính
trang corporate), KHÔNG phải bug cần sửa, `desktopDemosFeatured` dùng
`href: "/demo-charity"` bình thường cho mục #12 là đủ.

Pages/Services/Project/Blog/Contact — dùng đúng route corporate như mọi
niche index-only khác, không có bug.

Mobile offcanvas (`#menu-mobile`, KHÔNG có class "style-dark" — khác
carservices) đủ 20 niche, đúng thứ tự chuẩn, "Charity" tự active ở đúng vị
trí. 5 nhóm accordion Demos/Pages/Services/Project/Blog, Contact link
thẳng cuối. Modal "View all demos": link "/landing#demos".

Logo: `logo-charity.svg` (167x52 header, 193x44 mobile).

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- KHÔNG có icon search/cart nào render (đã bỏ đúng theo HTML gốc)
- Header-contact (số điện thoại) hiện, ẩn đúng ở ≤575px (sm)
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: Demos đủ 20 (không có class "style-dark" trên offcanvas), mọi
  link đúng route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
