Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Làm 3 trang blog của insurance, THEO ĐÚNG THỨ TỰ, báo cáo xong trang nào
rồi mới sang trang tiếp theo:

=====================================================================
TRANG 1 — /demo-insurance/blog-list (blog-list.html) — CÓ SIDEBAR
=====================================================================

5 blog-item dạng danh sách dọc (col-lg-8) + sidebar (col-lg-4).

SỬA LỖI LINK: TẤT CẢ link đang trỏ "blogdetail.html" (THIẾU DẤU GẠCH
NỐI — tên file THẬT là "blog-detail.html", đây là lỗi gõ thật) → sửa
thành đúng route "/blog-detail/${slug}".

SỬA NỘI DUNG MÔ TẢ (đã xác nhận theo tinh thần xử lý Lorem Ipsum như đã
làm ở service-detail — đây là placeholder CHƯA VIẾT, không phải lựa chọn
nội dung): mỗi bài hiện đang có "Sed ut perspiciatis, unde omnis iste
natus error..." → viết 1 câu mô tả ngắn thật sự khớp với từng tiêu đề
(tiêu đề giữ nguyên, đã phù hợp insurance):
1. "Generate better protect options now" (tag Life Insurance) → "Discover
   flexible life insurance options designed to protect your family's
   future, no matter what tomorrow brings."
2. "Enable smarter risk shielding tech" (tag Health Insurance) → "See how
   modern tools are making it easier to assess risk and choose the right
   health coverage for you and your family."
3. "Form innovative protect plans today" (tag Underwriting) → "Learn how
   our underwriting process creates fair, personalized plans built
   around your unique situation."
4. "Promote clear policy guidance tools" (tag Insurance Tips) → "Get
   practical tips on reading your policy, understanding your coverage,
   and avoiding common insurance mistakes."
5. "Introduce modern protect features" (tag Critical Illness) → "Explore
   new critical illness coverage features designed to give you faster
   support when you need it most."

SỬA sidebar author: "Linda Parker - Cardiologist at Viora" → "Linda
Parker - Senior Insurance Advisor at Viora" (giống cách đã sửa ở
service-detail, đồng nhất).

Sidebar Categories (Risk Assessment/Personal Accident/Critical
Illness/Home Insurance/Business Insurance) — PHÙ HỢP, giữ nguyên.

Sidebar Latest Posts (3 bài, link cũng bị lỗi "blogdetail.html" tương tự
— sửa đồng bộ) — tiêu đề các bài này PHÙ HỢP insurance, giữ nguyên tiêu
đề, không cần viết mô tả (chỉ hiện tiêu đề + tác giả + ngày).

Data 5 bài tách vào src/data/demo-insurance/blogPosts.ts (title, excerpt,
tag, author, date, image, slug).

=====================================================================
TRANG 2 — /demo-insurance/blog-grid (blog-grid.html) — KHÔNG SIDEBAR
=====================================================================

Lưới 6 blog-item (lg-col-3, KHÔNG có mô tả, chỉ ảnh+tag+meta+tiêu đề) —
NỘI DUNG SẠCH, link ĐÚNG "blog-detail.html" (có gạch nối, không lỗi).
Đọc đúng 6 tiêu đề trong HTML gốc, tách data riêng
src/data/demo-insurance/blogGridPosts.ts (CÓ THỂ trùng 1 phần nội dung
với blogPosts.ts của Trang 1 nếu HTML gốc dùng chung ảnh/tiêu đề — kiểm
tra lại, nếu trùng thì tái dùng chung 1 nguồn data, không tạo trùng).
Sửa link trỏ "/blog-detail/${slug}".

=====================================================================
TRANG 3 — /demo-insurance/blog-detail/[slug] (blog-detail.html) — ROUTE ĐỘNG + VIẾT LẠI NỘI DUNG
=====================================================================

ĐÃ XÁC NHẬN với người dùng: nội dung gốc Y HỆT bài blog đã gặp ở
corporate (nói về "Medical services", testimonial "property management
services", đoạn "Inside the enterprise") — KHÔNG liên quan bảo hiểm.
VIẾT LẠI toàn bộ, giữ nguyên cấu trúc kỹ thuật (tag, title, meta
Author/Post Date/Comment, 2 đoạn mở đầu, quote, 2 block "passive", tags,
share, prev/next):

- Tag: "HEALTH CARE" → "INSURANCE TIPS"
- Title: GIỮ "Empower smart coverage solutions now" (đã phù hợp, khớp
  đúng bài đầu tiên trong blogPosts.ts) — LẤY ĐỘNG theo slug (tra
  blogPosts.ts, không hardcode).
- Đoạn mở đầu 1: "Understanding your insurance options can feel
  overwhelming, but having the right coverage is one of the most
  important steps you can take to protect your health, home, and
  financial future."
- Đoạn mở đầu 2: "Whether you're insuring your family, your property, or
  your business, choosing a plan that truly fits your needs starts with
  knowing what's available and how each option works."
- Block 1 — heading "Trusted Care Close to Home" → "Coverage You Can
  Count On": "A good insurance plan isn't just about paying claims —
  it's about having a partner who understands your situation and
  responds quickly when it matters most."
- Quote: "\"Switching to this insurance provider was one of the best
  decisions we made. Their team made the entire process simple,
  transparent, and stress-free.\"" — giữ tên tác giả trong HTML gốc, đổi
  chức danh "CEO Avitex" → "Small Business Owner".
- Block 2 — heading "Looking Inward To Grow Outward" → "Choosing The
  Right Plan For You": "Every policy should be tailored to the person
  behind it. Our approach starts with listening — understanding your
  lifestyle, your risks, and your goals — before recommending any
  coverage.<br>At the end of the day, the best insurance plan is one
  that gives you genuine peace of mind, not just paperwork."
- Tags: "CompanyCulture"/"EnterpriseInsights" → "InsuranceTips"/
  "CoverageGuide".
- Comment/Reviews: GIỮ NGUYÊN (nội dung demo tĩnh, không liên quan niche
  cụ thể, phù hợp chung).

SỬA prev/next (tf-article-navigation): HTML gốc trỏ "single-post-1.html"
(KHÔNG TỒN TẠI, link hỏng) — LÀM ĐỘNG THẬT dựa theo vị trí bài hiện tại
trong mảng blogPosts.ts (5 bài gốc của Trang 1, KHÔNG tính qua
blogGridPosts nếu đó là data khác) — giống cách đã làm cho
project-details/blog-details của dự án Agentra trước đây. Ẩn nút Prev
nếu là bài đầu, ẩn Next nếu là bài cuối.

Route "/blog-detail/[slug]/page.tsx", generateStaticParams theo 5 slug
trong blogPosts.ts.

=====================================================================
SAU KHI XONG CẢ 3 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Mọi link "blogdetail.html" (thiếu gạch nối) đã sửa đúng route có gạch
  nối + đúng slug
- Nội dung mô tả Trang 1 không còn Lorem Ipsum
- Nội dung blog-detail mới hiển thị đúng, không còn dấu vết "Medical
  services"/"property management"/"Inside the enterprise"
- Prev/Next tính đúng theo vị trí thực, ẩn đúng ở bài đầu/cuối
- Slug không tồn tại → 404
- Không phụ thuộc jQuery/Bootstrap JS, build production pass