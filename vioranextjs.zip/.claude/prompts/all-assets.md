Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Copy assets riêng (css + images) của TẤT CẢ 19 niche còn lại (corporate
đã copy trước đó) — chuẩn bị trước cho Giai đoạn A (làm Header đủ 20
niche) theo đúng thứ tự ưu tiên đã cập nhật ở mục 6 master-workflow.md.

Danh sách 19 niche cần copy: agency, insurance, medical, spasalon,
restaurant, aitech, healthcoach, saas, coworkingspace, aicontentwriter,
construction, gardenlandscaping, carservices, charity, logistics,
solarenergy, agriculturefarming, lawyer, architechture.

Với MỖI niche trong danh sách trên, làm đúng như đã làm cho corporate:

1. Copy `../viora/viora/demo-<niche>/css/<Niche>.css` (tên file CSS viết
   hoa chữ đầu theo đúng tên thật trong thư mục, kiểm tra lại từng niche
   vì có thể khác cách viết hoa) vào vị trí tương ứng trong project
   (theo đúng cấu trúc đã dùng cho corporate — src/styles/demo-<niche>.scss
   hoặc tương đương, giữ nhất quán).

2. Copy `../viora/viora/demo-<niche>/images/` vào
   `public/assets/images/demo-<niche>/` (tách riêng theo từng niche,
   KHÔNG trộn lẫn ảnh giữa các niche).

KHÔNG import/wire CSS này vào layout hay component nào ở bước này — chỉ
copy file vật lý vào đúng vị trí, việc import sẽ làm khi bắt đầu code
Header của từng niche cụ thể (để tránh CSS niche này đè lên niche khác
khi chưa cần).

Sau khi copy xong cả 19 niche, báo cáo:
- Tổng dung lượng đã copy thêm vào public/assets/images/
- Danh sách bất kỳ niche nào có cấu trúc css/images khác biệt bất
  thường so với corporate (ví dụ thiếu file css, hoặc có nhiều hơn 1 file
  css, hoặc thư mục images có thêm thư mục con lạ) — liệt kê rõ để xử lý
  riêng khi tới lượt niche đó.