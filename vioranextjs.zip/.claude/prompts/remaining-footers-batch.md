Đọc CLAUDE.md và .claude/prompts/master-workflow.md (đặc biệt mục 6 —
quy tắc link sai niche, và mục 7 — cơ chế accordion mobile không phải
niche nào cũng có) trước khi bắt đầu.

Làm Footer cho 18 niche còn lại (corporate và agency ĐÃ XONG — kiểm tra
lại thực tế bằng cách xem file Footer.tsx có tồn tại chưa trước khi bỏ
qua, đừng chỉ tin theo trí nhớ), THEO ĐÚNG THỨ TỰ, MỖI NICHE 1 LẦN CHẠY
RIÊNG, báo cáo xong niche nào rồi mới sang niche kế:

insurance, medical, restaurant, aitech, healthcoach, saas, spasalon,
coworkingspace, aicontentwriter, construction, gardenlandscaping,
carservices, charity, logistics, solarenergy, agriculturefarming,
lawyer, architechture

Ghi chú style Footer đã khảo sát sơ bộ (XÁC NHẬN LẠI khi code, không copy
nguyên si vì chỉ mới xem class, chưa đọc hết nội dung từng niche):
- insurance: "footer style-default" — CÓ THỂ tái dùng gần giống cấu trúc
  Footer đã build ở corporate (cùng base "style-default"), kiểm tra kỹ
  trước khi quyết định tái dùng component hay viết riêng.
- healthcoach: "footer style-default v2" — biến thể của style-default,
  kiểm tra xem chỉ khác CSS hay khác cả cấu trúc HTML.
- logistics: "footer style-default v3" — tương tự, biến thể riêng.
- Các niche còn lại đều có số style riêng (footer-style-3 đến 18),
  không trùng nhau, coi như thiết kế độc lập từng niche (giống pattern
  đã thấy ở Header).

## Quy trình cho MỖI niche

1. Đọc toàn bộ nội dung `<footer>` trong
   ../viora/viora/demo-<niche>/index.html.
2. Kiểm tra CÓ hay KHÔNG có `.tf-collapse-content`/`.footer-heading-mobile`
   (accordion mobile) — không giả định, đo bằng grep hoặc đọc trực tiếp.
   Nếu CÓ, verify breakpoint bằng Playwright (mặc định theo mục 7 là
   767/768, nhưng xác nhận lại nếu nghi ngờ khác).
3. QUÉT TOÀN BỘ LINK trong footer, đối chiếu bảng danh sách trang mục 2:
   `grep -oE 'href="[^"]*"' demo-<niche>/index.html` trong đoạn footer,
   kiểm tra từng link — cái nào trỏ sang `../demo-<niche-khac>/` mà
   CHÍNH NICHE ĐANG LÀM lại CÓ trang tương ứng → SỬA về đúng trang của
   niche đó (theo quy tắc mục 6). Cái nào trỏ sang niche khác nhưng
   niche đang làm THẬT SỰ không có trang đó → GIỮ NGUYÊN.
4. Kiểm tra thêm các lỗi khác đã từng gặp (link tự trỏ về chính nó bất
   thường, tên file sai chính tả có thật vs lỗi gõ, thuộc tính HTML hỏng
   cú pháp kiểu "h..ref") — dùng đúng cách grep đã áp dụng ở Header.
5. Component components/layout/demo-<niche>/Footer.tsx riêng cho mỗi
   niche (dùng chung được với insurance/healthcoach/logistics NẾU sau
   khi đọc kỹ xác nhận cấu trúc HTML giống corporate đủ nhiều — không ép
   buộc nếu khác biệt đáng kể).
6. Nếu có accordion mobile, dùng chung hook accordion đã có (kiểm tra
   xem là single-open hay multi-open độc lập — footer thường multi-open
   độc lập như đã xác nhận ở corporate, KHÁC FAQ single-open).

## Sau MỖI niche — checklist verify

- Build pass
- Danh sách MỌI lỗi link đã phát hiện và cách xử lý (sửa hay giữ
  nguyên, kèm lý do theo quy tắc mục 6)
  
- Nếu có accordion mobile: đúng breakpoint, các cột đóng/mở độc lập
- Không phụ thuộc jQuery

## Sau khi xong CẢ 18 niche

Tổng kết bảng: niche nào Footer xong, style dùng chung hay riêng, tổng
số lỗi link đã sửa toàn bộ dự án.