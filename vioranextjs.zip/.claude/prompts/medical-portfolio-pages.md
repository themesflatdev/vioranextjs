Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc
(../viora/viora/demo-medical/portfolio.html và portfolio-detail.html). Đọc CSS/JS gốc lấy
đúng con số; không chắc thì dừng hỏi.

Làm 2 trang trong dropdown "Project" của medical (route group (demo-medical)):
  /demo-medical/portfolio  (portfolio.html)
  /demo-medical/portfolio-detail/[slug]  (portfolio-detail.html) — route động
(Tên file medical viết ĐÚNG "portfolio", khác insurance viết "porfolio".) KHÔNG làm Blog, Contact
ở bước này. Làm trang 1 xong báo cáo rồi mới sang trang 2.
YÊU CẦU CỨNG CỦA NGƯỜI DÙNG: phải GẮN LINK detail vào menu header (desktop + mobile) và mọi chỗ
trỏ tới — xem mục "GẮN LINK" cuối prompt, làm và verify TRƯỚC khi báo "xong".

## BƯỚC 0 — Chuẩn bị
- Dùng lại: PageHeaderBanner, BannerSection (variant "inner"), useWow, useSplitTextReveal,
  hook ScrollSmoother, các hover-image đã có. Chỉ tạo mới khi chưa có.
- Dữ liệu: src/data/demo-medical/portfolio.ts — 6 item (đúng thứ tự HTML gốc), ảnh 410x308
  images/portfolio-item-N.jpg:
    1 caring-for-kids            "Caring for Kids"             Body Surgery  (filter bodySurgery)
    2 pediatric-success-stories  "Pediatric Success Stories"   Cardiology    (filter cardiology)
    3 thriving-young-patients    "Thriving Young Patients"     Dental Care   (filter dentalCare)
    4 protecting-your-childs     "Protecting Your Child’s."    Dental Care   (filter dentalCare)
    5 diabetes-controlled        "Diabetes Controlled"         Cardiology    (filter cardiology)
    6 back-to-strength           "Back to Strength"            Body Surgery  (filter bodySurgery)
  (Tiêu đề item 4 bị cụt "Protecting Your Child’s." — lỗi của theme, GIỮ NGUYÊN vì không biết bản
  đúng.) Cả 6 item có cùng đoạn mô tả: "Medical services are an essential part of our lives, offering
  care and treatment for various health " (bị cụt, không có dấu chấm — lỗi demo, giữ nguyên).

## TRANG 1 — /demo-medical/portfolio
PageHeaderBanner: crumb gốc "our portfolio" (viết thường) -> "Our Portfolio"; h2 "Our Portfolio".
main-content: section-portfolio-3, rồi banner (variant inner).
section-portfolio-3 (`section-portfolio-3 tf-spacing-1 > tf-container medium`):
- `heading-section-5 mb_56 > row align-items-center`: col-lg-6 `.left` h3.title split-text
  effect-left "Medical Cases: Challenges And Breakthroughs"; col-lg-6 `.right` p.text-body-2.
  text_secondary.desc split-text split-lines-transform "We provide a wide range of healthcare
  services, such as general medicine, treatments, surgical procedures, and rehabilitation."
- Nút lọc: `tf-filters style-2 gap_14 mb_44 overflow-x-auto mx-auto wow fadeInUp`
  (data-wow-delay 0.4s), 4 `button.btn-fillter.text-button`: View All (active, data-filter="*"),
  Body Surgery (.bodySurgery), Dental Care (.dentalCare), Cardiology (.cardiology).
- Lưới: `fillters-wrap v2 wow fadeInUp mb_60` (data-wow-delay 0.4s), mỗi item
  `portfolio-item style-2 item-fillter hover-image-2 {filterClass}`:
  `.position-relative > .img-style (img 410x308 + a.overlay-link) + a.btn-arrow(href "#") >
  i.icon-ArrowUpRight`; `.content`: a.text-button.text_primary-color.category (href "#"), a.title.mb_8.
  link.h5 (tiêu đề), p.text_secondary.mb_16. `overlay-link` VÀ tiêu đề đều trỏ
  /demo-medical/portfolio-detail/{slug}; btn-arrow và category giữ href="#" như gốc.
CƠ CHẾ LỌC GỐC (đã đọc main.js — làm đúng): thư viện ISOTOPE v3.0.6, cấu hình
`{ itemSelector: ".item-fillter", layoutMode: "fitRows" }` (mặc định transition 0.4s), bấm nút ->
bỏ class active ở các nút, thêm active vào nút vừa bấm, `isotope({ filter: data-filter })`. Layout
cột lấy từ CSS gốc `.fillters-wrap` (_reset.scss ~dòng 2319: 3 cột, <=991px 2 cột, <=575px 1 cột,
--spacing-col 30/15px, --spacing-row 28px với .v2) — Isotope đặt vị trí tuyệt đối từng item.
Cách làm trong React: cài `npm i isotope-layout@3.0.6` (+ `@types/isotope-layout`) — bản vanilla,
KHÔNG cần jQuery. Tạo client component PortfolioFilterGrid.tsx: ref tới `.fillters-wrap`; trong
useEffect (import động) `new Isotope(el, {...})`; click nút -> đổi class active (state) +
`iso.arrange({ filter })`; cleanup `iso.destroy()` (chú ý React Strict Mode chạy effect 2 lần ở
dev); render đủ 6 item tĩnh, KHÔNG lọc/đổi thứ tự item bằng React (để Isotope toàn quyền style
inline); gọi `iso.layout()` sau khi ảnh tải xong/font tải xong để chiều cao đúng. Không dùng
Isotope để lọc nếu không chạy được -> báo cáo trước, đừng tự thay bằng cách khác.
SỬA LỖI TRONG HTML GỐC: item 6 ("Back to Strength", Body Surgery) có class bị gõ sai
`Body Surgery` (có dấu cách -> thành 2 class "Body" và "Surgery") nên trong bản gốc nó BIẾN MẤT
khi lọc "Body Surgery". Dùng đúng `bodySurgery` để nó hiện khi lọc Body Surgery (đúng ý định của
theme; ghi vào báo cáo cuối).

## TRANG 2 — /demo-medical/portfolio-detail/[slug]  (ROUTE ĐỘNG)
PageHeaderBanner: crumb "our portfolio" -> "Our Portfolio", h2 "Portfolio Details" (tĩnh như gốc).
main-content: block `portfolio-detail-2 tf-spacing-1` rồi banner (inner). Quy ước các trang
detail trước: HTML gốc chỉ có 1 bản nội dung demo; thân bài DÙNG CHUNG cho 6 slug, phần theo slug là
tiêu đề h3 (= tiêu đề item tra trong portfolio.ts; slug lạ -> notFound(); generateStaticParams theo
6 slug) và prev/next động.
Cấu trúc (tf-container medium): ảnh `thumb mb_40` thumb-portfolio-main.jpg 1920x512; `heading mb_40`:
ul.meta.mb_24 3 mục (Author "Jordyn Culhane", Post Date "May 18, 2025", Comment "Full-Time" — chữ
"Full-Time" là sót của theme ở MỌI niche, GIỮ NGUYÊN cho đồng nhất) + h3.font-main (tiêu đề theo
slug); `passive mb_39` 2 đoạn; `wrap-thumb d-flex gap_30 mb_40` 2 ảnh thumb-portfolio-1/2.jpg 630x512;
khối `mb_28` h4 "Trusted Care Close To Home" + 1 đoạn; `quote mb_40`; khối `mb_40` h4 + 2 đoạn;
`tag-share` (Tag + Share This Post: FacebookLogo, x-logo, instagram-logo); `tf-article-navigation
mb_60`; `reply-comment` (h4 "Comment (2)" + 2 `reply-comment-item`, avatar-2.jpg & avatar-4.jpg
60x60, 5 sao).
NỘI DUNG GỐC LÀ BẢN TRỘN: nửa trên thuộc y tế (đúng chỗ, GIỮ), nửa dưới là nội dung corporate/bất
động sản lọt vào. Áp dụng quyết định đã thống nhất ở agency/insurance (viết lại cho hợp niche, chỉ sửa
phần sai) — GIỮ NGUYÊN: ảnh, meta, đoạn mở đầu 1, khối "Trusted Care Close To Home" (heading+đoạn),
tên tác giả quote, tên/ngày/avatar/sao của 2 comment. SỬA:
- Đoạn mở đầu 2 (gốc lộn xộn, lặp "Medical services are an essential part of our lives..." hai lần,
  chữ "These are a services encompass a wide range"): "Medical services are an essential part of our
  lives, offering care and treatment for various health conditions. These services encompass a wide
  range of specialties, including primary care, pediatrics and cardiology, each delivered by
  experienced doctors with a patient-centered approach."
- Quote (gốc nói về "property management services"): "\"The care my family received was beyond what we
  expected. Every doctor and nurse was attentive, patient and professional at every step of our
  journey.\"" — giữ tên "Cheyenne Mango"; dòng chức danh gốc "CEO vilora" (sai tên, sai niche) ->
  "Parent of Patient".
- Khối cuối: heading "Looking Inward To Grow Outward" -> "Care That Continues Beyond The Clinic";
  đoạn 1: "Behind every successful recovery is a team that listens, plans and follows through — from
  the first consultation to the final check-up. Those quiet, consistent efforts are what allow us to
  deliver reliable care to every patient and family we serve."; đoạn 2: "At the end of the day, great
  healthcare isn’t built by chance. It’s built by design — one patient, one plan, one caring
  conversation at a time."
- Tags: "CompanyCulture", "EnterpriseInsights" -> "PatientCare", "MedicalCases".
- Prev/Next: gốc trỏ "single-post-1.html" (KHÔNG tồn tại) với tiêu đề corporate "Client Success
  Stories"/"Branded Impact". LÀM ĐỘNG THẬT theo vị trí slug trong portfolio.ts (6 item): Previous =
  item trước, Next = item sau, hiển thị TIÊU ĐỀ của item đó và link tới /portfolio-detail/{slug};
  ẩn Previous ở item đầu, ẩn Next ở item cuối (giữ class `ms-auto` của Next để vị trí đúng).
- Comment 1 (gốc "company open up about its internal culture"): "A truly inspiring story. It is wonderful
  to see such dedicated care and compassion from the whole medical team."; Comment 2 (gốc "Aligning
  people, process, and purpose"): "Thank you for sharing this case. Clear explanations and a caring
  approach make such a difference for families."

## GẮN LINK DETAIL — BẮT BUỘC (menu desktop + mobile, nội dung)
HTML gốc: mỗi trang con có 6 link tới 2 trang này, TẤT CẢ nằm trong MENU (3 nơi: header cố định,
header thường, offcanvas mobile). Footer và trang chủ KHÔNG có link portfolio. Sau khi có route:
1. src/data/demo-medical/menu.ts, mục dropdown "Project": nhãn gốc ghi sai "Porfolio" -> SỬA thành
   "Portfolio" (file thật đúng chính tả "portfolio.html", chỉ nhãn gõ sai), href
   /demo-medical/portfolio ; mục "Portfolio Detail" -> /demo-medical/portfolio-detail/caring-for-kids
   (slug của item ĐẦU TIÊN trong portfolio.ts; KHÔNG để trỏ route không slug — hiện link
   /demo-medical/portfolio-detail đang 404). Xác nhận cả 3 nơi render menu đều đọc cùng mảng dữ liệu;
   nơi nào hard-code thì sửa luôn (desktop hover dropdown + mobile accordion).
2. Trang /portfolio: 6 `overlay-link` + 6 tiêu đề -> /portfolio-detail/{slug} tương ứng.
3. Trang detail: Previous/Next động như trên; breadcrumb "HOME" -> /demo-medical.
4. Chạy quét link (scripts/viora-links.mjs nếu đã cài, hoặc Playwright tự viết) từ /demo-medical,
   /demo-medical/portfolio, /demo-medical/portfolio-detail/caring-for-kids, độ sâu 1: KHÔNG còn 404,
   không còn href ".html". Kiểm tra bằng Playwright cả desktop (hover dropdown Project) lẫn mobile
   (≤1199px: mở offcanvas, mở accordion Project, bấm Portfolio / Portfolio Detail) -> vào đúng trang.

## VERIFY
- So HTML gốc với Next ở 1440, 991, 575: số cột lưới (3/2/1), vị trí/chiều cao từng item (đo
  getBoundingClientRect), chiều cao container, ảnh, font, link không gạch chân.
- Lọc: View All (6 item) / Body Surgery (item 1 và 6 — item 6 đã sửa) / Dental Care (3, 4) /
  Cardiology (2, 5); chuyển lọc có animation 0.4s đúng Isotope; nút active đổi đúng.
- Detail: slug khác nhau đổi h3 + prev/next đúng, ẩn đúng ở đầu/cuối; slug lạ -> 404.
- Chuyển qua lại /demo-medical ↔ /demo-agency bằng <Link>: màu không lẫn.
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: file tạo/sửa, thư viện cài thêm, từng chỗ đã gắn link (menu x3 + nội dung) kèm kết quả
quét link, nội dung đã viết lại (nguyên văn), lỗi đã sửa (class item 6, nhãn "Porfolio"), việc chưa xong.