Đọc CLAUDE.md và .claude/prompts/master-workflow.md (đặc biệt mục 6 —
quy tắc xử lý link trỏ sai niche) trước khi bắt đầu.

Setup Footer cho niche "agency". Đã đọc kỹ toàn bộ nội dung, class
"footer-style-2" — KHÔNG có accordion mobile (không có
.tf-collapse-content), layout đơn giản: 2 cột (col-xl-7 giới thiệu +
CTA "Contact Us", col-xl-5 Quick Link + form newsletter + social icon).

## Sửa lỗi link theo đúng quy tắc mục 6

- "About" đang trỏ `../demo-corporate/about-us.html` → SỬA thành
  `/about` (agency có sẵn trang riêng)
- "Our Team" đang trỏ `../demo-corporate/our-team.html` → SỬA thành
  `/our-team` (agency có sẵn trang riêng)
- "Pricing" đang để `#` → SỬA thành `/our-pricing` (agency có sẵn trang
  riêng, không có lý do để trống)
- "Services" → `/services` (đã đúng, giữ nguyên)
- "Project" (href="portfolio.html") → `/portfolio` (đã đúng, giữ nguyên)
- "Blog" đang trỏ `../demo-corporate/blog-full-width.html` → GIỮ NGUYÊN
  trỏ sang corporate (agency không có trang blog riêng, đúng theo quy
  tắc mục 6 — mượn tạm là chủ đích chấp nhận được)
- "Contact" → `/contact` (đã đúng, giữ nguyên)

## Nội dung khác

- Email liên hệ (link lớn, hiệu ứng split-text — CHỈ giữ text, KHÔNG
  cần cài hiệu ứng split-text thật vì đã xác nhận theme không dùng
  Splitting.js runtime cho các trang niche)
- Địa chỉ + giờ làm việc (text tĩnh)
- Form newsletter: chỉ cần input + nút submit, onSubmit preventDefault
- Social icon: Facebook, LinkedIn, X, Instagram, YouTube (icon font có
  sẵn)

## Trang

Đặt <Footer /> vào layout.tsx route group (demo-agency).

## Sau khi xong

- Build pass, không lỗi
- Link About/Team/Pricing trỏ đúng về trang agency, Blog vẫn trỏ
  corporate (đúng chủ đích)
- Không phụ thuộc jQuery