Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Làm 2 trang, THEO ĐÚNG THỨ TỰ, báo cáo xong trang nào rồi mới sang trang
tiếp. CẢ 2 TRANG ĐỀU DÙNG CHUNG 1 KHỐI PRICING — xây dựng khối đó 1 LẦN
ở Trang 1 rồi TÁI DÙNG cho Trang 2, không viết 2 lần.

=====================================================================
TRANG 1 — /services (services.html)
=====================================================================

3 section, ĐÃ ĐỌC ĐỦ:

1. section-service: heading + nút "Talk To An Expert" (href="#") + 4
   service-item XEN KẼ ảnh trái/phải (class "ctl" đánh dấu item đảo
   chiều — item 1,3: ảnh trái; item 2,4: ảnh phải), mỗi item có tiêu đề/
   mô tả/3 checklist/link mũi tên, TẤT CẢ link tới /service-detail (dùng
   slug, xem mục Data bên dưới). LƯU Ý: item 4 ("Digital Marketing")
   ảnh KHÔNG bọc trong link <a> (chỉ div tĩnh) — GIỮ ĐÚNG như vậy, không
   tự thêm link cho nhất quán với 3 item kia (đây là khác biệt thật
   trong HTML gốc).

2. section-pricing — SỬA NỘI DUNG (đã xác nhận với người dùng, HTML gốc
   dán nhầm nội dung niche AI Content Writer — "Flexible Plans For Every
   Writer", gói tính theo số từ). Heading MỚI: sub "Our Pricing", title
   "Flexible Plans For Every Business", mô tả "Choose the plan that fits
   your needs — upgrade anytime as you grow." Giữ NGUYÊN cấu trúc kỹ
   thuật (tab Monthly/Yearly, 3 pricing-item, data-monthly/data-yearly
   trên 2 gói sau — cơ chế đổi giá theo tab ĐÃ CÓ SẴN pattern từ dự án
   trước, tái dùng nếu có hook usePricingTab tương tự dự án Agentra,
   viết mới nếu chưa có). Nội dung 3 gói MỚI:
   - Starter (free/tháng): "Perfect for businesses exploring strategic
     consulting for the first time." — Up to 1 discovery session/month,
     Basic market overview, Email support, Limited report access
   - Pro (data-monthly="79" data-yearly="149", có tag "Popular"): "For
     growing companies looking to scale with expert strategic guidance."
     — Unlimited consulting sessions, Dedicated account strategist,
     Quarterly performance reports, Priority support
   - Business (data-monthly="149" data-yearly="299"): "For agencies and
     enterprises managing complex, large-scale operations." — Full-
     service strategy & execution, Custom brand & marketing programs,
     Dedicated project team, API & platform integrations

3. section-cta-5 + wrap-partner (marquee) — TÁI DÙNG y hệt component đã
   build ở trang chủ/portfolio, không viết lại.

## Data

4 service, tách vào src/data/demo-corporate/services.ts (title, desc, 3
bullet, image, slug). Pricing 3 gói tách vào
src/data/demo-corporate/servicesPricing.ts (nội dung MỚI đã viết ở trên).

## Component

ServiceItemRow.tsx, PricingTabSection.tsx (tách riêng để Trang 2 tái
dùng), CTASection + Marquee (tái dùng).

=====================================================================
TRANG 2 — /service-detail/[slug] (service-detail.html) — ROUTE ĐỘNG
=====================================================================

LƯU Ý: giống các trang detail trước — HTML gốc CHỈ CÓ 1 bản nội dung
demo dùng chung cho cả 4 service. Nội dung ở đây (Business Strategy) PHÙ
HỢP corporate, GIỮ NGUYÊN, chỉ sửa duy nhất đoạn dưới đây.

5 section:
1. section-strategy: title/breadcrumb lấy theo slug (tra services.ts).
   Ảnh có hiệu ứng "uncover" (3 lát cắt che phủ ảnh, tự mở ra khi cuộn
   tới — class "uncover_slice", "section-triger") — ĐỌC ĐÚNG CSS/JS gốc
   xử lý hiệu ứng này (dạng reveal-curtain khi scroll vào view) trước
   khi code lại, không đoán. Nội dung "What We Offer" (3 box icon) dùng
   CHUNG 1 bộ tĩnh cho mọi slug (đúng HTML gốc).
2. section-expected-outcomes: ảnh có parallax (data-speed="0.7") + 3
   checklist — dùng chung tĩnh.
3. section-process: 4 tab (Discovery/Strategy/Execution/Optimization,
   tab "Strategy" active mặc định — LƯU Ý khác các trang trước, mặc định
   không phải tab đầu). SỬA đoạn mô tả (đã xác nhận, gốc ghi nhầm "...with
   the power of AI" không hợp corporate) thành: "Your growth strategy,
   delivered in 4 simple, structured steps." Cả 4 tab dùng CHUNG 1 đoạn
   mô tả demo giống hệt nhau theo HTML gốc (giữ nguyên, đây là lỗi lặp
   nội dung thông thường không phải lỗi sai niche).
4. section-pricing: TÁI DÙNG THẲNG PricingTabSection.tsx đã build ở
   Trang 1 (data giống hệt, không viết lại).
5. section-cta-5 + wrap-partner: tái dùng.

## Trang

Route "/service-detail/[slug]/page.tsx", generateStaticParams theo 4
slug trong services.ts.

## Sau khi xong cả 2 trang

Playwright so sánh với HTML gốc:
- 4 service item xen kẽ ảnh trái/phải đúng, item 4 không có link ảnh
- Pricing hiện đúng nội dung MỚI, tab Monthly/Yearly đổi giá đúng, GIỐNG
  NHAU giữa Trang 1 và Trang 2
- Hiệu ứng uncover (ảnh mở dần khi cuộn) hoạt động đúng
- Tab Process mặc định mở đúng "Strategy" (không phải tab đầu)
- Bấm từ card service → đúng route /service-detail/[slug]
- Không phụ thuộc jQuery, build production pass