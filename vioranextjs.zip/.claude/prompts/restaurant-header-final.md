Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "restaurant" (route group (demo-restaurant),
route "/demo-restaurant"). Chi tiết dưới đây đã XÁC MINH bằng đọc trực tiếp
demo-restaurant/index.html.

## 1. Cấu trúc DOM (GSAP ScrollSmoother)

demo-restaurant/index.html dùng gsap.min.js + ScrollSmoother + ScrollTrigger
+ SplitText + atropos.js (script tag xác nhận, KHÔNG có splitting.min.js —
giống mọi niche khác, chỉ CSS opacity fade).

2 header "style-5 header-sticky" (ngoài #smooth-wrapper) và "style-5" (trong
#smooth-wrapper/#smooth-content) — ĐÃ DIFF: nội dung giống hệt nhau (chỉ
khác class "header-sticky" và line-wrap). `#smooth-wrapper` có thêm class
`bg-dark-color-2` — giữ đúng class này trong HeaderSection.

Cơ chế scroll: "header-sticky" (KHÁC corporate/agency/insurance dùng
header-fixed) → dùng hook `useHeaderSticky` (đã có sẵn ở src/hooks/, direction-
aware, ngưỡng 400px, delta 10px, class "is-sticky"), KHÔNG viết lại.

## 2. PHÁT HIỆN QUAN TRỌNG: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

restaurant chỉ có 1 trang (index.html, xem master-workflow.md mục 2) —
KHÔNG có about/services/portfolio/blog riêng. HTML gốc xác nhận (cả desktop
mega-menu và mobile offcanvas): mọi link Pages/Services/Project/Blog/Contact
trỏ sang `../demo-corporate/<page>.html` (VD: about-us.html, our-team.html,
carrer.html, carrer-detail.html, FAQs.html, services.html, service-detail.html,
portfolio.html, portfolio-detail.html, blog-full-width.html,
blog-with-sidebar.html, blog-detail.html, contact.html) — TÁI DÙNG trang
thật của corporate làm nội dung demo, đây là chủ đích của theme gốc (đã ghi
vào memory, áp dụng cho toàn bộ 15 niche chỉ-có-index).

→ Trong menu.ts, các mảng pagesMenu/servicesMenu/projectMenu/blogMenu và
contactHref PHẢI trỏ tới route THẬT của corporate (`/about-us`, `/our-team`,
`/team-detail`, `/carrer`, `/carrer-detail`, `/faqs`, `/services`,
`/service-detail`, `/portfolio`, `/portfolio-detail`, `/blog-full-width`,
`/blog-with-sidebar`, `/blog-detail`, `/contact`) — KHÔNG có tiền tố
`/demo-restaurant`. Chỉ link "Home Restaurant" (mega-menu) + "Restaurant"
(mobile Demos) + logo mới trỏ `/demo-restaurant`. BỎ mục "404 Error" khỏi
Pages (trỏ ../demo-corporate/404.html trong gốc) — dùng not-found.tsx tự
động, giống quyết định đã áp dụng ở corporate.

## 3. Breakpoint responsive — mốc "lg" (991/992), giống corporate/agency

`mobile-button d-lg-none` xác nhận trong HTML — dùng CSS thuần có sẵn,
không cần JS đo viewport.

## 4. Header-right

Thứ tự: nút CTA `<a class="tf-btn style-border btn-hover-animate-border
sm-hide">Find A Table</a>` (href="#", KHÔNG trỏ đâu cả — giữ nguyên, ẨN ở
≤575px qua class "sm-hide") rồi `.mobile-button.d-lg-none`. KHÔNG có
header-contact/social icon nào ở header-right (khác insurance/agency).

Nút "View all demos" trong mega-menu có class `tf-btn btn-mega-2` (khác
"tf-btn" đơn thuần ở các niche trước) — giữ đúng class.

## 5. Menu (giữ nguyên, đã xác nhận đầy đủ, KHÔNG phát hiện bug link nào)

Desktop mega-menu Demos: 12 demo, thứ tự y hệt các niche trước, "Home
Restaurant" trỏ "/demo-restaurant" (active), "Home Corporate" trỏ "/".

Mobile — đủ 20 niche, thứ tự y hệt, offcanvas có class "style-dark". 5 nhóm
accordion Demos/Pages/Services/Project/Blog, Contact là link thẳng cuối
danh sách (trỏ /contact theo mục 2 ở trên).

Tách data vào src/data/demo-restaurant/menu.ts.

## 6. Modal "View all demos"

Dùng link đơn giản "/landing#demos" (như các niche trước).

## Sau khi xong — checklist verify

- ≥992px: main-menu hiện, mobile-button ẩn; ≤991px: ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover thuần)
- CTA "Find A Table" ẩn ở ≤575px
- Cuộn: cơ chế header-sticky (direction-aware) — cuộn xuống liên tục qua
  400px KHÔNG hiện is-sticky, cuộn ngược lên 1 đoạn (>10px) mới hiện
  is-sticky, cuộn dưới 400px luôn về trạng thái thường — test bằng
  Playwright với trang đủ cao (min-height 150vh), KHÔNG test kiểu ngưỡng
  đơn giản của header-fixed
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate (không có tiền tố /demo-restaurant)
- Không có .char nào (Splitting.js không chạy)
- Không còn phụ thuộc jQuery/Bootstrap JS
