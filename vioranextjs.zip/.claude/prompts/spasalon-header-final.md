Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "spasalon" (route group (demo-spasalon),
route "/demo-spasalon"). Chi tiết dưới đây đã XÁC MINH bằng đọc trực tiếp
demo-spasalon/index.html + _header.scss (không suy đoán).

## 1. Cấu trúc DOM (GSAP ScrollSmoother — giống các niche trước)

demo-spasalon/index.html dùng gsap.min.js + ScrollSmoother + ScrollTrigger +
SplitText, KHÔNG có splitting.min.js (giống mọi niche khác — chỉ CSS
opacity fade khi hover, không cài package splitting).

2 header "style-9 header-fixed" (ngoài #smooth-wrapper) và "style-9"
(trong #smooth-wrapper/#smooth-content) — ĐÃ DIFF, có 2 KHÁC BIỆT THẬT
(không phải chỉ xuống dòng):
- `.phone` (số điện thoại bên trái): bản fixed dùng class `text_primary`,
  bản thường dùng `text-white` (do bản thường overlay trong suốt trên nền
  hero tối, cần chữ trắng).
- Logo: bản fixed dùng `logo-spa-2.svg`, bản thường dùng `logo-spa-1.svg`
  (2 file logo khác nhau thật sự, cả 2 đã có sẵn trong
  public/assets/images/logo/).

Giữ đúng 2 khác biệt này qua prop `fixed`.

## 2. Cấu trúc ĐẶC BIỆT: logo NẰM GIỮA, menu chia 2 NỬA (style-9)

`.header-center` chứa THEO ĐÚNG THỨ TỰ: `<nav class="main-menu">` #1 (trái:
Demos mega-menu, Pages, Services) → `<a class="site-logo">` (logo, ở
GIỮA) → `<nav class="main-menu">` #2 (phải: "Porfolio" — giữ đúng lỗi
chính tả gốc, Blog, Contact). Đây là 2 phần tử `.main-menu` RIÊNG BIỆT,
không phải 1 dải liên tục — dựng đúng 2 `<nav>` trong Header.tsx, logo ở
giữa.

`.header-left.md-hide` (ngoài `.header-center`, bên trái header-inner):
box số điện thoại `icon-PhoneCall` + "1-333-345-6868" — ẨN ở ≤767px
(md-hide).

## 3. Breakpoint — SAI so với bảng khảo sát master-workflow.md, ĐÃ SỬA LẠI

Bảng master-workflow.md ghi spasalon/coworkingspace breakpoint "xl"
(1199/1200) — ĐÃ XÁC MINH SAI qua đọc trực tiếp
`assets/scss/component/_header.scss` dòng ~375-395: `.header.style-9` dùng
**`@media (max-width: 1300px)`** — một breakpoint HARDCODE RIÊNG, KHÔNG
phải mốc "xl" (1199) chuẩn trong bảng breakpoint chung (mục 3
master-workflow.md). Ở ≤1300px: CẢ 2 `.main-menu` (trong `.header-center`)
ẩn đồng thời (cùng 1 rule `.header-center { @media(max-width:1300px)
{ .main-menu{display:none} .mobile-button{display:flex} } }`, tự động ẩn
đồng bộ vì cùng chung selector cha), mobile-button hiện. KHÔNG cần thêm
CSS gì — SCSS đã copy sẵn xử lý đúng. Component chỉ cần đúng markup
(không có class d-lg-none/d-xl-none nào cần gắn thêm trên mobile-button
— khác các niche trước, style-9 tự ẩn/hiện qua CSS riêng của
`.header-center`).

CẦN BÁO LẠI: sửa dòng breakpoint của spasalon (và khả năng cả
coworkingspace, cùng gốc style-9) trong bảng mục 1 master-workflow.md từ
"xl (1199/1200)" thành "custom 1300px (KHÔNG theo bảng breakpoint chung
mục 3)" — verify lại coworkingspace khi tới lượt, KHÔNG giả định giống
hệt vì "v2" có thể chỉnh khác.

## 4. Header scroll: `header-fixed` (ngưỡng 300px) — ĐÚNG NHƯ BẢNG, tái dùng hook có sẵn

Class "header-fixed" xác nhận đúng trong HTML → dùng `useHeaderFixed`
(src/hooks/useHeaderFixed.ts), không viết lại.

## 5. Header-right: social icon (không CTA, không header-contact ở bên phải)

`.header-right`: `ul.tf-social.style-4.sm-hide` (4 icon: icon-Linkedin,
icon-XLogo-2, icon-InsLogo-fill, icon-Youtube — CÙNG bộ class với social
icon trong mobile "support", khác agency dùng bộ icon lowercase riêng cho
desktop) rồi tới `.mobile-button` (không có class d-lg-none/d-xl-none nào
— ẩn/hiện tự động qua CSS `.style-9 .mobile-button` đã nêu ở mục 3).

## 6. Menu (giữ nguyên nội dung, đã xác nhận đầy đủ, KHÔNG phát hiện bug link nào ở niche này)

Desktop — main-menu TRÁI (Demos, Pages, Services):
- Demos (mega-menu): ĐÚNG 12 demo, thứ tự y hệt các niche trước. "Home Spa
  Salon" trỏ "/demo-spasalon" (active tại trang này).
- Pages (dropdown): About Us→/about, Booking→/booking, Our
  Staffs→/staffs, Member Details→/member-detail, Our
  Testimonials→/testimonials, Calender→/calender, Packages→/packages,
  FAQs→/faqs. BỎ "404 Error" (trỏ chéo ../demo-corporate/404.html trong
  HTML gốc — dùng not-found.tsx tự động, như mọi niche trước).
- Services (dropdown): Our Services→/service, Services Detail→/service-detail

Desktop — main-menu PHẢI (Porfolio, Blog, Contact):
- Porfolio (dropdown, giữ đúng lỗi chính tả "Porfolio" trên cả label nav
  lẫn tên hiển thị): Our Portfolio→/portfolio, Portfolio
  Detail→/portfolio-detail
- Blog (dropdown): Blog List→/bloglist, Blog Grid→/bloggrid, Blog
  Detail→/blogdetail
- Contact→/contact

Mobile — ĐỦ 20 niche, thứ tự y hệt các niche trước. 5 nhóm accordion:
Demos/Pages/Services/Project(label mobile là "Project" dù desktop ghi
"Porfolio" — giữ đúng khác biệt tên gọi này, không tự đồng bộ 2 tên)/Blog.
Contact là link thẳng cuối danh sách.

Tách data vào src/data/demo-spasalon/menu.ts. TẤT CẢ href nội bộ niche
PHẢI có tiền tố `/demo-spasalon/...` (route root niche này không phải
"/"). 17 trang thật (xem master-workflow.md mục 2): index, about, contact,
faqs, booking, calender, packages, staffs, member-detail, service,
service-detail, portfolio, portfolio-detail, bloglist, bloggrid,
blogdetail, testimonials — KHÔNG tự thêm/bớt trang.

## 7. Modal "View all demos"

Có `#modalDemo` riêng trong trang này. Dùng lại giải pháp đã áp dụng ở
các niche trước: link đơn giản "/landing#demos".

## Sau khi xong — checklist verify

- ≥1301px: CẢ 2 main-menu (trái+phải) hiện đồng thời, mobile-button ẩn
- ≤1300px: CẢ 2 main-menu ẩn đồng thời, mobile-button hiện, offcanvas mở
  đúng (đo đúng mốc 1300px, KHÔNG dùng nhầm 1199/1200 như bảng khảo sát
  cũ ghi)
- Logo đổi đúng file theo trạng thái fixed/thường (logo-spa-2 vs
  logo-spa-1), màu chữ số điện thoại đổi đúng (text_primary vs text-white)
- header-left (số điện thoại) ẩn ở ≤767px (md-hide)
- Hover Pages/Services (trái) và Porfolio/Blog (phải) xổ đúng submenu
  (CSS hover thuần)
- Cuộn qua 300px: header ngoài nhận "is-fixed" đúng lúc
- Mobile: Demos đủ 20, 5 nhóm accordion đúng tên gọi
- Không có .char (không cài Splitting)
- Không còn phụ thuộc jQuery/Bootstrap JS
