Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc
(../viora/viora/demo-medical/service.html và service-detail.html).

Làm 2 trang trong dropdown "Services" của medical (route group (demo-medical)):
  /demo-medical/service  (service.html)
  /demo-medical/service-detail/[slug]  (service-detail.html)  — route động
KHÔNG làm Porfolio, Blog, Contact ở bước này. Làm trang 1 xong báo cáo rồi mới sang trang 2.
YÊU CẦU CỨNG CỦA NGƯỜI DÙNG: phải GẮN LINK detail vào header (desktop + mobile), footer và
mọi chỗ khác — xem mục "GẮN LINK" bên dưới, làm và verify TRƯỚC khi báo "xong".

## BƯỚC 0 — Chuẩn bị
- Hook/component đã có: dùng lại (useWow, useSplitTextReveal, useScrollSmoother, tab services
  của trang chủ, BenefitSection, BannerSection/BookAppointmentSection có `variant`,
  PageHeaderBanner, hook accordion 1-mục-mở + collapse transition, NiceSelect, dữ liệu
  faqs.ts). Chỉ tạo mới khi chưa có.
- Gom 7 dịch vụ vào MỘT nguồn duy nhất src/data/demo-medical/services.ts (nếu đã có mảng tab
  dịch vụ hoặc mảng option dịch vụ ở trang chủ/appointment thì GỘP về file này, tránh trùng):
    id (id tab trong HTML)      slug                  name
    generalCheckUp              general-check-up      General Check-Up
    pediatrics                  pediatrics            Pediatrics
    cardiology                  cardiology            Cardiology
    laboratoryTests             laboratory-tests      Laboratory Tests
    dermatology                 dermatology           Dermatology
    emergencyCare               emergency-care        Emergency Care
    diseaseManagement           disease-management    Disease Management
  Dùng chung cho: nhãn tab (trang chủ + trang service), dropdown "Choose Services", link
  footer, generateStaticParams của route detail.

## TRANG 1 — /demo-medical/service
PageHeaderBanner: crumb/h2 gốc ghi "our services"/"our Services" (viết thường chữ "our") ->
SỬA thành "Our Services" cho cả 2.
main-content có 4 block (thứ tự như dưới):
1. section-service-5 (variant "service") — KHÁC bản trang chủ (đã so từng dòng): class
   `section-service-5 flat-animate-tab tf-spacing-1` (KHÔNG có bg-primary-color, KHÔNG
   tf-spacing-6); heading `heading-section-5 mb_40 text-center`: tag "Our Services" + h2
   "Explore Our Main Service" (KHÔNG text_white); khối trái `tab-slide style-3 d-flex wow
   fadeInLeft` (có wow) bọc trong `.d-flex.gap_30.wrap`; icon mũi tên mỗi tab là `icon-ArrowRight`
   (trang chủ dùng icon-ArrowRight3); tab-pane dùng `box-service v2 hover-image-2` (kiểm tra bản
   trang chủ có "v2" không rồi copy đúng markup từng biến thể từ HTML gốc, đừng suy từ nhau).
   Giống trang chủ: 7 tab theo services.ts, MẶC ĐỊNH ACTIVE "Pediatrics" (tab thứ 2), cả 7 pane nội
   dung GIỐNG HỆT NHAU (sub "Cardiology", tiêu đề "Trusted Advanced Care for Heart Health", ảnh
   service-9.jpg 480x480 — lỗi demo, GIỮ NGUYÊN). Link tiêu đề + btn-arrow của pane ->
   /demo-medical/service-detail/cardiology (pane nào cũng là nội dung Cardiology). Tab bằng
   useState, giữ class active/show, không Bootstrap JS.
2. section-benefit (variant): giống BenefitSection trang chủ (bg-light-color) chỉ khác `row
   align-items-end` thay vì `align-items-center` -> thêm prop `alignItems`.
3. section-book-appointment (variant inner, KHÔNG bgLight). SỬA lỗi gõ: h2 gốc là " Appointment
   Today" (thiếu chữ đầu) -> "Schedule Appointment Today" (như mọi trang khác).
4. section-banner (variant inner).

## TRANG 2 — /demo-medical/service-detail/[slug]  (ROUTE ĐỘNG)
PageHeaderBanner: crumb "service details" -> "Service Details", h2 "Service Details" (HTML gốc tiêu
đề trang là TĨNH, không theo dịch vụ — giữ tĩnh). main-content: block `service-detail-2` rồi
banner (inner).
Quy ước các trang detail trước: HTML gốc chỉ có 1 bản nội dung demo (viết cho Cardiology); thân
bài DÙNG CHUNG cho 7 slug, chỉ phần theo slug là TÊN dịch vụ trong 2 tiêu đề h4 (tra services.ts,
slug lạ -> notFound(), generateStaticParams theo 7 slug). Với slug "cardiology" trang phải GIỐNG
HỆT bản gốc.
`service-detail-2.tf-spacing-1 > .tf-container > .row`: col-lg-4 sidebar + col-lg-8 nội dung.
- Sidebar `.tf-sidebar` gồm 3 `sidebar-item`: (a) sidebar-author: avatar
  ../assets/images/avatar/avatar-1.jpg 80x80, tên "Linda Parker", "Content writer at Viora",
  `tf-social style-2` 5 icon (messenger, x, instagram, skype, telegram — class icon-*-logo; có
  sẵn trong icomoon, href "#"); (b) sidebar-categories: tiêu đề "Categories" + 5 mục kèm số:
  Vitality Health Solutions (112), WellSpring Wellness Center (32), Harmony Family Health Medical
  (42), Evergreen Medical Center (65), PureLife Health Services (13); (c) `sidebar-item banner`:
  ảnh images/banner-sidebar.jpg 410x548, "Need Help? Call Us:" + "(1)-555-678-8888", nút "Book
  Appointment" (`tf-btn btn-hover-animate btn-bg-white` + <span class="text_primary-color">) ->
  /demo-medical/appointment. Nội dung sidebar giữ nguyên như gốc (chỉ hơi lạ, không sai niche).
  Nếu đã có component sidebar dùng chung (author/categories) từ blog niche khác thì chỉ tái dùng
  khi markup GIỐNG HỆT; khác thì viết component riêng cho trang này.
- Nội dung (col-lg-8, `.content-inner`): ảnh `thumb.mb_40` thumb-main-service.jpg 940x512; khối
  `passive.mb_40`: h4.text_primary-color.mb_16 "Professional Medical Service Of {Tên dịch vụ}",
  1 đoạn mô tả, danh sách 6 mục (icon-Check); khối `passive v2`: h4 "Advantage {Tên dịch vụ}",
  1 đoạn mô tả, `wrap-thumb flex-wrap flex-md-nowrap d-flex gap_30 mb_40` với 2 ảnh
  thumb-service-1.jpg / thumb-service-2.jpg 630x512; khối FAQ: h4 "Health Tips & Info" + accordion 4
  mục (id accordion-faq, CHỈ 1 MỤC MỞ, câu 1 mở sẵn) — tái dùng hook accordion + collapse transition
  chuẩn của dự án.
- SỬA NỘI DUNG (HTML gốc có Lorem Ipsum THẬT chưa viết — "Medicate is a long established fact...
  Lorem Ipsum is simply dummy text...", 6 mục danh sách tiếng Latin, 4 câu trả lời FAQ Lorem; còn có
  1 thẻ <li> bị thiếu </li> — React render đúng 6 <li>). Viết nội dung thật (đã áp dụng chính sách
  xử lý placeholder, không cần hỏi lại):
  * Đoạn mô tả khối 1: "At our medical center, our specialists combine clinical expertise with modern
    technology to deliver accurate diagnoses and personalized treatment plans for every patient."
  * 6 mục: "Comprehensive evaluation and accurate diagnosis" / "Personalized treatment plans for every
    patient" / "Experienced doctors and specialist consultations" / "Modern equipment and advanced
    diagnostics" / "Clear guidance and follow-up care" / "Convenient scheduling and minimal wait
    times".
  * Đoạn mô tả khối 2 (Advantage): "Choosing our team means care built around you: clear explanations,
    evidence-based treatment, and a coordinated approach across every specialty, so you always know
    the next step in your health journey."
  * 4 câu FAQ: dùng ĐÚNG 4 câu hỏi/câu trả lời đầu của src/data/demo-medical/faqs.ts (đã viết ở trang
    /faqs) — tái dùng dữ liệu, KHÔNG viết riêng. (Câu hỏi gốc cũng lặp/sai ngữ pháp — giữ nguyên.)

## GẮN LINK DETAIL — BẮT BUỘC (menu desktop + mobile, footer, nội dung)
Trong HTML gốc, mỗi trang con có 11 link tới 2 trang này (7 link service-detail + 4 link service: 3 trong menu + 4/1 trong footer); riêng trang chủ còn thêm 14 link ở các tab dịch vụ. Sau khi có route, SỬA TẤT CẢ và
xác nhận không còn href dạng ".html" hay route không slug:
1. Menu — src/data/demo-medical/menu.ts (mục "Services" của dropdown Services):
   "Services" -> /demo-medical/service ; "Services Detail" -> /demo-medical/service-detail/cardiology
   (chọn slug "cardiology" vì bản demo gốc viết cho Cardiology nên trang này giống hệt trang gốc). Menu
   được render ở BA nơi: header cố định, header thường, và offcanvas mobile — xác nhận cả 3 đọc từ
   cùng một mảng; nếu có nơi hard-code thì sửa luôn.
2. Footer medical (Footer.tsx / data footer): "Our Services" (cột Quick Links) ->
   /demo-medical/service ; cột "Our Services" có 4 link RIÊNG, mỗi link trỏ ĐÚNG slug của chính nó:
   General Check-Up -> /service-detail/general-check-up ; Disease Management ->
   /service-detail/disease-management ; Laboratory Tests -> /service-detail/laboratory-tests ;
   Emergency Care -> /service-detail/emergency-care (HTML gốc cả 4 cùng trỏ service-detail.html, nhưng
   vì đã có route động nên mỗi link nên tới đúng dịch vụ của nó). Footer render ở mọi trang medical nên
   sửa một lần ở component.
3. Trang chủ medical: nút "Our Services" của khối About -> /demo-medical/service ; 7 tab pane
   (tiêu đề + btn-arrow, 14 link) -> /demo-medical/service-detail/cardiology.
4. Trang /service: link tiêu đề + btn-arrow trong 7 pane -> /service-detail/cardiology (như trên).
5. Dropdown "Choose Services" (trang chủ, appointment, book-appointment) dùng chung services.ts.
6. Chạy quét link (scripts/viora-links.mjs nếu đã cài, hoặc Playwright tự viết) bắt đầu từ
   /demo-medical, /demo-medical/service, /demo-medical/service-detail/cardiology với độ sâu 1: KHÔNG
   còn link 404, không còn href ".html". Kiểm tra thủ công bằng Playwright ở cả desktop (hover
   dropdown Services) và mobile (≤1199px mở offcanvas, mở accordion Services, bấm Services Detail) rằng
   cả hai mục đều dẫn tới trang đúng và active/hover hiển thị đúng.

## VERIFY
- So HTML gốc với Next ở 1440, 991, 575: thứ tự block, chiều cao block, ảnh, font, link không gạch
  chân. Trang service: tab mặc định "Pediatrics", đổi tab đúng, hiệu ứng wow fadeInLeft. Trang detail
  (slug cardiology) giống bản gốc; đổi sang slug khác thì 2 tiêu đề h4 đổi tên đúng; slug lạ -> 404.
- Accordion detail: chỉ 1 mục mở, câu 1 mở sẵn, có transition.
- Chuyển qua lại /demo-medical ↔ /demo-agency bằng <Link>: màu không lẫn.
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: file tạo/sửa, danh sách TỪNG chỗ đã gắn link (menu x3, footer x5, trang chủ, trang
service) kèm kết quả quét link, nội dung đã viết lại (nguyên văn), lỗi chính tả đã sửa, việc chưa xong.