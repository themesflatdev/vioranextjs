Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc
lấy đúng con số, không áng chừng, không tự đơn giản hoá. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-restaurant/index.html (route "/demo-restaurant", route group
(demo-restaurant)). Header/Footer ĐÃ CÓ SẴN (header style-5, footer-style-4). Niche này CHỈ có
index.html, không có trang con. Làm hero + 7 block main-content (ĐÃ ĐỌC ĐỦ, liệt kê chính xác dưới đây),
THEO 4 NHÓM, verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Nền trang TỐI: `<div id="smooth-wrapper" class="bg-dark-color-2">` — wrapper #smooth-wrapper trong layout
restaurant PHẢI mang class bg-dark-color-2 (kiểm tra, thiếu thì thêm).

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. HeaderSection của restaurant gọi useScrollSmoother() + useWow(); layout có wrapper
   data-niche="restaurant"; demo-restaurant.scss dùng [data-niche="restaurant"] (không :root).
2. ATROPOS (thư viện MỚI, hiệu ứng nghiêng 3D): bản gốc nạp assets/js/atropos.js + assets/css/atropos.min.css,
   phiên bản 2.0.2. Cài `npm i atropos@2.0.2` và thêm src/styles/vendor/atropos.scss (copy nội dung
   assets/css/atropos.min.css) vào chuỗi vendor trước reset trong app.scss như bootstrap/swiper — KHÔNG
   dùng thẻ <link>, KHÔNG dùng `atropos/css` của npm (để đúng CSS gốc).
3. `ls src/hooks src/components/common` và dùng lại: useSplitTextReveal, useWow, useScrollSmoother,
   useScrollTransform, useCountUp (không cần ở trang này), hook ảnh parallax data-speed, hook custom
   cursor ("cursor-wrapper/custom-cursor/area-cursor-custom" — đã làm ở corporate/agency), hook tab,
   cơ chế Swiper theo fix-swiper-controls (useSwiperControls). KIỂM TRA CÁC ĐIỀU SAU, thiếu thì bổ sung:
   a. useSplitTextReveal có đủ chế độ `effect-blur-fade` và `split-lines-rotation-x` chưa. Số liệu từ
      gsapAnimate.js: target = phần tử `p`/`a` con đầu tiên nếu có, không thì chính phần tử; mặc định
      SplitText type "words, chars", duration 0.9, stagger 0.02, ease power3.out, perspective 400.
      effect-right: from {opacity 0, x 50}. split-lines-transform: tách "lines", stagger 0.2, from
      {opacity 0, yPercent 100, autoAlpha 0}. split-lines-rotation-x: tách "lines", stagger 0.2, from
      {opacity 0, rotationX -120, transformOrigin "top center -50"}. effect-blur-fade: tách "words",
      fromTo {opacity 0, filter blur(10px), y 20} -> {opacity 1, blur(0px), y 0}, duration 1, stagger 0.1,
      ease power3.out. Cùng scrollTrigger như các chế độ khác.
   b. useWow có đọc `data-wow-duration` (vd "2s") và `data-wow-delay`, và class animate.css `zoomIn`
      hoạt động không (restaurant dùng `wow zoomIn` với duration 2s ở nhiều nơi).
   c. useScrollTransform nhận đủ `data-direction` = up|left|right và `data-distance` dạng phần trăm.
   d. Tab: giữ class active/show, không Bootstrap JS.
4. QUY TẮC SWIPER (đã gây lỗi ở medical): KHÔNG dùng navigation={true}/pagination={true} hay object thiếu
   el/prevEl/nextEl; dots của theme phải là phần tử THẬT (class sw-dots ...) nằm đúng vị trí như HTML gốc
   và buộc vào Swiper qua ref (hook useSwiperControls). Trang này không có nút prev/next, chỉ có dots.
5. next/image bắt buộc width/height; nhiều ảnh trong HTML gốc KHÔNG khai báo kích thước — dùng kích thước
   thật của file (đã đo):
   hero-1.png 841x882 | hero-2.png 326x355 | table-awaits-1.png 471x445 | table-awaits-2.png 269x258 |
   table-awaits-3.png 515x552 | item-restaurant-1 110x124 | -2 142x335 | -3 296x254 | -4 167x190 | -5 380x893
   | -6 124x167 | -7 163x148 | -8 94x106 | -9 217x317 | -10 291x598 | leaf.png 442x538 | leaf-2 268x468 |
   leaf-3 259x295 | leaf-4 321x524 | discount-1.png 157x157. Ảnh các block khác có sẵn width/height trong HTML.
6. Tên file dữ liệu: KHÔNG đặt `menu.ts` (đã dùng cho điều hướng header). Dùng
   src/data/demo-restaurant/menuItems.ts (thực đơn), popularMenu.ts, testimonials.ts, blogPosts.ts.

## NHÓM 1 — HERO + ABOUT
### Hero `hero-banner-5 position-relative` (nằm NGOÀI main-content, trước nó)
- `tf-container medium > row`: col-md-7 `.content`: h1.title.mb_28.split-text.effect-right "Where Flavor Meets
  Moments."; p.text-body-default.text_placehover.split-text.split-lines-rotation-x "Experience unforgettable
  moments through exceptional food, crafted with care and passion"; a.tf-btn.btn-switch-text.wow.fadeInUp
  href="#" > span > span.btn-double-text data-text="Explore Our Menu" (hover đổi chữ là CSS).
  col-md-5: `div.atropos.my-atropos.thumbs.tf-animateCLP-right.slide-btt-animated` >
  .atropos-scale > .atropos-rotate > .atropos-inner > img hero-1.png.
- Cùng cấp với container (con trực tiếp của hero): `div.item.slide-ltr-animated` > img hero-2.png.
- `slide-btt-animated` và `slide-ltr-animated`: ĐÃ XÁC MINH là CSS thuần trong _animation.scss
  (`animation: slide-to-slide 10s linear infinite` dùng biến --pxl-translate-x/y; btt có
  --pxl-translate-y: -70px) -> chỉ cần giữ đúng class, không cần JS.
- ATROPOS: gốc gọi `Atropos({ el, shadow: true, highlight: true })` cho MỌI `.my-atropos`. Viết hook
  useAtropos (hoặc component) client-only: import atropos, khởi tạo trong useEffect với đúng 2 tuỳ chọn
  đó, `destroy()` khi unmount/đổi route (đặc biệt vì có 2 phần tử .my-atropos ở 2 section). Ảnh layer có
  `data-atropos-offset` phải giữ nguyên thuộc tính này (Atropos đọc nó).
- `tf-animateCLP-right` (clip-path reveal): dùng hook/CSS đã có từ medical (thêm class active-animate
  khi vào viewport, trễ theo data-delay giây).
### About `section-about-8 position-relative tf-spacing-1`
- `tf-container medium > row align-items-center`: col-lg-6 `.content`: heading-section-3 d-grid gap_12 mb_36
  [sub "About Us" (text-label text-uppercase wow fadeInUp text_white lh-16), h3.title.split-text.
  effect-blur-fade "Where Passion Meets The Plate"]; p.mb_39.text-body-default.wow.fadeInUp "Viora was born from
  a simple idea: to create a place where every meal tells a story, every ingredient matters, and every guest
  feels right at home. Founded by food lovers with a shared dream, our restaurant brings together global
  flavors in a warm, inviting space that feels both familiar and exciting."; div.wow.fadeInUp >
  a.tf-btn.style-border.btn-hover-animate-border "Read More" href="#" (+ <span></span>).
  col-lg-6: `.thumbs.img-style.overflow-hidden`: img about-1.jpg 560x560 với data-speed=".9" (parallax ảnh;
  bỏ thuộc tính rác lang="0"), và `.contact.d-flex.gap_12.align-items-center.tf-animateCLP-up`
  data-delay=".4s": icon-PhoneCall + "Have any Question?" + h6.font-main "315-666-6688".
- Dải 4 box: `.swiper.tf-sw-mobile.z-5` data-screen=575 data-preview=1 data-space=15 > `.swiper-wrapper.
  tf-grid-layout-sm.lg-col-4.sm-col-2.tf-spacing-1.pb-0` > 4 `.swiper-slide` > `.tf-box-icon.style-3.wow.
  fadeInLeft` (data-wow-delay "", ".1s", ".2s", ".3s"): icon-ChefHat "Premium Chef" / "Crafted by passionate
  chefs every plate a masterpiece."; icon-Package "Fast Delivery" / "Your favorites, hot and speedy to your
  door."; icon-Leaf "Fresh Ingredients" / "We choose fresh ingredients every day, for every dish.";
  icon-Headset "Friendly Service" / "Wherever you are, we bring warm, attentive service." (tiêu đề là
  <a href="#" class="mb_8 h6 link">). Dots: `div.sw-dots.style-white.sw-pagination-mb.justify-content-center.
  d-flex.mt_24.d-md-none` nằm TRONG `.swiper`.
  CƠ CHẾ `tf-sw-mobile` (đã đọc carousel.js): Swiper CHỈ được khởi tạo khi `matchMedia("(max-width: 575px)")`
  khớp: slidesPerView = data-preview (1), spaceBetween = data-space (15), speed 1000, pagination clickable
  trên `.sw-pagination-mb`; khi rộng hơn 575px thì `destroy(true, true)` và xoá style inline của
  .swiper-wrapper/.swiper-slide, để CSS grid (`tf-grid-layout-sm lg-col-4 sm-col-2`) hoạt động; lắng nghe
  resize để bật/tắt qua lại. Làm bằng Swiper vanilla trong useEffect + matchMedia (hook useMobileSwiper,
  tìm trong src xem đã có chưa), cleanup đúng; KHÔNG dùng <Swiper> React cho phần này.
- Trang trí tuyệt đối (`position-absolute scroll-transform`, con của section, sau container):
  item-1 (up, 50%, item-restaurant-1.png), item-2 (left, 50%, -2), item-3 (left, 10%, -3), item-4 (right,
  50%, -4), leaf (up, 50%, leaf-3.png).

## NHÓM 2 — TABLE AWAITS + CHOOSE DELICIOUS (TAB THỰC ĐƠN)
### `section-table-awaits tf-spacing-1`
`tf-container medium > .box-table-awaits.align-items-center`: `.atropos.my-atropos.thumbs` (KHÔNG có
tf-animateCLP) > ... > .atropos-inner chứa 3 ảnh: `img.main.wow.zoomIn` data-atropos-offset="2"
data-wow-duration="2s" table-awaits-1.png; `img.leaf-1.wow.zoomIn` data-atropos-offset="-4.5"
data-wow-delay=".3s" data-wow-duration="2s" table-awaits-2.png; `img.leaf-2.wow.zoomIn`
data-atropos-offset="-2.5" data-wow-delay=".3s" data-wow-duration="2s" table-awaits-3.png. `.content`:
heading-section-3 d-grid gap_12 mb_42 [sub "Your Table Awaits"; h3.title.split-text.effect-blur-fade "Secure
Your Seat For Something Special."; p.desc.mt_10.text-body-default.wow.fadeInUp "Whether it’s a romantic
evening, a casual lunch, or a special celebration we’re here to serve you with warmth, flavor, and care. Fill
in the details below to reserve your spot, and let us take care of the rest."] (nội dung nhắc "điền form"
nhưng trang KHÔNG có form — đặc điểm của theme, giữ nguyên); `.info-time.d-grid.gap_12.mb_40`: h6.wow.fadeInUp
"Opening Hours:" + 2 p.text-body-2.text_white.wow.fadeInUp "Monday – Friday: 11:00 AM – 10:00 PM" và "Saturday
– Sunday & Holidays: 10:00 AM – 11:00 PM"; a.tf-btn.style-border.btn-hover-animate-border.wow.fadeInUp "Make A
Reservation" href="#" (+ <span></span>).
### `section-choose-delicious flat-animate-tab tf-spacing-1`
- heading-section-3 text-center mb_28 d-grid gap_12 mb_40: sub.v2 "Choose delicious" (... justify-content-center
  wow fadeInUp) + h3.title.split-text.effect-blur-fade "Popular menu".
- `.tab-slide.style-4.d-flex.mb_40 > ul.menu-tab.d-flex.justify-content-between.wow.fadeInUp[role=tablist]` 5 tab
  (li.nav-tab-item > a.tab-link.d-flex.justify-content-between.align-items-center > i.icon + span.text-button):
  Starters (icon-BowlSteam), Non-Veg (icon-CookingPot, MẶC ĐỊNH ACTIVE — tab thứ 2), Vegetarian (icon-Carrot),
  Dessert (icon-Popcorn), Drinks (icon-BeerStein). Gốc ghi nhãn "Nonvage" (lỗi chính tả hiển nhiên) -> SỬA
  thành "Non-Veg" (id tab giữ nonvage). Tab KHÔNG có `.item-slide-effect` (không có thanh trượt).
- `.tab-content.wow.fadeInUp`: 5 pane (starters, nonvage active show, vegetarian, dessert, drinks), mỗi pane
  `.tf-grid-layout.md-col-2.menu-restaurant` gồm 8 `.menu-restaurant-item.style-text`
  (`.heading.d-flex.justify-content-between.gap_16`: a.link.h6.text-capitalize tên + h6.text_primary-color giá;
  p.text-body-default mô tả). ĐÃ XÁC MINH: cả 5 pane (và 2 pane mồ côi) có CÙNG 8 món, cùng giá "38$" — lỗi
  demo, GIỮ NGUYÊN (đổi tab chỉ đổi pane hiện). 8 món theo thứ tự: Grilled Lemongrass Chicken / "Lemongrass
  garlic chicken thighs served"; Crispy Salmon on Wasabi Mash / "Pan-seared salmon on wasabi potato purée";
  Shrimp & Avocado Summer Rolls / "Fresh shrimp and avocado rolls with peanut sauce."; Passionfruit Panna
  Cotta / "Light and tangy cream dessert with passionfruit coulis"; Beef Ribeye with Peppercorn Jus / "Premium
  grilled cut with mashed potatoes"; Truffle Mushroom Risotto / "Creamy risotto with wild mushrooms and truffle
  oil."; Pumpkin Soup with Coconut Cream / "Creamy pumpkin soup with coconut cream"; Chocolate Lava Cake with
  Salted Caramel / "Warm chocolate cake with molten center, sea salt". (Mô tả món 1 cụt "…thighs served" — giữ
  nguyên.) Lưu 1 mảng dùng chung cho cả 5 tab.
- HTML gốc còn 2 pane MỒ CÔI (`emergencyCare`, `diseaseManagement` — tên của niche Medical, sót do copy) không
  có tab nào trỏ tới nên không bao giờ hiển thị -> BỎ, ghi vào báo cáo.
- Trang trí (con trực tiếp của section, sau container): `.item.scroll-transform` (left, 10%,
  item-restaurant-5.png) và `.leaf.scroll-transform` (up, 20%, leaf.png).

## NHÓM 3 — DELICIOUS POPULAR + TESTIMONIAL
### `section-delicious-popular`
- Trong `tf-container medium`: heading-section-3 flex-wrap gap_16 d-flex align-items-center
  justify-content-between mb_40: bên trái sub "Choose delicious" (text-label text-uppercase wow fadeInUp
  text_white mb_12 lh-16) + h3 "Popular Menu" (split-text effect-blur-fade); bên phải
  a.tf-btn.style-border.btn-hover-animate-border.wow.fadeInRight "View All" href="#".
- NGOÀI container: `.wrap.tf-grid-layout.lg-col-2.gap_20.wow.fadeInUp` gồm 2 cột `div.d-flex.gap_20.
  flex-column`, mỗi cột 2 `.menu-restaurant-item.style-list.cursor-wrapper`:
  cột 1: (1) CONTENT trước, ẢNH sau: "Shrimp & Avocado Summer Rolls", 38$, menu-popular-item-1.jpg;
         (2) ẢNH trước, CONTENT sau: "Truffle Mushroom Risotto", 45$, menu-popular-item-3.jpg.
  cột 2: (3) CONTENT trước, ẢNH sau: "Beef Ribeye with Peppercorn Jus", 51$, menu-popular-item-2.jpg, mô tả
         "Premium grilled cut with mashed potatoes and black pepper sauce"; (4) ẢNH trước, CONTENT sau: "Crispy
         Salmon on Wasabi Mash", 84$, menu-popular-item-4.jpg, mô tả "Pan-seared salmon on wasabi potato purée
         with sautéed greens."
  Mỗi item: `.content.d-flex.flex-column.justify-content-between.gap_8` (h4.title.text-capitalize >
  a.hover-line-text.link href="#"; p.text-body-default) và `.img-style.area-cursor-custom.overflow-hidden`
  (img 455x455 data-speed="0.9" + `.custom-cursor.text-button.fw-6` "Order" + h4.price giá).
  SỬA 2 mô tả sai trong chính trang (đã áp dụng chính sách sửa mâu thuẫn nội bộ, dùng đúng mô tả đã có ở danh
  sách thực đơn): (1) gốc là "Shrimp & Avocado Summer Rolls" (lặp lại tên món) -> "Fresh shrimp and avocado
  rolls with peanut sauce."; (2) gốc là "Warm chocolate cake with molten center, sea salt, and caramel sauce." (mô
  tả của món bánh chocolate đặt nhầm cho Truffle Mushroom Risotto) -> "Creamy risotto with wild mushrooms and
  truffle oil.".
- CUSTOM CURSOR "Order": TÁI DÙNG hook/component đã có (đã đọc main.js: trong `.area-cursor-custom`, khi di
  chuột `.custom-cursor` có top = clientY - areaTop - 60, left = clientX - areaLeft - 60, opacity 1, scale(1);
  khi rời chuột opacity 0, scale(0.3)); chỉ cần xác nhận tên class `area-cursor-custom` được hỗ trợ.
### `section-testimonial-4 sw-layout tf-spacing-9`
- heading-section-3 mb_40 > sub.v2 "Testimonials" (justify-content-center wow fadeInUp); `.row.
  justify-content-center > .col-lg-8 > .swiper.wow.fadeInUp[data-space=20]` > wrapper > 3 slide GIỐNG HỆT
  nhau (lỗi demo, giữ nguyên): `.testimonial-item.style-3`: p.h4.desc.text-center.fw-4 "From romantic dinners to
  family celebrations, our guests keep coming back for more than just the food they return for the warmth, the
  service, and the unforgettable atmosphere."; `.author.text-center`: `.avatar.mb_24` img avatar-5.jpg (ảnh dùng
  chung ../assets/images/avatar/, 80x80) + a.text-button.text_white.mb_4.link "Jocelyn Philips" (không href) +
  .text-caption-1 "Food Blogger". Dots `div.sw-dots.style-white.sw-pagination-layout.text-center` là con của
  `.swiper`, đặt SAU swiper-wrapper. Cấu hình (carousel.js): speed 1000, observer + observeParents true, slidesPerView 1 ở MỌI breakpoint
  (không khai báo data-preview/tablet/mobile), spaceBetween 20 ở mọi breakpoint, KHÔNG loop, KHÔNG autoplay,
  pagination bullets clickable. Buộc dots bằng ref (xem Bước 0.4).
- Trang trí: `.item-1..4.position-absolute.scroll-transform` (đều direction left): item-1 10% (item-restaurant-6),
  item-2 30% (-7), item-3 50% (-8), item-4 40% (-9); `.leaf.position-absolute.sm-hide.scroll-transform` up 10%
  (leaf-4.png).

## NHÓM 4 — DISCOUNT + INSIGHTS
### `section-discount`
`tf-grid-layout.lg-col-2` với 2 `.menu-restaurant-item.style-banner`: `.img-style` > img 930x980
(menu-discount-item-1.jpg / -2.jpg); `.content`: a.link.h1.title.split-text.effect-blur-fade href="#" "Peachy
Cherry" / "Flame Top"; `.bot`: p.text-body-2.mb_28.text_white.split-text.split-lines-transform "Cream cake with
peach and cherry light, fruity, and charming" / "Grilled beef over garlic butter rice with soy glaze and
herbs."; a.tf-btn.btn-bg-white.btn-switch-text.wow.fadeInUp (span > span.btn-double-text data-text="Order now")
href="#". Cả 2 item có `.discount.wow.zoomIn` data-wow-duration="2s": `.bg` > img discount-1.png +
`.discount-content` [.discount-number.text_white.fw-6 "25%" + .fw-7.text_white.text "DISCOUNT!"].
### `section-insights-2 sw-layout tf-spacing-1`
- heading-section-3 text-center d-grid gap_14 mb_40: sub.v2 "Blog" + h3.title.split-text.effect-blur-fade
  "Recent Articles".
- `.swiper` data-preview=3 data-tablet=2 data-mobile=1 data-mobile-sm=2 data-space-lg=30 data-space-md=24
  data-space=15. Cấu hình ĐÃ SUY TỪ carousel.js (speed 1000, observer + observeParents true, không loop, không
  autoplay): <575px: 1 slide, spaceBetween 15; 575–767px: 2 slide, space 15; 768–991px: 2 slide, space 24;
  >=992px: 3 slide, space 30 (đo lại đúng 4 mốc này ở bản gốc và bản Next) > wrapper > 3 `.swiper-slide.wow.
  fadeInLeft` (data-wow-delay "", ".2s", ".3s") > `.blog-item.style-1.hover-image`: a.img-style.mb_24 (img
  410x274 blog-item-1/2/3.jpg) + `.content`: `.date.text_white.text-label.text-uppercase.mb_12.lh-16` "13
  August" (cả 3 bài cùng ngày — giữ nguyên) + a.title.h5.mb_11.link.hover-line-text: "The Secret Behind Our
  Signature Dishes", "How to Pair Food & Wine Like a Chef", "Creating Memorable Dining Moments". Dots
  `div.sw-dots.style-white.sw-pagination-layout.mt_24.text-center` là con của `.swiper`, buộc bằng ref.
- LINK: HTML gốc trỏ cả 6 link (ảnh + tiêu đề × 3) tới `../demo-corporate/blog-detail.html`. Restaurant KHÔNG có
  trang blog riêng -> theo quy tắc đã thống nhất, GIỮ trỏ sang corporate: dùng route thật của corporate
  `/blog-detail/{slug}` với slug của bài ĐẦU TIÊN trong dữ liệu blog của corporate (tìm trong
  src/data/demo-corporate/, không hard-code tên dán tay). Tuyệt đối không để `.html`.
- Trang trí: `.item.position-absolute.scroll-transform` (left, 10%, item-restaurant-10.png) và
  `.leaf.position-absolute.scroll-transform` (up, 20%, leaf-2.png).

## VERIFY (Playwright, mở HTML gốc và Next cùng độ rộng; nếu đã cài scripts/viora-check.mjs và
## viora-links.mjs thì dùng)
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font, link không gạch chân,
  nền tối đúng (computed background của #smooth-wrapper khớp bản gốc), không ảnh lỗi/404.
- Atropos: có phần tử `.atropos-shadow` và `.atropos-highlight`; rê chuột lên thẻ hero làm `.atropos-rotate` đổi
  transform, các layer có data-atropos-offset dịch chuyển khác nhau; chuyển sang niche khác rồi quay lại không lỗi
  console (đã destroy đúng).
- tf-sw-mobile: ≤575px có class swiper-initialized, 1 slide/lần, dots hiện và bấm được; ≥576px KHÔNG còn Swiper,
  lưới 2 cột (sm) / 4 cột (lg) như gốc; kéo cửa sổ qua mốc 575 theo cả 2 chiều không lỗi.
- Swiper testimonial/insights: số `.swiper-button-prev/.swiper-button-next/.swiper-pagination` mặc định = 0; dots
  nằm trong `.sw-pagination-layout`, bấm đổi slide; insights đúng số cột theo breakpoint.
- Tab thực đơn: mặc định "Non-Veg" active, 5 tab, đổi tab đổi pane (8 món/pane), không Bootstrap JS.
- Hiệu ứng chữ: p hero chạy split-lines-rotation-x; các h3 chạy effect-blur-fade; p discount chạy
  split-lines-transform; wow zoomIn có animation-duration 2s ở discount và ảnh table-awaits.
- Custom cursor "Order" bám chuột trong vùng ảnh và ẩn khi rời; 4 ảnh popular dùng đúng thứ tự content/ảnh xen kẽ.
- Link: 6 link insights trả 200 (trỏ corporate blog-detail), các link "#" giữ nguyên; không còn ".html".
- Chuyển qua lại /demo-restaurant ↔ /demo-medical ↔ / bằng <Link>: màu/font không lẫn.
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: file/hook/component tạo mới (useAtropos, useMobileSwiper...), thư viện cài thêm (atropos@2.0.2),
nội dung đã sửa (nhãn "Non-Veg", 2 mô tả món), phần bỏ (2 pane mồ côi), kết quả đo từng điểm trên, việc chưa xong.