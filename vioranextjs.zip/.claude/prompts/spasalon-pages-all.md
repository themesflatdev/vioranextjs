Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc. Không chắc -> dừng hỏi.

Làm 8 trang trong dropdown "Pages" của demo-spasalon (route group (demo-spasalon), prefix /demo-spasalon),
THEO NHÓM, báo cáo xong nhóm nào rồi mới sang nhóm tiếp. Header/Footer ĐÃ CÓ SẴN.
KHÔNG làm Service, Portfolio, Blog, Contact ở bước này.

## PHẦN DÙNG CHUNG (đọc TRƯỚC khi làm bất kỳ trang nào)

### PageHeaderSpa (page-layout-v02)
Mọi trang đều có khối đầu trang nằm NGOÀI main-content (trước nó):
`.page-layout-v02.parallax-container.overflow-hidden > .thumb.parallax-image > img.image-inner` 1920x720
images/page-title.jpg (loading eager) + `.tf-container > .content.text-center > ul.tf-breadcrumb.
justify-content-center.mb_16` [li "HOME" -> /demo-spasalon + li breadcrumb trang] + h2.title.text_white.
Parallax: cùng cơ chế data-speed / ScrollSmoother `effects: true` (không cần hook riêng).
Tạo component PageHeaderSpa dùng chung (prop: crumb, title).

### Component tái dùng từ trang chủ (KHÔNG viết lại)
- BookingSection (section-booking py-0): "Book Your Visit", ảnh spa-care-time-1.jpg, nút -> /demo-spasalon/booking
- PackagesSection (section-packages): 5 gói từ packages.ts
- GallerySection (section-gallery): 2 cột marquee dọc 6 ảnh gallery-1..6.jpg

### Data: src/data/demo-spasalon/
teamMembers.ts (6 người, tất cả Cosmetologist):
  maria-torres / dana-cho / amira-hassan / feran-torres / ana-chloris / christ-van
  (ảnh team-1..6.jpg — đọc HTML gốc staffs.html để lấy đúng thứ tự ảnh từng người)
Dùng lại packages.ts và faqs.ts nếu đã có từ trang chủ.

### Link: mọi href ".html" trong các trang -> route /demo-spasalon/... theo bảng:
about.html->/about | booking.html->/booking | staffs.html->/staffs |
member-detail.html->/member-detail/{slug} | testimonials.html->/testimonials |
calender.html->/calender | packages.html->/packages | faqs.html->/faqs |
index.html->/demo-spasalon | service.html->/service (tạm "#" nếu chưa làm).

## NHÓM 1 — ABOUT + STAFFS + MEMBER DETAIL

### /demo-spasalon/about (about.html)
PageHeaderSpa: crumb "About Us" / h2 "About Us". main-content có 6 section theo thứ tự:

1. section-about-6: GIỐNG HỆT trang chủ -> TÁI DÙNG AboutSection.

2. section-gallery: GIỐNG HỆT trang chủ -> TÁI DÙNG GallerySection.

3. section-image-view tf-spacing-1: `.tf-container.medium > .wrap-image-view`. Đọc HTML gốc about.html
   để lấy chính xác markup/ảnh/kích thước — tái dùng tf-animateCLP, hover-image-2 nếu có.

4. section-team-5: `.tf-container.medium > heading [sub "OUR TEAM" (text-label text-uppercase split-text
   effect-up), h2 "Meet Our Expert" (split-text effect-blur-fade)] + tf-grid-layout md-col-3 gap_30`.
   Hiển thị 3 thành viên ĐẦU từ teamMembers.ts. Card: ảnh 360x480 + tên + "Cosmetologist" + link ->
   /member-detail/[slug]. wow fadeInLeft với delay "", ".1s", ".2s".

5. section-lookbook tf-spacing-1: Đọc HTML gốc lấy ĐÚNG markup. `tf-container.medium > wrap-lookbook`
   gồm 3 `.lookbook-item.position-relative` (ảnh 510x650, tên "Organic Handmade Candles", các pin
   `.tf-pin-btn.bundle-pin-item.swiper-button`). ĐỌC main.js xác nhận cơ chế pin lookbook (class
   swiper-button nhưng không phải Swiper thật), báo cáo cơ chế rồi mới code.

6. section-booking py-0: TÁI DÙNG BookingSection.

### /demo-spasalon/staffs (staffs.html)
PageHeaderSpa: crumb "Our Staffs" / h2 "Our Staffs". 3 section:

1. section-team-5 tf-spacing-1: heading + lưới `lg-col-3 sm-col-2 gap_30` 6 thành viên ĐẦY ĐỦ từ
   teamMembers.ts. wow fadeInLeft, delay lặp "", ".1s", ".2s" cho mỗi hàng 3 người.

2. section-gallery: TÁI DÙNG GallerySection.

3. section-booking py-0: TÁI DÙNG BookingSection.

### /demo-spasalon/member-detail/[slug] (member-detail.html) — ROUTE ĐỘNG
PageHeaderSpa: crumb "Member Details" / h2 "Member Details".
generateStaticParams theo 6 slug từ teamMembers.ts. Slug lạ -> notFound().
Thân bài dùng CHUNG cho mọi slug; phần theo slug: tên và "Cosmetologist" (tra teamMembers.ts).

main-content: 2 section:

1. Nội dung member: Đọc HTML gốc để copy đúng layout (2 cột). SỬA mâu thuẫn nội bộ: gốc ghi chức danh
   "Chief Executive Officer" nhưng mô tả viết "Chief Marketing Officer" -> bỏ tên chức danh cụ thể trong
   mô tả, viết "As our dedicated Cosmetologist, they bring years of expertise..." (họ/their để trung tính).
   Giữ nguyên: Info sidebar (Location, WhatsApp, LinkedIn), Areas of Expertise, quote.

2. section-packages: TÁI DÙNG PackagesSection.

3. section-booking py-0: TÁI DÙNG BookingSection.

## NHÓM 2 — PACKAGES + CALENDAR + TESTIMONIALS

### /demo-spasalon/packages (packages.html)
PageHeaderSpa: crumb "Packages" / h2 "Packages". 3 section:

1. section-pricing-5 sw-layout tf-spacing-14: GIỐNG HỆT trang chủ (Swiper 3 gói, dots) ->
   TÁI DÙNG PricingSection đã build ở trang chủ.

2. section-packages: TÁI DÙNG PackagesSection.

3. section-booking py-0: TÁI DÙNG BookingSection.

### /demo-spasalon/calender (calender.html)
PageHeaderSpa: crumb "Calender" / h2 "Calender". (Giữ nguyên lỗi gõ "Calender" — là tên route thật.) 3 section:

1. section-calendar tf-spacing-1: `.tf-container.medium > heading [sub "Calendar", h2.split-text.effect-right
   "Find Your Perfect Time"] + .wrap-calendar > img` 1290x865 images/calendar.jpg. ĐÂY LÀ ẢNH TĨNH —
   không phải component lịch tương tác, giữ nguyên.

2. section-packages: TÁI DÙNG PackagesSection.

3. section-booking py-0: TÁI DÙNG BookingSection.

### /demo-spasalon/testimonials (testimonials.html)
PageHeaderSpa: crumb "Our Testimonials" / h2 "Our Testimonials". 2 section:

1. section-testimonial-9 v2 tf-spacing-10: BIẾN THỂ của testimonial trang chủ — 6 item, lưới md-col-2,
   KHÔNG có ảnh người bên cạnh (chỉ content). Đọc HTML gốc testimonials.html để copy đúng markup card.
   6 testimonial (lời nhận xét từ HTML gốc, đúng niche spa, không sửa):
   1 Lydia Gouse — "The moment I stepped in, I felt calm. The massage was heavenly — I didn't want to leave!"
   2 Madelyn Rhiel Madsen — "This spa is my monthly ritual now. The therapists are so kind, and every detail is perfect."
   3 David L. — "From start to finish, everything was perfect. My skin glowed instantly — I'll definitely return!"
   4 Anna P. — "The staff was so kind and welcoming. I felt renewed inside and out after my treatment!"
   5 Santhos K. — "Every detail was handled with such care. The spa felt like a peaceful escape from life!"
   6 James R. — "The massage eased every ache in my body. I walked out with energy and a smile!"
   Data -> src/data/demo-spasalon/testimonials.ts.

2. section-booking py-0: TÁI DÙNG BookingSection.

## NHÓM 3 — BOOKING (FORM 5 BƯỚC) + FAQs

### /demo-spasalon/booking (booking.html)
PageHeaderSpa: crumb "Booking" / h2 "Book An Appointment".

section-booking-2 tf-spacing-1: form đặt lịch 5 BƯỚC.
`wg-booking-step > ul.steps` 5 li: "1. Service" (active) / "2. TIME" / "3. Details" / "4. Payment" / "5. Done".
Mỗi li: span.title-step.d-block.text_primary-color.text-uppercase.letter-spacing-1.text-label.lh-16 + span.stepbar.
Form `#multiStepForm.form-service-booking.style-2`: dùng React state (currentStep 1-5), KHÔNG jQuery/Bootstrap JS.

Đọc HTML gốc booking.html để lấy ĐÚNG nội dung từng step (số ô, nhãn, option). Tóm tắt:
- Step 1 "Service": NiceSelect Category (Health/Popular), NiceSelect Service (Sport Massage/Hot Stone Massage/
  Massage Therapy/Physiotherapy), NiceSelect Staff (6 thành viên từ teamMembers.ts), + hàng 2: NiceSelect Date,
  NiceSelect Duration, NiceSelect Session. Nút "Next Step".
- Step 2 "TIME": đọc HTML gốc lấy đúng layout (lưới giờ chọn hay form). Nút Back / Next Step.
- Step 3 "Details": các ô nhập tên/email/phone/ghi chú. Nút Back / Next Step.
- Step 4 "Payment": chọn phương thức. Nút Back / Submit (onSubmit preventDefault).
- Step 5 "Done": thông báo thành công, không submit thật.
NiceSelect dùng component NiceSelect.tsx đã có (mở/đóng/chọn bằng state, class .nice-select/.current/.list/.option).
Nút Back/Next chỉ đổi currentStep, không validate phức tạp (giữ đúng như HTML gốc).

### /demo-spasalon/faqs (faqs.html)
PageHeaderSpa: crumb "FAQs" / h2 "FAQs". 2 section:

1. section-faqs-7 tf-spacing-1: 2 cột — col-lg-5 heading + col-lg-7 accordion.
   Heading: sub "FAQS" (text-label text-uppercase split-text effect-up), h2.split-text.effect-blur-fade
   "Frequently Asked Questions". Accordion 8 câu hỏi PHÙ HỢP spa, câu trả lời gốc là Lorem Ipsum CHƯA VIẾT ->
   viết thật (cùng chính sách xử lý placeholder, không hỏi lại):
   Q1 "How often should I book a spa treatment?" ->
     "For most people, once or twice a month is ideal to maintain skin health and overall relaxation benefits."
   Q2 "What benefits do I gain from facial therapy?" ->
     "Regular facials deeply cleanse pores, improve skin texture, boost hydration, and help slow visible signs of aging."
   Q3 "How long does a deep tissue massage last?" ->
     "Our deep tissue massage sessions typically run 60 to 90 minutes depending on the areas you'd like to focus on."
   Q4 "What must I prepare before a spa session?" ->
     "Arrive 10 minutes early, stay hydrated, and avoid heavy meals beforehand. We'll take care of everything else."
   Q5 "How safe are detox body wraps for health?" ->
     "Our body wraps use natural, skin-friendly ingredients and are safe for most guests — just let us know about any allergies."
   Q6 "What skincare results come from regular facials?" ->
     "You'll notice clearer, brighter skin, reduced fine lines, and improved tone with consistent monthly treatments."
   Q7 "How effective is hot stone massage for stress?" ->
     "Very effective — the warmth of the stones deeply relaxes muscles and promotes a sense of calm that lasts for days."
   Q8 "What happens during an aromatherapy session?" ->
     "We blend therapeutic essential oils with a gentle massage to calm the mind, ease tension, and uplift your mood."
   Accordion: 1 mục mở (câu 1), data-bs-parent="#accordion-faq", dùng hook accordion chuẩn của dự án.
   Data -> src/data/demo-spasalon/faqs.ts (tái dùng nếu đã có từ trang chủ).

2. section-booking py-0: TÁI DÙNG BookingSection.

## VERIFY (sau mỗi nhóm, Playwright)
- 8 trang có PageHeaderSpa đúng (parallax ảnh nền, breadcrumb, h2).
- Component tái dùng (Booking, Packages, Gallery, About, Pricing) render đúng không lỗi khi dùng nhiều trang.
- member-detail/[slug]: 6 slug -> 200, tên đúng, slug lạ -> 404. Chức danh mô tả không còn mâu thuẫn CEO/CMO.
- Booking form: step 1 active mặc định, nút Next đổi step, nút Back quay lại, step 5 hiện done.
- FAQ: câu 1 mở sẵn, chỉ 1 mục mở, có transition, 8 câu trả lời thật (không còn Lorem).
- Testimonials: 6 item hiện đúng lời nhận xét.
- Mọi link: quét /demo-spasalon độ sâu 2, KHÔNG còn ".html", KHÔNG còn link 404 trừ trang chưa làm.
- npm run build pass.

Báo cáo cuối mỗi nhóm: file tạo/sửa, component tái dùng, nội dung viết lại (nguyên văn 8 FAQ, member-detail fix),
lỗi chính tả đã sửa, việc chưa xong.