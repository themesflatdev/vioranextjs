Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "aitech" (route group (demo-aitech), route
"/demo-aitech"). Đã XÁC MINH bằng đọc trực tiếp demo-aitech/index.html.

## 1. KHÔNG có #smooth-wrapper/#smooth-content — KHÁC MỌI NICHE TRƯỚC

demo-aitech/index.html CÓ load gsap.min.js + ScrollSmoother.min.js +
ScrollTrigger.min.js + SplitText.min.js (script tag xác nhận), nhưng
grep toàn file KHÔNG có bất kỳ "smooth-wrapper"/"smooth-content" nào — 2
header nằm liên tiếp nhau, KHÔNG có div bọc GSAP ScrollSmoother. Đây là
bằng chứng cụ thể cho quy tắc ở master-workflow.md Bước 2 ("kiểm tra
script tag... không giả định mọi niche đều dùng smooth-wrapper chỉ vì có
load ScrollSmoother.min.js").

→ HeaderSection.tsx cho niche này KHÔNG bọc `{children}` trong
`#smooth-wrapper`/`#smooth-content`, chỉ render: Header (fixed) + Header
(thường) + `{children}` + MobileNav, liên tiếp nhau.

KHÔNG có splitting.min.js (giống mọi niche khác — CSS opacity fade đơn
giản khi hover, không cài package splitting).

2 header "style-6 header-sticky" và "style-6" — ĐÃ DIFF: nội dung giống
hệt nhau (chỉ khác class "header-sticky" + line-wrap).

## 2. Cơ chế scroll: `header-sticky` — TÁI DÙNG hook có sẵn

Dùng `useHeaderSticky` (src/hooks/useHeaderSticky.ts, direction-aware,
ngưỡng 400px, delta 10px, class "is-sticky"), không viết lại.

## 3. Breakpoint — mốc "xl" (1199/1200) — ĐÃ XÁC NHẬN ĐÚNG qua SCSS

`mobile-button d-xl-none` xác nhận trong HTML, VÀ đã đọc trực tiếp
`assets/scss/component/_header.scss` dòng ~290-313: `.header.style-6
.main-menu { @include res(xl) { display:none } }` — override riêng cho
style-6, ghi đè rule chung `res(lg)`. Xác nhận đúng bảng master-workflow.md
(KHÔNG giống trường hợp sai của spasalon) — main-menu và mobile-button
cùng ẩn/hiện ở đúng mốc 1199/1200, không lệch nhau. Vẫn nên đo lại 1 lần
bằng Playwright ở viewport 1200/1199 cho chắc trước khi kết luận cuối.

## 4. Header-right — Login link + CTA "Get Started" (KHÔNG có social/contact-box)

Thứ tự: `<a class="link text-button">Login</a>` (href="#") → CTA
`<a class="tf-btn btn-hover-animate-2 btn-bg-primary-3 sm-hide">Get
Started</a>` (href="#", ẩn ở ≤575px) → `.mobile-button.d-xl-none`.

## 5. PATTERN chung 15 niche chỉ-có-index: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

Giống restaurant (xem memory index-only-niches-reuse-corporate-pages) —
ĐÃ XÁC NHẬN LẠI ở aitech: mọi link Pages/Services/Project/Blog/Contact trỏ
`../demo-corporate/<page>.html`. → menu.ts dùng route THẬT của corporate
(`/about-us`, `/our-team`, `/team-detail`, `/carrer`, `/carrer-detail`,
`/faqs`, `/services`, `/service-detail`, `/portfolio`, `/portfolio-detail`,
`/blog-full-width`, `/blog-with-sidebar`, `/blog-detail`, `/contact`),
KHÔNG có tiền tố `/demo-aitech`. Chỉ "Home AI Tech"/"AI Tech" (Demos) +
logo trỏ `/demo-aitech`. Bỏ "404 Error" khỏi Pages (not-found.tsx tự
động).

## 6. Menu (giữ nguyên, KHÔNG phát hiện bug link nào)

Desktop mega-menu Demos: 12 demo, thứ tự y hệt các niche trước, submenu có
class "menu-rounded" (giống insurance). "Home AI Tech" trỏ "/demo-aitech"
(active).

Mobile — đủ 20 niche, offcanvas "style-dark", 5 nhóm accordion
Demos/Pages/Services/Project/Blog, Contact link thẳng cuối danh sách.

Tách data vào src/data/demo-aitech/menu.ts.

## 7. Modal "View all demos": link đơn giản "/landing#demos".

## Sau khi xong — checklist verify

- Đo CHÍNH XÁC mốc ẩn/hiện main-menu VÀ mobile-button bằng Playwright ở
  nhiều viewport quanh 1199-1200 VÀ 991-992 — báo cáo rõ mốc thật nếu khác
  dự kiến "xl" (giống bài học từ spasalon)
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- Login + Get Started hiện đúng, Get Started ẩn ở ≤575px
- Cơ chế header-sticky: cuộn xuống liên tục qua 400px KHÔNG sticky, cuộn
  ngược lên 1 đoạn (trong phạm vi cuộn thực tế của trang, kiểm tra
  scrollHeight trước khi chọn giá trị scroll test) mới thấy "is-sticky"
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
