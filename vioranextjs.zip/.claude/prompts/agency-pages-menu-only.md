Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

CHỈ làm 6 trang trong dropdown "Pages" của agency (KHÔNG làm Services,
Service Detail, Portfolio, Portfolio Detail ở bước này — để sau), THEO
ĐÚNG THỨ TỰ, báo cáo xong trang nào rồi mới sang trang tiếp theo:

About Us → Our Team → Team Detail → Our Pricing → Testimonials → FAQs

GHI CHÚ CHUNG: "team-purpose-showcase" (gallery 5 ảnh masonry) đã xuất
hiện GIỐNG HỆT ở /contact và /our-team của corporate, và lặp lại ở
/about của agency — XÁC NHẬN ĐÂY LÀ COMPONENT DÙNG CHUNG THẬT SỰ, chuyển
ShowcaseGallery.tsx vào components/common/ nếu chưa làm, dùng chung cho
mọi niche, KHÔNG viết lại theo từng niche.

=====================================================================
TRANG 1 — /demo-agency/about (about.html) — 4 section
=====================================================================

1. section-about-2 v2: heading "text-change-color" (tái dùng cơ chế từ
   Home Agency) + 4 counter (Completed Projects/Years of Experience/
   Client Satisfaction/Our Clients) + nút "About Us".
2. team-purpose-showcase: TÁI DÙNG ShowcaseGallery (components/common/).
3. section-team-7: 4 thành viên (Linda Parker-Developer, Joseph
   Jessica-Designer, David John-Founder, Jessica Jung-Co-Founder) —
   SUBSET của 6 người đầy đủ sẽ tạo ở Trang 2 (Our Team), dùng chung data,
   KHÔNG tạo trùng.
4. section-service-3: TÁI DÙNG THẲNG ServicesNumbered.tsx đã build ở
   Home Agency (data services.ts đã có sẵn), KHÔNG viết lại.
5. section-resume-2 v2: TÁI DÙNG THẲNG ResumeSection.tsx (kèm marquee
   lồng trong) đã build ở Home Agency.

=====================================================================
TRANG 2 — /demo-agency/our-team (our-team.html)
=====================================================================

section-team-6: ĐỦ 6 thành viên (Linda Parker-Developer, Joseph
Jessica-Designer, David John-Founder, Jessica Jung-Co-Founder, Thomas
Tatum, Angelina Onana — đọc đúng role 2 người cuối trong HTML gốc thật,
đừng đoán). Tạo src/data/demo-agency/teamMembers.ts DÙNG CHUNG cho Trang 1
(subset 4 người đầu) và Trang 3 (team-detail).

Cuối trang có "section-testimonial-2" (tái dùng teaser đã build ở Home)
+ "section-contact-3" (form liên hệ — NẾU CHƯA LÀM RIÊNG, tạm thời copy
y hệt cấu trúc HTML gốc, phần sửa nội dung mô tả/dropdown sẽ làm ở bước
/contact riêng sau, KHÔNG cần sửa ở đây, chỉ cần dựng đúng cấu trúc để
không lỗi).

=====================================================================
TRANG 3 — /demo-agency/team-detail/[slug] (team-detail.html) — ROUTE ĐỘNG
=====================================================================

1 bản demo dùng chung cho mọi slug (David John - CEO & Founder, có
Education + Experience — cấu trúc RIÊNG của agency, KHÁC corporate dùng
"Areas of Expertise"). Title/tên/ảnh lấy theo slug (tra teamMembers.ts
của agency, KHÔNG dùng chung file data với corporate). Route
"/team-detail/[slug]/page.tsx", generateStaticParams theo 6 slug.

=====================================================================
TRANG 4 — /demo-agency/our-pricing (our-pricing.html) — SỬA TÍNH NĂNG
=====================================================================

3 gói (Basic $49, Standard $99 "Popular", Premium $199) — GIỮ NGUYÊN giá/
tên gói/mô tả ngắn ("Start at $X included Y clients"), CHỈ SỬA danh sách
tính năng (gốc dùng tính năng phần mềm không hợp agency, ĐÃ XÁC NHẬN với
người dùng viết lại). Cả 3 gói dùng CHUNG 4 tính năng sau (đúng như HTML
gốc lặp lại y hệt cho cả 3 gói, giữ nguyên kiểu lặp này):
- Dedicated Project Manager
- Unlimited Design Revisions
- Source File Delivery
- Priority Email Support

Swiper carousel (data-preview=3/tablet=2/mobile=1). Cuối trang:
section-testimonial-2 (tái dùng) + section-contact-3 (dựng cấu trúc,
chưa cần sửa nội dung — làm ở bước /contact riêng sau).

=====================================================================
TRANG 5 — /demo-agency/testimonials (testimonials.html) — VIẾT LẠI NỘI DUNG
=====================================================================

Lưới 6 testimonial (KHÔNG phải Swiper, dạng grid tĩnh lg-col-3) — ĐÃ XÁC
NHẬN với người dùng, phần lớn testimonial dính nội dung bảo hiểm nhà đất
("Homeowner", "Villa Owner", "coverage"), CẦN VIẾT LẠI cho phù hợp agency
sáng tạo/thiết kế. Đọc lại ĐỦ CẢ 6 testimonial trong HTML gốc, testimonial
nào ĐÃ PHÙ HỢP (ví dụ vai trò "Architect" có thể vẫn hợp lý làm khách hàng
agency thiết kế) thì GIỮ NGUYÊN, chỉ viết lại đúng cái KHÔNG hợp. Văn
phong tham khảo: "The team completely transformed our brand identity —
professional, creative, and incredibly easy to work with from start to
finish." (đổi role thành Startup Founder/Marketing Director/Product
Manager... tuỳ ngữ cảnh, giữ nguyên avatar/tên hiện có, chỉ đổi nội dung
quote + vai trò cho phù hợp).

Data tách vào src/data/demo-agency/testimonialsFull.ts. Cuối trang:
section-contact-3 (dựng cấu trúc, chưa sửa nội dung).

=====================================================================
TRANG 6 — /demo-agency/faqs (faqs.html) — VIẾT LẠI TOÀN BỘ NỘI DUNG
=====================================================================

HTML gốc có 3 nhóm nói về "chat software" (SaaS) — KHÔNG hợp agency, ĐÃ
XÁC NHẬN với người dùng viết lại toàn bộ. Dùng ĐÚNG nội dung sau (giữ
nguyên cấu trúc kỹ thuật: 3 nhóm, mỗi nhóm 5 câu, accordion, câu đầu mỗi
nhóm mở sẵn):

**Nhóm 1 — "Project Process"**
1. Q: What does your design process look like?
   A: Our process starts with discovery and research, followed by
   strategy, design concepts, revisions, and final delivery. We keep you
   involved at every stage to ensure the result matches your vision.
2. Q: How long does a typical project take?
   A: Timelines vary by project scope, but most branding projects take
   2-4 weeks, while full website builds typically take 4-8 weeks
   depending on complexity.
3. Q: Can I request revisions during the project?
   A: Yes, each package includes a set number of revision rounds. We
   welcome your feedback throughout the process to make sure the final
   result truly represents your brand.
4. Q: Do you work with clients remotely?
   A: Absolutely. We collaborate with clients worldwide using tools like
   Slack, Zoom, and Figma to keep communication smooth no matter where
   you're located.
5. Q: What information do you need from me to get started?
   A: We'll ask for your brand goals, target audience, any existing
   brand assets, and examples of styles you like. A short discovery call
   helps us tailor the approach to your needs.

**Nhóm 2 — "Pricing & Payment"**
1. Q: How does pricing work for your services?
   A: Pricing depends on project scope and deliverables. We offer both
   fixed-price packages and custom quotes for larger projects — reach
   out and we'll recommend the best fit.
2. Q: Do you require a deposit before starting?
   A: Yes, we typically require a 50% deposit to begin work, with the
   remaining balance due upon project completion.
3. Q: What is your refund policy?
   A: If a project is cancelled before work begins, we offer a full
   refund of the deposit. Once design work has started, refunds are
   prorated based on work completed.
4. Q: Are there any hidden fees?
   A: No. All costs are outlined clearly in your proposal before we
   begin, so there are no surprises along the way.
5. Q: Can I upgrade my package mid-project?
   A: Yes, you can upgrade your package at any time — we'll simply
   adjust the scope and pricing accordingly.

**Nhóm 3 — "Services Questions"**
1. Q: What services does your agency offer?
   A: We offer brand strategy, web design & development, digital
   marketing, and UI/UX design — everything you need to build and grow a
   standout digital presence.
2. Q: Do you offer ongoing support after launch?
   A: Yes, we offer maintenance and support packages to keep your
   website and digital assets running smoothly long after launch.
3. Q: Can you help with an existing brand, or only new ones?
   A: Both! Whether you're starting from scratch or refreshing an
   existing brand, we tailor our approach to fit your current stage.
4. Q: Do you handle both branding and web development?
   A: Yes, our team covers the full spectrum — from brand identity and
   strategy to fully custom website design and development.
5. Q: Is SEO included in your web design packages?
   A: Basic on-page SEO best practices are included in every website
   build, with advanced SEO and marketing available as an add-on
   service.

Tách data vào src/data/demo-agency/faqs.ts. Cuối trang tái dùng
section-contact-3 (dựng cấu trúc, chưa sửa nội dung).

=====================================================================
SAU KHI XONG CẢ 6 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Nội dung đã viết lại (pricing, testimonials, faqs) hiển thị đúng bản
  mới, không còn dấu vết nội dung sai niche
- Component tái dùng (ServicesNumbered, ResumeSection, ShowcaseGallery)
  hoạt động đúng, không lỗi
- 6 team member link đúng /team-detail/[slug] tương ứng
- ShowcaseGallery đã chuyển vào components/common/, xác nhận /contact và
  /our-team của CORPORATE vẫn hoạt động đúng sau khi refactor
- Không phụ thuộc jQuery/Bootstrap JS, build production pass

LƯU Ý: 5 trang còn lại của agency (Services, Service Detail, Portfolio,
Portfolio Detail, Contact) SẼ LÀM SAU trong 1 prompt riêng — KHÔNG tự ý
làm thêm ở bước này.