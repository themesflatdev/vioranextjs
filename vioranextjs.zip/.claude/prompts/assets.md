Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Copy toàn bộ assets từ ../viora/viora/ vào project vioranextjs, ĐÚNG NGAY
TỪ ĐẦU (rút kinh nghiệm từ dự án agentranextjs trước, không để sót/dư như
lần đó).

## 1. Assets DÙNG CHUNG (mọi niche + trang landing)

Copy vào public/assets/ (giữ cấu trúc thư mục con):
- images/ (11MB — ảnh dùng chung, khác ảnh riêng từng niche)
- js/ (2.7MB — các thư viện: GSAP thật đã có sẵn, ScrollSmoother,
  SplitText, Swiper, Atropos, distortion-img, Isotope, image-compare-viewer,
  Splitting.js, Springer, jQuery Fancybox, jQuery UI — copy hết dù chưa
  dùng ngay, sẽ dùng dần từng thư viện theo từng bước sau)
- css/ (1.1MB — CSS thư viện bên thứ 3 đã build sẵn: swiper.css,
  isotope liên quan nếu có, atropos.css, fancybox.css... — đây là CSS
  thuần, KHÔNG phải phần build từ SCSS riêng, copy nguyên vào
  public/assets/css/ hoặc src/styles/vendor/ tùy quyết định cấu trúc, giữ
  nhất quán)
- favicon.svg

## 2. Icon font (CHỈ copy phần cần thiết — rút kinh nghiệm từ agentranextjs)

Từ assets/icons/icomoon/, CHỈ copy:
- style.css
- fonts/ (icomoon.eot/svg/ttf/woff)

KHÔNG copy: demo.html, demo-files/, selection.json, Read Me.txt (rác
catalog demo của Icomoon, không cần cho runtime).

Ngoài ra assets/icons/ còn có 1 file SVG riêng lẻ "check-2.svg" (không
thuộc icomoon) — copy luôn file này vào public/assets/icons/.

## 3. Font chữ (Google Fonts — KHÔNG copy file, dùng next/font/google)

Mở assets/font/fonts.css, xác định đúng tên font đang dùng (Bricolage
Grotesque) và các weight/style. Setup qua next/font/google trong
layout.tsx (không copy file/không dùng link CDN thủ công), y hệt cách đã
làm ở agentranextjs.

## 4. SCSS chung

Copy assets/scss/ vào src/styles/, giữ nguyên cấu trúc partial
(_landing.scss, _reset.scss, _sections.scss, _widgets.scss, abstracts/,
component/, app.scss).

## 5. Assets RIÊNG của niche corporate (chỉ niche này, các niche khác

CHƯA copy vì chưa làm tới)

- demo-corporate/css/corporate.css → copy vào src/styles/demo-corporate.scss
  (đổi đuôi .css thành .scss nếu cần import qua Sass, hoặc giữ .css tùy
  cấu trúc — chỉ cần đảm bảo import được vào layout/page tương ứng route
  niche corporate) — file này override lên trên CSS chung, cần import
  ĐÚNG THỨ TỰ SAU CSS chung.
- demo-corporate/images/ (5.8MB) → copy vào public/assets/images/demo-corporate/
  (tách riêng thư mục, không trộn lẫn với assets/images/ chung, để dễ
  quản lý khi thêm niche khác sau này)

## Sau khi xong

Chạy npm run dev, kiểm tra:
- Font chữ (Bricolage Grotesque) load đúng qua next/font
- Icon font hiển thị đúng (thử 1 icon bất kỳ trong code test tạm nếu cần)
- Không còn file thừa nào của icomoon (demo.html, selection.json...) trong
  public/
- Cấu trúc thư mục rõ ràng: assets chung vs assets riêng corporate tách
  biệt, để sau này thêm niche khác không bị lẫn