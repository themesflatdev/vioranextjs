Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

CHỈ làm 2 trang trong dropdown "Services" của insurance (KHÔNG làm
Contact, Portfolio, Portfolio Detail, Blog ở bước này), báo cáo xong
trang nào rồi mới sang trang tiếp theo. NHỚ GẮN ĐÚNG ROUTE VÀO MENU sau
khi có route thật (bài học từ agency — đừng để menu trỏ route không
slug/không tồn tại).

=====================================================================
TRANG 1 — /demo-insurance/services (services.html)
=====================================================================

3 section:
1. section-why: GIỐNG HỆT WhyChooseSection.tsx đã build ở trang chủ —
   TÁI DÙNG THẲNG.
2. section-service-4 v2: KHÁC trang chủ — đây là LƯỚI TĨNH (lg-col-4,
   KHÔNG phải Swiper), ĐỦ 8 dịch vụ (khác trang chủ chỉ có 4 trong
   Swiper): Health Insurance, Life Insurance, Property Insurance,
   Business Insurance, Personal Accident, Travel Insurance, Home
   Insurance, Agriculture Insurance. GIỮ NGUYÊN mô tả (cả 8 dùng chung 1
   câu AI-driven — đã xác nhận với người dùng không sửa, áp dụng nhất
   quán như đã quyết định ở trang chủ). Mở rộng
   src/data/demo-insurance/services.ts (đã có 4 từ trang chủ) thành ĐỦ 8,
   KHÔNG tạo file data mới trùng. Sửa TẤT CẢ link "service-detail.html"
   tĩnh → "/service-detail/${slug}".
3. section-request: TÁI DÙNG từ trang chủ.

=====================================================================
TRANG 2 — /demo-insurance/service-detail/[slug] (service-detail.html) — ROUTE ĐỘNG + SỬA NỘI DUNG
=====================================================================

Title (h2) + breadcrumb: LẤY ĐÚNG theo slug (tra services.ts, 8 dịch vụ) —
ĐÂY LÀ PHẦN ĐỘNG THẬT.

Phần thân bài (sidebar + content) dùng 1 BẢN DEMO CHUNG cho mọi slug,
NHƯNG ĐÃ PHÁT HIỆN nội dung demo gốc SAI HẲN NICHE + CÓ LOREM IPSUM CHƯA
VIẾT (không giống các lỗi text-sai-niche thông thường trước đây — đây là
placeholder thật chưa hoàn thiện), CẦN SỬA (không hỏi lại, áp dụng theo
tinh thần đã thống nhất vì đây rõ ràng là nội dung chưa hoàn chỉnh chứ
không phải chỉ "không hợp"):

- Sidebar author: "Linda Parker - Cardiologist at Viora" → SỬA thành
  "Linda Parker - Senior Insurance Advisor at Viora" (giữ tên, chỉ đổi
  chức danh).
- Sidebar categories (Risk Assessment/Personal Accident/Critical
  Illness/Home Insurance/Business Insurance) — PHÙ HỢP, giữ nguyên.
- Banner "3M+ Coverage Value" — giữ nguyên, nhưng SỬA link
  "appointment.html" (không tồn tại, lỗi) → "/contact".
- Heading chính "Professional Medical Service Of Cardiology" → SỬA thành
  "Comprehensive Coverage Tailored To Your Needs".
- Đoạn mô tả (SỬA — đang là Lorem Ipsum): "We work closely with you to
  understand your unique situation and design a protection plan that
  truly fits your life, your assets, and your long-term goals."
- Danh sách 6 mục (SỬA — đang là Lorem Ipsum + câu vô nghĩa): "Flexible
  coverage options tailored to your needs", "Fast, transparent claims
  processing", "24/7 access to support when you need it most", "No
  hidden fees or confusing fine print", "Add-on coverage available as
  your needs grow", "Dedicated advisor to guide you every step of the
  way".
- Heading phụ "Specialized Investigations" (thuật ngữ y khoa) → SỬA
  thành "How It Works".
- Đoạn mô tả dưới heading phụ (SỬA — Lorem Ipsum): "Getting covered is
  simple. Our team guides you from the first consultation through
  policy activation, making sure you understand exactly what's protected
  and why."
- 2 ảnh thumb — giữ nguyên.
- Heading "Health Tips & Info" (thuật ngữ y khoa) → SỬA thành "Common
  Questions".
- 5 câu FAQ bên dưới — GIỐNG HỆT 5 câu đầu đã có ở trang chủ/FAQs — TÁI
  DÙNG data/component FAQ đã có, GIỮ NGUYÊN câu trả lời (đã quyết định
  không sửa).

Route "/service-detail/[slug]/page.tsx", generateStaticParams theo 8
slug trong services.ts.

## Gắn menu (quan trọng — bài học từ agency)

Sau khi có đủ route, cập nhật data/demo-insurance/menu.ts: mục "Services
Detail" trong dropdown (cả desktop và mobile nếu có) đang trỏ route
KHÔNG slug → sửa trỏ đúng vào slug của SERVICE ĐẦU TIÊN trong services.ts
(giống cách đã sửa cho agency/corporate trước đây).

=====================================================================
SAU KHI XONG CẢ 2 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Lưới 8 dịch vụ hiển thị đủ, đúng ảnh/tên
- Bấm từ mỗi dịch vụ → đúng route /service-detail/[slug], title đổi
  đúng theo dịch vụ
- Nội dung thân bài đã sửa hiển thị đúng bản mới, không còn "Cardiologist",
  "Lorem ipsum", thuật ngữ y khoa
- Menu "Services Detail" trỏ đúng route có slug, không còn 404
- Thử slug không tồn tại → 404
- Không phụ thuộc jQuery/Bootstrap JS, build production pass

LƯU Ý: Contact, Portfolio, Portfolio Detail, Blog của insurance SẼ LÀM
SAU trong prompt riêng — KHÔNG tự ý làm thêm ở bước này.