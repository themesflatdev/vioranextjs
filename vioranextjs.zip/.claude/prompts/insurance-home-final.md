Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Convert trang chủ ../viora/viora/demo-insurance/index.html (route
"/demo-insurance") — Header/Footer ĐÃ CÓ SẴN, chỉ làm hero + 8 section
main-content, ĐÃ ĐỌC ĐỦ. LÀM THEO TỪNG NHÓM, verify từng nhóm trước khi
sang nhóm tiếp.

## NHÓM 1: Hero + About

- HeroBanner.tsx (hero-banner-3, parallax-container): video nền
  (muted/autoplay/loop) dùng ĐÚNG "../video/medical-video.mp4" — ĐÃ XÁC
  NHẬN với người dùng GIỮ NGUYÊN dù không fit niche (theme gốc không có
  video riêng cho insurance, dùng tạm video medical — đúng y hệt HTML
  gốc, KHÔNG tự thay ảnh/video khác). Title "split-text effect-right"
  (GSAP SplitText — đọc đúng cơ chế gsapAnimate.js xử lý class
  "split-text" này, phân biệt với "Splitting.js" giả ở header không chạy
  thật — ĐÂY LÀ SplitText CỦA GSAP THẬT, có chạy, cần implement đúng).
  4 "support" checklist (24/7 Claims Support/Flexible Plans/Trusted
  Advisors/Financial Peace Of Mind).

- AboutSection.tsx: 2 đoạn text (giữ nguyên, không sửa) + 3 counter
  (15+ Years/6k+ Happy Clients/120+ Professional Advisors — TÁI DÙNG
  useCountUp đã có) + ảnh giữa.

## NHÓM 2: Services (Swiper) + Why Choose Us

- ServicesSwiperSection.tsx: Swiper (data-screen-xl=4/preview=3/
  tablet=3/mobile=1/mobile-sm=2), 4 service (Health/Life/Property/
  Business Insurance). GIỮ NGUYÊN mô tả (cả 4 dùng chung 1 câu AI-driven
  — đã xác nhận với người dùng không sửa). SỬA nút "Explore All Plans"
  → đổi link từ "../demo-corporate/services.html" (sai, trỏ nhầm niche
  khác) thành "/services" (trang services của CHÍNH insurance, sẽ tồn
  tại khi làm tới trang con đó).

- WhyChooseSection.tsx: heading + 3 box icon (Personalized Plans/Fast &
  Fair Claims/Expert Support — nội dung NÀY PHÙ HỢP insurance, giữ
  nguyên, không sửa) + ảnh parallax (data-speed=".8") + nút "Talk To An
  Expert"→/contact.

## NHÓM 3: Overview + Insights (Swiper)

- OverviewSection.tsx: 3 cột (counter 99% + ảnh + testimonial "property
  management services"/Cheyenne Mango — GIỮ NGUYÊN không sửa dù hơi lệch
  ngữ cảnh, đã xác nhận với người dùng; "3M+ Coverage Value" + nút "Get A
  Free Quote"; "95% Claims Approved" + ảnh).

- InsightsSwiperSection.tsx: Swiper (data-preview=3/tablet=2/mobile=1/
  mobile-sm=2), 3 blog-item (tiêu đề/tag/tác giả/ngày — GIỮ NGUYÊN nội
  dung, phù hợp insurance). SỬA toàn bộ link (ảnh + title) đang trỏ
  "../demo-corporate/blog-detail.html" → đổi thành "/blog-detail" (trang
  blog-detail của CHÍNH insurance, sẽ tồn tại khi làm tới trang con đó —
  nếu insurance dùng route động [slug] cho blog-detail giống corporate,
  tạm trỏ về slug tương ứng item đầu hoặc để dạng không-slug tuỳ cấu trúc
  sẽ quyết định khi làm trang blog-detail của insurance sau).

## NHÓM 4: Request (form CTA) + Newsletter + FAQs

- RequestSection.tsx: ảnh nền parallax (data-speed=".8") + heading "Get
  Your Free Insurance Quote Today" + form (Full name/Email/Phone/
  Message, onSubmit preventDefault) — nội dung phù hợp, giữ nguyên.

- NewsletterSection.tsx: heading + form email + dải avatar "18K people"
  — giữ nguyên.

- FAQSection.tsx: accordion single-open (Q1 mở sẵn — TÁI DÙNG hook
  useAccordion single-open đã có từ corporate/agency). 5 câu hỏi RẤT PHÙ
  HỢP insurance (giữ nguyên câu hỏi), NHƯNG cả 5 câu trả lời đang GIỐNG
  HỆT NHAU (1 đoạn chung chung) — ĐÃ XÁC NHẬN với người dùng GIỮ NGUYÊN,
  không tự viết câu trả lời riêng cho từng câu.

## Sau MỖI nhóm

Chạy npm run dev, kiểm tra riêng phần vừa làm, báo cáo trước khi làm
nhóm tiếp theo.

## Sau khi xong toàn bộ

Playwright so sánh với HTML gốc:
- Video hero load đúng (medical-video.mp4), text split-text animation
  chạy đúng (GSAP SplitText thật, không phải fake như header)
- Cả 2 Swiper (Services, Insights) responsive đúng breakpoint
- Nút "Explore All Plans" và 3 link blog đã sửa trỏ đúng route riêng của
  insurance (không còn trỏ demo-corporate)
- Counter chạy đúng 1 lần khi cuộn tới
- FAQ accordion single-open, Q1 mở sẵn
- Không phụ thuộc jQuery, build production pass