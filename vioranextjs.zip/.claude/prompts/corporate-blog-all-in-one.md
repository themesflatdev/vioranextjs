Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.
Nếu không chắc cách implement, dừng hỏi thay vì tự chọn cách khác.

Làm ĐỦ 3 trang blog của corporate, THEO ĐÚNG THỨ TỰ, verify xong trang
nào báo cáo trang đó rồi mới sang trang tiếp:

=====================================================================
TRANG 1 — /blog-full-width (../viora/viora/demo-corporate/blog-full-width.html)
=====================================================================

Route group (demo-corporate), Header/Footer đã có sẵn. Không sidebar.

- Heading "Our Blog" / "Latest News"
- 2 blog-item lớn xếp ngang (row-blog, flex-column ở mobile, flex-row từ
  md), ảnh 937x620 và 464x620
- 7 blog-item lưới 3 cột (tf-grid-layout md-col-3)
- Pagination (wg-pagination, 3 trang + nút mũi tên)

## Data — MỞ RỘNG để pagination hoạt động THẬT

HTML gốc chỉ có 9 bài — CLONE thêm để có ít nhất 18-24 bài (đủ 3 trang
thật, mỗi trang 9 bài giống bố cục gốc: 2 lớn + 7 lưới). Khi clone, đổi
slug/id cho không trùng, có thể dùng lại y nguyên title/ảnh/nội dung bài
gốc (đây chỉ là data demo để pagination có ý nghĩa) — ghi comment
"cloned for pagination demo" trong code.

Tạo src/data/demo-corporate/blogPosts.ts — mỗi bài: id/slug, title,
author, date, image, size ("large"/"normal"). Tạo hook
src/hooks/usePagination.ts (nếu dự án viora CHƯA có, kiểm tra trước —
KHÔNG tạo trùng nếu đã có sẵn từ trước) dùng chung cho cả 3 trang có
pagination bên dưới.

## Component

BlogPostCard.tsx (dùng chung), BlogFullWidthGrid.tsx, Pagination.tsx
(props currentPage/totalPages/onPageChange, không hardcode UI tĩnh).

=====================================================================
TRANG 2 — /blog-with-sidebar (blog-with-sidebar.html)
=====================================================================

- Cùng heading "Our Blog"/"Latest News", NHƯNG layout col-lg-8 (danh sách
  dọc: 1 bài lớn (937x620) + 4 bài thường, KHÔNG phải lưới 3 cột) +
  col-lg-4 sidebar. Cũng CÓ pagination — dùng CHUNG hook usePagination +
  data blogPosts đã mở rộng ở Trang 1 (không tạo data riêng).

## Sidebar (đầy đủ 5 phần, tách BlogSidebar.tsx dùng lại được cho
## blog-detail nếu cần)

1. sidebar-author: form search + avatar tác giả (Tony Nguyen, "Content
   writer at Viora") + social icon (messenger/x/instagram/skype/telegram)
   + nút "Buy Theme" (href="#")
2. sidebar-categories: 5 category kèm số lượng — Business Consulting
   (112), Finance Consulting (32), Investment Tips (42), Tax Solutions
   (65), Risk Management (13)
3. sidebar-latest-post: 4 bài mới nhất (ảnh nhỏ 120x120 + title + meta) —
   TÁI DÙNG data blogPosts, lấy 4 bài bất kỳ, không cần data riêng
4. Subscribe Newsletter: input email + nút submit
5. sidebar-tags: 9 tag (Finance, Growth, Strategy, Risk, Tax, Investment,
   Business, Market, Consulting)

Tách data category/tags vào src/data/demo-corporate/blogSidebar.ts.

=====================================================================
TRANG 3 — /blog-detail/[slug] (blog-detail.html) — ROUTE ĐỘNG
=====================================================================

LƯU Ý: HTML gốc chỉ có 1 bài viết chi tiết duy nhất (demo dùng chung) —
giống tình huống đã gặp ở service-details/project-details của dự án
Agentra trước đây. Xử lý y hệt cách đó:

- Title/meta (category "Teamwork", author "Jordyn Culhane", date "May
  18, 2025") + breadcrumb: lấy ĐÚNG theo bài tương ứng slug (tra trong
  blogPosts theo slug — nếu blogPosts hiện tại không có đủ field
  category/author/date riêng, thêm vào type, nhưng GIỮ NGUYÊN dùng
  chung 1 bộ giá trị demo cho các bài KHÔNG có data riêng, không tự bịa)
- NỘI DUNG THÂN BÀI (đoạn mở đầu, ảnh, các block "passive" H4+danh
  sách, tags, share) dùng CHUNG 1 bộ nội dung tĩnh cho MỌI slug — copy
  đúng y hệt nội dung trong blog-detail.html gốc, KHÔNG tự viết riêng
  cho từng bài.
- Cột social icon "sticky" bên trái (ẩn dưới md) — dùng CSS position:
  sticky khi cuộn trong phạm vi bài viết.
- Prev/Next (tf-article-navigation): HTML gốc trỏ tới
  "single-post-1.html" (KHÔNG TỒN TẠI — link hỏng) nhưng TEXT hiển thị
  "Client Success Stories"/"Branded Impact" khớp đúng 2 bài thật trong
  data. LÀM ĐỘNG THẬT (khác nội dung thân bài chỉ demo tĩnh): tính đúng
  bài TRƯỚC/SAU theo vị trí thực trong mảng blogPosts (SAU KHI ĐÃ MỞ
  RỘNG data — dùng đúng 9 bài GỐC làm cơ sở tính prev/next, không tính
  trên các bài clone thêm để tránh prev/next chạy vòng vô nghĩa qua các
  bản sao giống hệt nhau — cân nhắc: tạo 1 mảng con "originalPosts" tách
  từ 9 bài gốc riêng để dùng cho mục đích prev/next và sidebar-latest-post,
  còn mảng đầy đủ đã clone chỉ dùng cho listing+pagination ở Trang 1/2).
- Comment: 3 review demo tĩnh (avatar, tên, ngày, rating 5 sao —
  TẤT CẢ đều 5/5 sao theo HTML gốc, giữ nguyên không tự đổi), form thêm
  review (Name/Email/Review, onSubmit preventDefault).
- Sidebar: TÁI DÙNG BlogSidebar.tsx đã build ở Trang 2 (kiểm tra HTML gốc
  blog-detail.html có đúng cùng cấu trúc sidebar không trước khi tái
  dùng — nếu khác, báo tôi).

## Trang

Route "/blog-detail/[slug]" (generateStaticParams theo "originalPosts",
9 slug gốc — KHÔNG tạo static params cho các bài clone thêm vì chúng chỉ
phục vụ demo pagination, không cần trang chi tiết riêng).

=====================================================================
SAU KHI XONG CẢ 3 TRANG
=====================================================================

- Pagination hoạt động thật ở cả Trang 1 và Trang 2, dùng chung 1 hook,
  đổi trang không lỗi
- Từ card bài viết ở Trang 1/2, bấm vào đúng slug → Trang 3 hiện đúng
  title/meta, prev/next tính đúng theo 9 bài gốc
- Thử slug không tồn tại → 404
- Sidebar Trang 2 và Trang 3 giống hệt nhau (nếu đúng là dùng chung)
- Không phụ thuộc jQuery, build production pass
