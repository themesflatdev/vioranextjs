Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng
con số, không áng chừng, không tự đơn giản hoá. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-saas/index.html (route "/demo-saas", route group (demo-saas)). Header/Footer ĐÃ
CÓ SẴN (header style-8 header-sticky, mốc menu mobile lg 991/992; footer-style-7). Niche này CHỈ có index.html, không có
trang con. Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS), hero, rồi 7 block main-content (ĐÃ ĐỌC ĐỦ), THEO 4 NHÓM; verify xong
nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Đặc điểm: CÓ ScrollSmoother (`#wrapper` > `#smooth-wrapper` > `#smooth-content`), nền TỐI (--Bg-dark), font `.font-2` = Sora,
`.font-3` = Manrope. Điểm khó nhất: hiệu ứng WEBGL méo ảnh theo chuột ở khối CTA (Nhóm 4).

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-saas)/layout.tsx: wrapper `data-niche="saas"`; cấu trúc #wrapper > #smooth-wrapper > #smooth-content như các niche
   dùng ScrollSmoother đã làm; HeaderSection gọi useScrollSmoother() + useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE: demo-saas/css/saas.css (102 dòng) ngoài `:root` còn có selector TOÀN CỤC: `body {color}`,
   `#smooth-wrapper {background-color: var(--Bg-dark)}`, `h1,.h1…h6,.h6 {color: var(--White); font-family; font-weight}`,
   `.font-main/.font-2/.font-3`, `.main-menu …`, `.navigation …` (nhiều rule menu tối), `.tf-btn`, `.tf-btn.style-border`,
   `.tf-btn.btn-bg-white`, `.section-cta-3 {position:relative; z-index:2}`, `.section-service-8, .section-testimonial-7
   {background-image …}`. Next gộp CSS mọi niche vào 1 bundle nên chúng RÒ sang niche khác (18 file CSS niche — tất cả trừ
   corporate — có kiểu rò này). Với src/styles/demo-saas.scss: BỌC TOÀN BỘ trong `[data-niche="saas"] { ... }` (SCSS nesting):
   `:root {…}` -> biến trên chính `[data-niche="saas"]` (dùng `&`); `body {color}` -> `color` trên `[data-niche="saas"]`;
   `#smooth-wrapper {…}` -> `#smooth-wrapper {…}` lồng bên trong; mọi rule còn lại lồng nguyên văn (giữ `!important`). KHÔNG đổi
   giá trị/thứ tự. Nếu độ ưu tiên selector đổi làm lệch so với HTML gốc ở chỗ nào, sửa riêng chỗ đó cho khớp bản gốc.
   ĐƯỜNG DẪN ẢNH NỀN: rule `.section-service-8, .section-testimonial-7` dùng `url(../../assets/images/shape/shape-saas.png)`
   (đường dẫn tương đối theo thư mục demo-saas/css, ảnh 1920x634 nằm ở assets/images/shape/). Trong Next phải là đường dẫn public
   `/assets/images/shape/shape-saas.png` (xác nhận file có trong public và request trả 200; ảnh nền hiện ở 2 khối đó như bản gốc).
   Đo lại sau khi bọc (cổng test KHÔNG dùng 5060/5061): màu/font h2 + màu body của `/`, `/demo-agency`, `/demo-saas` và các niche
   đã làm khớp HTML gốc tương ứng, cả khi điều hướng client-side giữa chúng.
3. Font: `.font-2` = Sora, `.font-3` = Manrope (assets/font/fonts.css có sẵn @font-face của cả hai). Xác nhận chúng tải được trong Next
   (h5.title.font-2 ở FAQ render bằng Sora: `document.fonts.check('16px Sora')` true và computed font-family đúng).
4. `ls src/hooks src/components/common` và tái dùng: useSplitTextReveal, useWow, useScrollSmoother, useInfiniteSlide, hook tab giá
   Monthly/Yearly (+ tabSlide), hook accordion 1-mục-mở + collapse transition, useSwiperControls, và nếu aitech/aicontentwriter đã
   làm: useRevealElements (data-ns-animate), TypingPlaceholderInput. Kiểm tra/bổ sung:
   a. useSplitTextReveal có chế độ `effect-up` (from opacity 0, y 20), `effect-blur-fade` (tách "words", fromTo {opacity 0, blur(10px),
      y 20} -> {1, blur(0), 0}, duration 1, stagger 0.1, power3.out) và `split-lines-transform` (tách "lines", from opacity 0, yPercent
      100, autoAlpha 0, stagger 0.2). Mặc định: SplitText "words, chars", duration 0.9, stagger 0.02, ease power3.out; target là `p`/`a`
      con đầu tiên nếu có, không thì chính phần tử.
   b. useRevealElements cho `data-ns-animate` (12 chỗ trang này, kể cả trên thẻ `.swiper` và trên `.thumbs`). Nếu CHƯA có thì tạo theo
      gsapAnimate.js initRevealElements: duration = parseFloat(data-duration) (mặc định 0.6); delay = parseFloat(data-delay) ("0.2s"
      -> 0.2; rỗng -> 0); offset 60; start "top 90%"; end "top 50%"; direction = data-direction || "down" (data-direction=""
      RỖNG vẫn là "down"); đặt trước style opacity 1 + filter blur(0); gsap.from(elem, {opacity 0, filter "blur(16px)", duration, delay,
      ease "power2.out", y +offset (down) | y -offset (up) | x -offset (left) | x +offset (right), scrollTrigger {trigger elem, start,
      end, scrub:false}}). Springer KHÔNG cần (chỉ dùng khi data-spring). Dọn ScrollTrigger khi unmount.
   c. TypingPlaceholderInput — nếu CHƯA có thì tạo, PORT NGUYÊN VĂN main.js animateInput: placeholders = data-placeholders tách "|",
      interval = data-interval || 100ms; typeIn(): isTyping=true, text = placeholders[i], class span "placeholder-text typing-animation
      typing-in", sau 2000ms isTyping=false; typeOut(): nếu isTyping thì thoát; class "placeholder-text typing-animation typing-out"; sau
      800ms i=(i+1)%n rồi typeIn(); khởi động typeIn() một lần rồi setInterval(()=>{ if(!isTyping) typeOut(); }, interval). GIỮ quirk gốc
      (typeOut có thể bị gọi lặp trong 800ms); thêm dọn dẹp khi unmount. `.placeholder-wrapper` phải là phần tử KỀ SAU input trong
      fieldset; input có placeholder=" " (MỘT DẤU CÁCH).
   d. Swiper: KHÔNG dùng navigation={true}/pagination={true} hay object thiếu el/prevEl/nextEl; dots của theme là phần tử THẬT buộc vào
      Swiper bằng ref (useSwiperControls), đặt đúng vị trí như HTML gốc. Cấu hình chung từ carousel.js: speed 1000, observer true, KHÔNG
      loop/autoplay; breakpoints: <575px: `data-mobile` slide, space `data-space`; >=575: `data-mobile-sm`, space `data-space`; >=768: `data-tablet`,
      space `data-space-md`; >=992: `data-preview`, space `data-space-lg`; >=1200: `data-screen-xl` (mặc định = preview), space `data-space-xl`
      (mặc định = space-lg). Dots tìm theo `.sw-pagination-layout` trong vùng `.sw-layout`.
   e. useInfiniteSlide hướng "left" (marquee đối tác): speed mặc định 50 px/s, clone = data-clone, pause khi hover.
5. next/image bắt buộc width/height: ảnh KHÔNG khai báo kích thước trong HTML gốc (dùng kích thước thật của file):
   hero-2.png 208x209 | hero-3.png 201x200 | hero-4.png 481x270 | hero-5.png 220x218 | hero-6.png 201x319 | hero-7.png 497x299 |
   item-1.png 896x927 | item-2.png 697x726 | item-3.png 631x597 | item-4.png 811x704 | item-5.png 410x464 |
   ../assets/images/logo/partner-7.svg 230x48 | partner-8.svg 151x48 | partner-9.svg 201x47 | partner-10.svg 258x48 | partner-11.svg 163x43.
   Ảnh khác đã có width/height trong HTML (hero-1.jpg 1920x880, about-1.jpg 1250x686, service-1/2.jpg 570x429, about-2.jpg 476x476,
   avatar 48x48 và 60x60).
6. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, KHÔNG chỉ kiểm tra; làm ngay ở bước này). Đã đọc HTML: niche này KHÔNG có trang con; trong
   header và offcanvas mobile `#menu-mobile`, MỌI mục ngoài "Demos" (Pages, Services, Project, Blog, Contact) đều trỏ sang trang CORPORATE
   (`../demo-corporate/*.html`; tập link đã so với restaurant: GIỐNG HỆT). Corporate chạy ở route GỐC (không tiền tố):
   | Nhãn menu                  | href trong HTML gốc                       | Route Next                      |
   | Home Corporate             | ../demo-corporate/index.html              | /                               |
   | Pages > About Us           | ../demo-corporate/about-us.html           | /about-us                       |
   | Pages > Our Team           | ../demo-corporate/our-team.html           | /our-team                       |
   | Pages > Team Detail        | ../demo-corporate/team-detail.html        | /team-detail/{slug}             |
   | Pages > Carrer             | ../demo-corporate/carrer.html             | /carrer                         |
   | Pages > Carrer Detail      | ../demo-corporate/carrer-detail.html      | /carrer-detail/{slug}           |
   | Pages > FAQs               | ../demo-corporate/FAQs.html (F hoa)       | /faqs                           |
   | Services > Services        | ../demo-corporate/services.html           | /services                       |
   | Services > Services Detail | ../demo-corporate/service-detail.html     | /service-detail/{slug}          |
   | Project > Porfolio         | ../demo-corporate/portfolio.html          | /portfolio                      |
   | Project > Portfolio Detail | ../demo-corporate/portfolio-detail.html   | /portfolio-detail/{slug}        |
   | Blog > Blog Full Width     | ../demo-corporate/blog-full-width.html    | /blog-full-width                |
   | Blog > Blog With Sidebar   | ../demo-corporate/blog-with-sidebar.html  | /blog-with-sidebar              |
   | Blog > Blog Detail         | ../demo-corporate/blog-detail.html        | /blog-detail/{slug}             |
   | Contact                    | ../demo-corporate/contact.html            | /contact                        |
   - {slug}: LẤY từ menu của corporate (src/data/demo-corporate/menu.ts đang dùng slug đầu tiên cho các mục "...Detail"), KHÔNG gõ tay/đoán.
     Route "...Detail" không slug sẽ 404.
   - "404 Error": làm ĐỒNG NHẤT với menu corporate (đã bỏ); nếu niche đang có sẵn thì giữ nguyên trạng thái hiện tại.
   - Nhãn "Porfolio" là lỗi gõ -> "Portfolio" (nếu corporate vẫn ghi "Porfolio" thì sửa luôn ở corporate cho đồng nhất). Mục "Contact" cấp 1 có
     2 thẻ <span> cùng chữ (hiệu ứng hover) là đúng markup gốc.
   - "Home SaaS" trỏ chính nó (/demo-saas); "Home <niche khác>" trỏ /demo-<niche>: niche CHƯA làm sẽ 404 cho tới khi làm tới — dự kiến, chỉ
     liệt kê, KHÔNG sửa.
   Cách làm: (a) đọc src/data/demo-corporate/menu.ts, src/data/demo-saas/menu.ts, components/layout/demo-saas/ (Header, MobileNav,
   HeaderSection); (b) in BẢNG TRƯỚC (nhãn | href hiện tại | route đích | khác không) — mục trỏ "#", route không tồn tại như /demo-saas/about,
   Detail không slug, hay còn ".html" đều phải sửa; (c) sửa dữ liệu menu theo bảng, ưu tiên MỘT NGUỒN (import mảng của corporate nếu có
   export, không thì copy href kèm comment `// mirrors demo-corporate/menu.ts`); KHÔNG đổi cấu trúc menu corporate; giữ mega-menu Demos,
   class, hover, accordion mobile; (d) cả BA nơi render menu (header cố định/thường, offcanvas mobile) đọc cùng dữ liệu; dùng <Link>.
   KHÔNG tạo route /demo-saas/about... KHÔNG sửa FOOTER (đã làm ở đợt Footer trước).
7. Tên file dữ liệu: src/data/demo-saas/features.ts, services.ts, pricing.ts, testimonials.ts, faqs.ts, partners.ts.

## NHÓM 1 — HERO + FEATURES
### Hero `hero-banner-8` (nằm TRONG smooth-content, trước main-content)
- `.thumbs` > img hero-1.jpg 1920x880 (loading lazy như gốc). `.content > .tf-container`: h1.mb_16 data-ns-animate data-duration="1"
  "Supercharge Your Workflow"; p.text-body-2.mb_36 data-ns-animate data-duration="1" data-delay="0.2s" "Automate tasks, analyze data, and
  scale faster all in one powerful platform."; `form.form-newsletter.style-7.mb_36` data-ns-animate data-duration="1" data-delay="0.4s"
  action="#": `div.position-relative.input-animate-container > fieldset.position-relative > input[type=email].input-field.animated-input
  placeholder=" " data-placeholders="Enter your email"` + `div.placeholder-wrapper > span.placeholder-text.typing-animation + span.cursor`;
  rồi `button[name=submit][type=submit].tf-btn.btn-switch-text > span > span.btn-double-text.text-body-1.fw-6 data-text="Try Chatbot For
  Free"` "Try Chatbot For Free" (hover đổi chữ là CSS). onSubmit preventDefault. Cuối: `.trust.d-flex.align-items-center.
  justify-content-center.gap_12`: `.group` 3 avatar 48x48 group-avatar-4-1/2/3.jpg (wow fadeInLeft, delay 0.1/0.2/0.3s) + p.text-caption-1.
  text_white.wow.fadeInUp data-wow-delay="0.2s" "Over 50,000 users trust us."
- `.floating-images` (con của hero, sau .content): 6 `div.item-N.position-absolute.floating-card` đều data-ns-animate data-duration="1":
  item-1: data-direction="left", class thêm md-hide, img hero-2.png | item-2: "left", lg-hide, hero-3.png | item-3: data-direction="" (rỗng
  -> "down"), md-hide, hero-4.png | item-4: "right", lg-hide, hero-5.png | item-5: "right", md-hide, hero-6.png | item-6: "" (down), md-hide,
  hero-7.png.
### `section-feature-3`
- `.tf-container.medium.tf-spacing-1 > div.thumbs` data-ns-animate data-duration="1": img about-1.jpg 1250x686 (lazy) + `.item-1.position-absolute`
  (img item-1.png) + `.item-2.position-absolute` (img item-2.png).
- `.tf-container > .wrap-partner`: p.text-label.text_white.text-uppercase.text-center.lh-16.mb_32.split-text.effect-up "50,000+ creative professionals
  and teams rely on us every day"; `.wrap-infiniteslide > .infiniteslide` data-clone="2" data-style="left" gồm 10 `.marquee-item > img`:
  partner-7, 8, 9, 10, 11 rồi lặp lại 7, 8, 9, 10, 11 (10 item trong HTML gốc, ảnh ../assets/images/logo/, kích thước ở Bước 0.5). Marquee
  hướng trái, speed 50 px/s, pause khi hover.
- `.wrap-box-icon.tf-spacing-1 > .tf-container.medium > .tf-grid-layout.lg-col-4.md-col-2.gap_30` 4 `.tf-box-icon.style-4.wow.fadeInLeft`
  (data-wow-delay "", "0.1s", "0.2s", "0.3s"): `.content` > `.icon.mb_22 > i.icon-Clock | icon-ChartBar | icon-Group | icon-HandPointing`
  + a.h5.link.mb_12 (href "#") + p.text_muted.text-body-default; rồi a.btn-arrow.link (href "#") > div.position-relative > span.text.text-button
  "Read More" + i.icon-ArrowRight. 4 mục: "Save Time" / "Automate repetitive tasks and focus on what really matters."; "Better Insights" /
  "Track performance and make smarter decisions."; "Work Together" / "Collaborate easily across teams and projects."; "Easy To Use" /
  gốc "Clean interface, zero learning curve get started in minutes." (thiếu dấu "—" giữa 2 vế, cùng kiểu lỗi đã gặp ở các niche trước) ->
  SỬA thành "Clean interface, zero learning curve — get started in minutes."

## NHÓM 2 — SERVICES + ABOUT
### `section-service-8 tf-spacing-1 pb-0`
- `.tf-container.medium > heading-section-4.text-center.d-grid.gap_12.mb_24.mb_40`: tag (text-label text-uppercase wow fadeInUp text_white
  mx-auto) gốc "how it works" (nhãn đặt nhầm — đây là khối "Our Services"; cùng cách xử lý đã dùng ở aitech/aicontentwriter) -> SỬA thành
  "Our Services"; h3.title.split-text.effect-blur-fade "Our Services"; p.desc.text-body-2.text_placehover.split-text.split-lines-transform
  "Smart solutions built to grow your business."
- `.tf-grid-layout.md-col-2.gap_30` data-ns-animate data-duration="1": 2 `.service-item.style-2`: `.content.mb_32` (a.h4.link.mb_8 href "#" +
  p.text_placehover.text-body-default) + `.img-style` (img 570x429 lazy service-1.jpg / service-2.jpg) + `.shape.position-absolute` (img
  item-3.png 631x597, cả hai item dùng cùng ảnh): "Custom SaaS Development" / "Tailored web and mobile solutions built to scale with your
  business."; "Data & Analytics Integration" / "Connect your platforms and unlock actionable insights with ease."
- Nền: ảnh shape-saas.png (CSS, đã xử lý ở Bước 0.2).
### `section-about-4 tf-spacing-1`
- `.tf-container.medium > .row.align-items-xxl-start.align-items-center`: col-lg-6.position-relative > `.thumbs` > `.img-style.wow.fadeInLeft` (img
  about-2.jpg 476x476 lazy) + `.item.position-absolute` (img item-4.png 811x704). col-lg-6: heading-section-4.mb_24.d-grid.gap_16 [tag "About Us"
  (text-label text-uppercase wow fadeInUp text_white mb_8), h3.title.split-text.effect-blur-fade "Simple Solutions For Complex Needs", p.desc.
  text-body-default.text_muted.split-text.split-lines-transform "We create smart SaaS products that simplify work and support your growth."] +
  `.wrap-list > ul.list.d-grid.gap_12` 5 `li.text-body-default.text_white.wow.fadeInUp` (data-wow-delay: không có, 0.2s, 0.4s, 0.6s, 0.8s; KHÔNG có icon):
  "Simple Solutions for Complex Needs", "Solving Complexity with Simplicity", "Simplifying the Complex", "Turning Complexity into Clarity", "Smart Tools
  for Tough Problems" (5 câu diễn đạt lại cùng một ý — lỗi demo, giữ nguyên).

## NHÓM 3 — PRICING + TESTIMONIAL
### `section-pricing-4 flat-animate-tab pricing-container sw-layout`
- `.wrap.tf-spacing-12.pt-0 > .tf-container.medium > .row.align-items-center`: col-lg-4 `.box-left` + col-lg-8 `.tab-content`.
- box-left: heading-section-4.d-grid.gap_16.mb_32 [tag "Pricing" (text-label text-uppercase wow fadeInUp text_white), h3.title.split-text.
  effect-blur-fade "Plans That Work", p.desc.text-body-default.text_muted.split-text.split-lines-transform: gốc "Transparent pricing with no hidden fees
  upgrade or scale anytime as your team grows." (thiếu dấu) -> SỬA thành "Transparent pricing with no hidden fees — upgrade or scale anytime as your
  team grows."]; `.tab-slide.style-1.d-flex.wow.fadeInUp` (data-wow-delay="0.2s") > `ul.menu-tab.d-inline-flex.align-items-center.
  justify-content-center[role=tablist]` có `<li class="item-slide-effect">` + 2 tab: "Pay Monthly" (li.active, data-pricing="monthly") và "Pay Yearly"
  (data-pricing="year"); không có tab-pane.
- col-lg-8 `.tab-content > .swiper` data-preview=2 data-tablet=2 data-mobile=1 data-space-lg=30 data-space-md=20 data-space=15 (theo carousel.js:
  <768px: 1 slide, space 15; 768–991px: 2 slide, space 20; >=992px: 2 slide, space 30) và dots `div.sw-dots.style-white.position-relative.z-5.
  sw-pagination-layout.text-center.mt_24` (đã xác minh bằng phân tích DOM: dots là con trực tiếp của `.swiper`, sau `.swiper-wrapper`); buộc dots bằng ref.
  2 slide:
  (1) Premium — `.pricing-item.style-3.wow.fadeInRight` data-wow-delay="0.2s": `.content`: `.heading.mb_12.d-flex.gap_12.align-items-center.justify-content-between`
  [h5.title "Premium" + `.tag.text-button.text_white` "Save 25%"]; p.text-body-default.text_placehover.mb_20 gốc "Ideal for individuals who who need advanced
  features and tools for client work." (gõ trùng "who who") -> SỬA "Ideal for individuals who need advanced features and tools for client work.";
  h3.price.text_white.mb_26.price-value data-monthly="9.99" data-yearly="49.9" > "$" + span.wrap-price > span > (span.price-month +
  span.price-year, markup ban đầu rỗng — JS điền) + span.text-body-default.fw-4.price-period; a.tf-btn.btn-switch-text.w-full.mb_40 > span >
  span.btn-double-text data-text="Get Started" "Get Started"; ul.list 3 li.text-body-default.text_white (i.icon-Check): "Unlimited Projects", "Up to 15 team
  members", "Advanced Analytics". Ngoài `.content`: `.item.position-absolute` > img item-5.png 410x464.
  (2) Basic — `.pricing-item.style-3.free.wow.fadeInRight` data-wow-delay="": heading.mb_12 (chỉ h5.title "Basic"); p "Perfect for individuals and small teams
  just getting started."; h3.price.text_white.mb_23.price-value > span.price-amount "Free" (KHÔNG có price-month/price-year/price-period, KHÔNG có
  data-monthly); a.tf-btn.btn-switch-text.w-full.btn-bg-white.mb_40 "Get Started" (data-text); ul.list: li (i.icon-Check) "1 Project Workspace"; li.disable
  (i.icon-Close) "Up to 3 team members"; li.disable (i.icon-Close) "Basic Analytics".
- CƠ CHẾ ĐỔI GIÁ (main.js initSwitchPriceValue — làm đúng): trong `.pricing-container`, các phần tử `[data-pricing]` là tab; với mỗi `.price-value` mà có ĐỦ
  .price-month, .price-year VÀ .price-period thì: .price-month = data-monthly, .price-year = data-yearly; tab "monthly" -> .price-month có class active, .price-year
  bỏ active, `.price-period` = "/ month"; tab khác ("year") -> ngược lại và "/ year"; phần tử thiếu 1 trong 3 (gói Basic) thì BỎ QUA hoàn toàn (giữ "Free"). Mặc
  định chạy "monthly" => Premium hiển thị "$9.99 / month" (chữ "/ Month" trong markup gốc bị JS đổi thành "/ month" ngay khi khởi tạo — hiển thị cuối cùng là
  "/ month"); bấm "Pay Yearly" -> "$49.9 / year". Bấm tab còn đặt class active cho đúng thẻ a[data-pricing]. tabSlide: `.item-slide-effect` width = outerWidth của
  li.active, translateX(left của li) khi click, resize và lúc khởi tạo (transition 0.5s trong SCSS). Tái dùng hook tab giá đã có.
### `section-testimonial-7 tf-spacing-1 sw-layout`
- `.tf-container > heading-section-4.text-center.mb_42`: tag "TESTIMONIAL" (viết hoa sẵn; text-label text-uppercase wow fadeInUp text_white mb_16); h3.title.
  split-text.effect-blur-fade "What People Are Saying". Ngoài tf-container: `.swiper` data-ns-animate data-duration="1" data-screen-xl=4 data-preview=3 data-tablet=2
  data-mobile-sm=2 data-mobile=1 data-space-lg=20 data-space-md=20 data-space=15 (theo carousel.js: <575px: 1 slide space 15; 575–767px: 2 slide space 15;
  768–991px: 2 slide space 20; 992–1199px: 3 slide space 20; >=1200px: 4 slide space 20), dots `div.sw-dots.style-white.position-relative.z-5.sw-pagination-layout.
  text-center.mt_24` (con trực tiếp của `.swiper` sau wrapper — đã xác minh bằng phân tích DOM), buộc bằng ref. Lưu ý `data-ns-animate` nằm trên chính thẻ .swiper (reveal cả khối).
- 4 `.swiper-slide > .testimonial-item.style-6`: `div` > `ul.ratings.d-flex.mb_10.gap_4.mb_24` 5 `li > i.icon-Star` + p.text-body-default.text_white lời nhận xét; `.author.d-flex.gap_16.
  align-items-center`: `.avatar` > img 60x60 + div > a.h6.d-block.link.text_white.mb_8 tên (href "#") + span.text-caption-1.text_on-suface-1 chức danh:
   1 "This tool saved us hours every week. Everything feels faster and easier now" — Tatiana Workman, Marketing Manager (avatar-19.jpg)
   2 "I love how clean and intuitive the interface is. Our team adopted it in a day" — Terry Workman, Product Designer (avatar-20.jpg)
   3 "We scaled from 3 to 30 users with zero hassle. Support was fantastic." — Tatiana George, COO at a SaaS startup (avatar-21.jpg)
   4 "Finally, software that just works — no learning curve, no clutter." — Tatiana George, COO at a SaaS startup (avatar-22.jpg)
  (Tatiana George xuất hiện 2 lần với avatar khác — lỗi demo, giữ nguyên.) Avatar là ảnh dùng chung ../assets/images/avatar/.
- Nền: ảnh shape-saas.png (CSS, Bước 0.2).

## NHÓM 4 — FAQS + CTA (WEBGL)
### `section-faqs-3 tf-spacing-1 pt-0`
- `.tf-container.medium > .row`: col-lg-4 `.box > .heading-section-4`: tag "FAQs" (text-label text-uppercase wow fadeInUp text_white mb_20) + h2.title.font-2.
  split-text.effect-blur-fade "Frequently Asked Questions"; col-lg-8 `ul.accordion-wrap.d-grid.gap_16#accordion-faq` gồm 5 `li.accordion-item.style-5.wow.fadeInRight`
  (data-wow-delay "0s", "0.2s", "0.4s", "0.6s", "0.8s"): a.accordion-title (data-bs-toggle="collapse") > .heading > h5.title.text-capitalize.font-2 (chữ "Q1: …" nằm
  TRONG tiêu đề) + span.icon; panel `.collapse` (câu 1 `.collapse.show`, data-bs-parent="#accordion-faq") > .accordion-faqs-content > p.text-body-default.text_muted.
  Câu hỏi: "Q1: How does the free trial work?" / "Q2: Can I change my plan later?" / "Q3: Is my data secure?" / "Q4: Do you offer team accounts?" / "Q5: What
  happens when my trial ends?". CẢ 5 câu trả lời gốc GIỐNG HỆT nhau ("Yes, you can upgrade, downgrade, or cancel your plan anytime from your dashboard.") —
  lỗi demo, GIỮ NGUYÊN (cùng quyết định đã áp dụng cho FAQ của insurance/aitech/aicontentwriter).
- Hành vi: Bootstrap collapse với data-bs-parent => CHỈ 1 MỤC MỞ; câu 1 mở sẵn. li KHÔNG có class action_click/active (JS accordionActive không áp dụng): trạng thái
  icon do class/aria của `a.accordion-title` (collapsed/aria-expanded) — đọc SCSS `.accordion-item.style-5` để biết cái gì đổi icon rồi đặt đúng. Dùng hook accordion
  1-mục-mở + collapse transition chuẩn của dự án.
### `section-cta-3 tf-spacing-1 pt-0` — HIỆU ỨNG WEBGL MÉO ẢNH THEO CHUỘT
- `.tf-container.medium > div.box.tf-image-distortion` data-background="images/bg-1.jpg" (ảnh 1290x344): h2.mb_12.title.split-text.effect-blur-fade.
  position-relative.z-5 "Ready To Get Started?"; p.text-body-2.text_white.mb_40.split-text.split-lines-transform.position-relative.z-5 "Create your free account
  in minutes. No credit card needed."; `form.form-newsletter.style-1.wow.fadeInUp` data-wow-delay="0.4s" action="#": `.wrap.gap_12` > `fieldset.position-relative` >
  input[type=email].tb-my-input.style-border name="email" placeholder="Enter Your Email" required; button[name=submit][type=submit].tf-btn.btn-switch-text > span >
  span.btn-double-text.text-body-1.fw-6 data-text="Get Started" "Get Started". onSubmit preventDefault.
- ĐÃ XÁC MINH trên HTML gốc (Playwright + WebGL): trang cuối nạp `<script type="module" src="../assets/js/distortion-img.js">` — dựng canvas WebGL (OGL + Flowmap)
  làm con CUỐI của `.tf-image-distortion` (canvas position:absolute 100% theo CSS `.tf-image-distortion`, kích thước 1290x344 ở viewport 1440); đồng thời main.js getDataImage
  gán CSS `background-image: url(data-background)` cho phần tử.
- Làm component client `ImageDistortionBox` (thân là div.box.tf-image-distortion + children), logic PORT ĐÚNG distortion-img.js:
  * Thư viện: file assets/js/distortion-img-depend.js (131KB) chính là OGL (xuất Renderer, Program, Mesh, Vec2, Texture, Flowmap, Plane...). Ưu tiên SAO CHÉP file
    gốc này vào dự án (vd src/lib/ogl/distortion-img-depend.js, thêm `// @ts-nocheck` hoặc khai báo type) để API/hành vi y hệt; chỉ dùng `npm i ogl` nếu đã kiểm tra
    Flowmap/Renderer cho kết quả giống hệt. Import động trong useEffect (client-only, không chạy khi SSR).
  * Khởi tạo: `renderer = new Renderer()` (tuỳ chọn mặc định); `gl = renderer.gl`; `background.appendChild(gl.canvas)` — gắn bằng DOM trong effect (KHÔNG render canvas
    qua JSX) để canvas luôn là con CUỐI như gốc; resize(): rect = background.getBoundingClientRect(); aspect = rect.width/rect.height; gl.canvas.width/height = rect.width/height;
    renderer.setSize(rect.width, rect.height); gọi resize() ngay và khi window resize.
  * `flowmap = new Flowmap(gl, { falloff: 0.3, dissipation: 0.95, size: 1000 })`; `geometry = new Plane(gl)`; `texture = new Texture(gl)`; ảnh `new Image()` với
    crossOrigin "anonymous", onload: texture.image = img; minFilter/magFilter = gl.LINEAR; wrapS/wrapT = gl.CLAMP_TO_EDGE; src = data-background.
  * Shader — vertex: `attribute vec2 uv; attribute vec2 position; varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position, 0.0, .45); }` (w = 0.45
    làm ảnh phóng lớn ~2.2 lần); fragment: `precision highp float; uniform sampler2D tImage; uniform sampler2D tFlow; varying vec2 vUv; void main(){ vec3 flow =
    texture2D(tFlow, vUv).rgb; vec2 uv = vUv; uv += (flow.rg * flow.b * 50.0); vec3 tex = texture2D(tImage, uv).rgb; gl_FragColor.rgb = tex; gl_FragColor.a = 1.0; }`;
    `program = new Program(gl, { vertex, fragment, uniforms: { tImage: { value: texture }, tFlow: flowmap.uniform } })`; `mesh = new Mesh(gl, { geometry, program })`.
  * Chuột/cảm ứng: listener `mousemove` và `touchmove` (chạm đầu tiên) trên CHÍNH `.tf-image-distortion`: x = (clientX - rect.left)/rect.width; y = 1 - (clientY - rect.top)/rect.height;
    mouse.set(x, y). Khởi tạo mouse = lastMouse = Vec2(0.5), velocity = Vec2().
  * Vòng lặp requestAnimationFrame (spring = 0.04, friction = 0.8, springVel = Vec2): mỗi frame `springVel.copy(mouse).sub(lastMouse).multiply(spring); velocity.add(springVel).
    multiply(friction); lastMouse.add(velocity); flowmap.mouse.copy(lastMouse); flowmap.velocity.copy(velocity); flowmap.aspect = aspect; flowmap.update(); renderer.render({ scene: mesh });
    requestAnimationFrame(update)`.
  * Dọn dẹp khi unmount (gốc không dọn, React phải dọn): cancelAnimationFrame, gỡ listener (mousemove, touchmove, resize), gỡ canvas khỏi DOM,
    `gl.getExtension("WEBGL_lose_context")?.loseContext()`. React Strict Mode chạy effect 2 lần ở dev: bảo đảm chỉ còn MỘT canvas, một vòng lặp.
  * Ảnh nền CSS: đặt `style={{ backgroundImage: 'url(/assets/…/bg-1.jpg)' }}` (tương đương getDataImage) và giữ thuộc tính data-background; bg-1.jpg copy vào public như các ảnh khác.
- SỬA LỖI TƯƠNG TÁC TRONG HTML GỐC (đã áp dụng cách xử lý "lỗi làm hỏng chức năng, giữ nguyên diện mạo"): ở bản gốc canvas (con cuối, position:absolute) PHỦ LÊN form,
  document.elementFromPoint tại ô email và nút "Get Started" đều trả về CANVAS => ô nhập và nút KHÔNG bấm được (h2 và p thì có position-relative z-5 nên không bị che, chỉ form
  bị quên). Thêm class `position-relative z-5` cho thẻ `form.form-newsletter.style-1` để form nằm trên canvas; hiệu ứng méo vẫn chạy vì sự kiện chuột gắn trên `.box`. Ghi vào báo cáo.
  Diện mạo phải giữ y hệt bản gốc.

## VERIFY (Playwright; mở HTML gốc qua server tĩnh và Next ở cùng độ rộng; nếu đã cài scripts/viora-check.mjs và viora-links.mjs thì dùng; KHÔNG dùng Claude in Chrome)
- Để WebGL chạy trong Chromium headless, khởi chạy với args `["--use-gl=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]` (đã thử trên HTML gốc, WebGL OK).
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font (Sora/Manrope), link không gạch chân, nền tối đúng (computed background của
  #smooth-wrapper và màu chữ body khớp bản gốc), ảnh nền shape-saas.png hiện ở service-8 và testimonial-7 (request 200), không ảnh lỗi/404, có #smooth-wrapper.
- Rò rỉ CSS: sau khi bọc [data-niche], màu/font h2 + màu body ở các niche khác không đổi so với HTML gốc, cả khi điều hướng client-side.
- Hero: placeholder gõ chữ lặp đúng nhịp (ghi các lần đổi class typing-in/typing-out ~8 giây ở bản gốc và Next, so thời điểm); các phần tử data-ns-animate: trước khi cuộn tới
  mờ + blur(16px) + lệch 60px theo direction (left/right/down), qua mốc "top 90%" chạy 1 lần đúng duration/delay; 6 ảnh floating ẩn đúng theo md-hide/lg-hide.
- Marquee đối tác: chạy sang trái, 10 item, pause khi hover. 4 box-icon wow fadeInLeft đúng delay.
- Pricing: nhãn "Pay Monthly"/"Pay Yearly"; mặc định Premium "$9.99 / month"; bấm Yearly -> "$49.9 / year"; Basic luôn "Free"; thanh trượt tab đúng vị trí 0.5s; Swiper 2/2/1 slide
  theo breakpoint, dots bấm được; số `.swiper-button-*` / `.swiper-pagination` mặc định = 0 trên cả trang.
- Testimonial: 4/3/2/2/1 slide theo breakpoint (>=1200, 992–1199, 768–991, 575–767, <575), dots hoạt động, không loop; reveal cả khối.
- FAQ: câu 1 mở sẵn, chỉ 1 mục mở, có transition, icon đổi đúng.
- CTA WebGL: có đúng 1 `canvas` là con cuối của `.tf-image-distortion`, kích thước bằng khung (1290x344 ở 1440px); rê chuột trong khung làm ảnh méo (so ảnh chụp canvas trước/sau
  khi rê chuột: pixel thay đổi) và hồi lại dần (friction); `document.elementFromPoint` tại ô email và nút trả về chính input/button (KHÔNG phải canvas); gõ được vào ô email, bấm được nút;
  chuyển sang trang khác rồi quay lại không nhân đôi canvas/vòng lặp, không cảnh báo "too many WebGL contexts" trong console.
- Menu: quét link từ /demo-saas (desktop hover dropdown + mobile ≤991px offcanvas, accordion, bấm từng mục): MỌI link Pages / Services / Project / Blog / Contact -> 200 và vào đúng
  trang corporate; liệt kê riêng 404 chỉ do niche chưa làm; không còn ".html".
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả bọc CSS niche (file đã bọc, đường dẫn ảnh nền đã sửa, kết quả đo rò rỉ); hook/component mới (ImageDistortionBox + cách lấy OGL, useRevealElements,
TypingPlaceholderInput nếu mới tạo); nội dung đã sửa (tag "how it works" -> "Our Services", "who who", 2 chỗ thiếu dấu "—", thêm z-5 cho form CTA); kết quả đo từng điểm trên; việc chưa xong.