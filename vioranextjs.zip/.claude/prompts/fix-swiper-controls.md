Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

LỖI: ở /demo-medical (và có thể mọi trang có Swiper đã làm), nút điều hướng và
dots của Swiper hiển thị SAI so với HTML gốc:
  1. Hero: có 2 mũi tên XANH to (kiểu mặc định của Swiper) ở sát mép trái/phải,
     cạnh nút tròn trắng của theme; có 3 chấm xám nhỏ ở góc dưới-trái (đáng ra
     ở màn rộng KHÔNG có dots).
  2. Testimonial: có 2 mũi tên XANH to bên trong khung, và nút tròn trắng của
     theme nằm XA hơn bản gốc (ở 1919px: Next ~250px / ~1630px, gốc 375px / 1485px).

## NGUYÊN NHÂN (đã xác minh từ mã nguồn swiper-react, KHÔNG phải đoán)
Trong swiper-react, hàm needsNavigation(params) = true khi `navigation` là `true`
HOẶC là object KHÔNG có prevEl/nextEl; needsPagination(params) = true khi
`pagination` là `true` HOẶC object KHÔNG có `el`. Khi true, <Swiper> TỰ VẼ THÊM
<div class="swiper-button-prev">, <div class="swiper-button-next"> và
<div class="swiper-pagination"> (đây là các mũi tên xanh / chấm xám mặc định).
Còn HTML gốc đã có sẵn nút/dots RIÊNG của theme (.nav-prev-layout,
.nav-next-layout, .sw-pagination-layout) và nằm BÊN TRONG .swiper.
Bản Next đang (a) để Swiper tự vẽ nút/dots mặc định, và (b) đặt nút theme NGOÀI
root <Swiper> nên .swiper không còn là khung tham chiếu (position:relative) của
chúng -> nút bị lệch vị trí.
(Đây là chẩn đoán dựa trên mã nguồn thư viện + ảnh chụp, CHƯA thấy code của bạn:
bước 1 bên dưới là để xác nhận.)

## SỐ ĐO CHUẨN trên HTML gốc ở 1919px (Playwright)
- Số phần tử `.swiper-button-prev/.swiper-button-next` trong HTML gốc = 0.
- Hero (.tf-slider-2): .swiper full 1919x800 (position:relative). Nút prev ở
  x=40, nút next ở x=1819 (absolute, left/right 40px, cao 60x60, căn giữa dọc
  ~y=400), đều nằm trong .swiper. Dots (.sw-dots) display:none.
  Quy tắc SCSS (_hero.scss): `.tf-slider-2 .sw-dots {display:none; position:
  absolute; bottom:30px; z-index:2}` và `@media (max-width:1610px)
  { .sw-button {display:none} .sw-dots {display:block} }`. Tức: >1610px hiện nút,
  ẩn dots; <=1610px ẩn nút, hiện dots. (LƯU Ý: trong medical-home-final.md trước
  đó ghi "nav ẩn <=1199px" là SAI — mốc đúng của hero là 1610px theo SCSS này.)
- Testimonial (.section-testimonial-3): .swiper rộng 1170 tại x=375, cao 226.
  Nút prev: absolute left:0 (x=375); nút next: absolute right:0 (x=1485); top 113px
  trong .swiper. Nút nằm TRONG .swiper.

## BƯỚC 1 — Xác nhận nguyên nhân trong code (chạy lệnh, báo kết quả)
- `grep -rn "<Swiper" src --include=*.tsx` liệt kê MỌI chỗ dùng Swiper (hero,
  testimonial, services, insights, pricing, projects... của corporate, agency,
  insurance, medical, landing).
- Với từng chỗ, ghi lại: có prop `navigation` / `pagination` không, ở dạng nào
  (`true`, object không có prevEl/nextEl/el, hay có đủ), và nút/dots của theme
  được render ở đâu (con của <Swiper> hay bên ngoài).
- Mở /demo-medical bằng Playwright, đếm
  `document.querySelectorAll('.swiper-button-prev,.swiper-button-next,.swiper-pagination').length`
  (phải = 0 sau khi sửa) và xem nút theme có phải con của `.swiper` không.

## BƯỚC 2 — Tạo 1 hook dùng chung (đừng sửa rời rạc từng chỗ)
Tạo src/hooks/useSwiperControls.ts:

```ts
import { useRef } from "react";
import type { Swiper as SwiperType } from "swiper";
import type { NavigationOptions, PaginationOptions } from "swiper/types";

export function useSwiperControls() {
  const prevRef = useRef<HTMLDivElement>(null);
  const nextRef = useRef<HTMLDivElement>(null);
  const dotsRef = useRef<HTMLDivElement>(null);

  // Gán phần tử THẬT của theme cho Swiper TRƯỚC khi nó init.
  const onBeforeInit = (swiper: SwiperType) => {
    const nav = swiper.params.navigation as NavigationOptions | undefined;
    if (nav) { nav.prevEl = prevRef.current; nav.nextEl = nextRef.current; }
    const pag = swiper.params.pagination as PaginationOptions | undefined;
    if (pag) { pag.el = dotsRef.current; }
  };

  return { prevRef, nextRef, dotsRef, onBeforeInit };
}
```

Cách dùng (ví dụ hero) — QUAN TRỌNG: truyền `prevEl/nextEl/el` là `ref.current`
(lần render đầu là `null`, không phải `undefined`, nên Swiper KHÔNG tự vẽ phần tử
mặc định), và đặt nút/dots của theme làm CON của <Swiper> (không phải
<SwiperSlide>) để chúng nằm TRONG .swiper như HTML gốc:

```tsx
const { prevRef, nextRef, dotsRef, onBeforeInit } = useSwiperControls();
<Swiper
  modules={[Navigation, Pagination, EffectFade]}
  navigation={{ prevEl: prevRef.current, nextEl: nextRef.current }}
  pagination={{ el: dotsRef.current, clickable: true }}
  onBeforeInit={onBeforeInit}
  /* ...các prop khác giữ nguyên theo HTML gốc... */
>
  <SwiperSlide>...</SwiperSlide>
  <div ref={prevRef} className="...copy y hệt class gốc nút prev..." />
  <div ref={nextRef} className="...copy y hệt class gốc nút next..." />
  <div ref={dotsRef} className="...copy y hệt class gốc dots..." />
</Swiper>
```
(Mở HTML gốc copy ĐÚNG markup/class/icon của nút và dots; nếu nút gốc là <div>
hay <a>/<button> thì dùng đúng thẻ đó.) KHÔNG dùng `navigation={true}`,
`pagination={true}`, `navigation={{}}` hay `pagination={{ clickable: true }}` không
có `el`. KHÔNG import thêm swiper/css/navigation hay swiper/css/pagination.

## BƯỚC 3 — Áp dụng cho TẤT CẢ Swiper tìm được ở Bước 1
Không chỉ medical: sửa mọi Swiper có nút/dots theo hook trên (corporate, agency,
insurance, medical, landing nếu có). Swiper không có nút/dots thì giữ nguyên.
Hero medical: nhớ đúng quy tắc hiển thị theo SCSS gốc (mốc 1610px), không tự đặt
mốc khác. Testimonial/các swiper khác: đo HTML gốc để biết mốc hiện/ẩn nút và
dots (đọc SCSS của section, đừng suy từ tên class).

## BƯỚC 4 — Verify bằng số (Playwright, mở HTML gốc và Next cùng độ rộng)
Test ở 1919, 1611, 1610, 1440, 991, 575:
- Không còn phần tử mặc định: số `.swiper-button-prev/.swiper-button-next/
  .swiper-pagination` = 0 trên MỌI trang có Swiper (quét toàn bộ route đã làm).
- Hero 1919px: prev x≈40, next x≈1819 (±2px), đều là con của `.swiper`; dots
  ẩn. Ở 1610px trở xuống: nút ẩn, dots hiện và nằm giữa-dưới như bản gốc.
- Testimonial 1919px: prev x≈375, next x≈1485 (±2px), top ≈113px trong .swiper.
- Bấm nút next/prev đổi slide thật; bấm dots đổi slide; nút `swiper-button-disabled`
  hiển thị đúng trạng thái như bản gốc ở slide đầu/cuối.
- So ảnh chụp từng block hero/testimonial giữa gốc và Next, ghi lại sai lệch còn lại.
- `npm run build` pass.

Báo cáo: danh sách file/Swiper đã sửa, trước/sau số đo, các Swiper KHÔNG sửa và lý do.