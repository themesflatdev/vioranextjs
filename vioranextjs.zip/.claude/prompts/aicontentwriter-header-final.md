Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "aicontentwriter" (route
"/demo-aicontentwriter"). Đã XÁC MINH bằng đọc trực tiếp
demo-aicontentwriter/index.html.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (KHÔNG
splitting.min.js). Có #smooth-wrapper/#smooth-content — LƯU Ý: ngay sau
`#smooth-content` mở ra, TRƯỚC header thường, có 1 `.topbar` (banner
khuyến mãi "Exclusive offer...") — đây là NỘI DUNG TRANG CHỦ (Bước 3),
KHÔNG PHẢI một phần của Header, KHÔNG dựng trong HeaderSection.tsx ở bước
này — chỉ cần biết nó tồn tại để không nhầm cấu trúc DOM khi tới lượt làm
trang chủ. `demo-aicontentwriter.scss` có sẵn rule `#smooth-wrapper {
background-color: var(--Bg-light) }` — không cần class phụ nào trong
markup.

2 header "style-10 header-fixed" / "style-10" — ĐÃ DIFF: giống hệt nhau
(chỉ khác class + line-wrap).

Cơ chế scroll: header-fixed (ngưỡng 300px) → dùng `useHeaderFixed` (đã có
sẵn), ĐÚNG như bảng master-workflow.md. Breakpoint: `mobile-button
d-lg-none` → mốc "lg" (991/992).

## 2. PATTERN chung: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

Xác nhận lại đúng (xem memory index-only-niches-reuse-corporate-pages) —
route thật corporate, KHÔNG tiền tố `/demo-aicontentwriter`. Bỏ "404
Error".

## 3. Chi tiết markup riêng

- `tf-container` + mega-menu KHÔNG có class phụ nào ("menu-rounded" không
  có ở niche này).
- header-right: `class="header-right d-flex align-items-center gap_24"`
  — Login link (`class="link text-button text_primary"`, href="#") → CTA
  `<a class="tf-btn style-border btn-hover-animate-border md-hide">Get
  Started</a>` (href="#", ẨN Ở ≤767px — "md-hide", KHÁC aitech dùng
  "sm-hide") → `.mobile-button.d-lg-none`.
- Offcanvas mobile-nav-wrap KHÔNG có class phụ nào (không "style-dark").
- Logo: `logo-AIcontent.svg`.

## 4. Menu (giữ nguyên, không phát hiện bug link nào)

12 demo mega-menu thứ tự y hệt các niche trước, "Home AI Content Writer"
trỏ "/demo-aicontentwriter" (active). Mobile đủ 20 niche, 5 nhóm accordion
Demos/Pages/Services/Project/Blog, Contact link thẳng cuối.

Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥992px main-menu hiện/mobile-button ẩn; ≤991px ngược lại
- Hover 4 submenu mở đúng (CSS hover)
- Login + Get Started hiện đúng; Get Started ẩn ở ≤767px (md-hide, đo đúng
  mốc 767/768 — KHÔNG nhầm sm-hide 575)
- Cơ chế header-fixed: cuộn qua 300px → is-fixed đúng lúc (ngưỡng đơn
  giản, không direction-aware — test đơn giản như corporate/agency, dùng
  trang đủ cao 150vh)
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
