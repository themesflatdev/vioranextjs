Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "lawyer" (route "/demo-lawyer"). Đã
XÁC MINH bằng đọc trực tiếp demo-lawyer/index.html — KHÔNG có bug nội
dung, 2 bản header giống hệt nhau.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer.

2 header "style-18 header-sticky bg-secondary-color" (ngoài) / "style-18"
(trong) — NỘI DUNG GIỐNG HỆT NHAU. Cơ chế scroll: header-sticky →
`useHeaderSticky` (TÁI DÙNG). Breakpoint: `<nav class="main-menu style-2
xl-hide">` + `mobile-button d-xl-none` → mốc "xl" (1199/1200), ĐÚNG như
bảng mục 1. Container `tf-container w-1840`.

## 2. Menu — lawyer TỰ CÓ MẶT trong 12 demo (self-link, không phải bug)

12 demo mega-menu: 10 mục đầu đúng thứ tự chuẩn, mục #11 "Home Lawyer" TỰ
TRỎ VỀ `index.html` (route "/demo-lawyer", tự trỏ chính nó — giống pattern
đã gặp ở charity), mục #12 vẫn "Home Charity" bình thường. Dùng
`desktopDemosFeatured` với `href: "/demo-lawyer"` cho mục #11 là đủ,
KHÔNG phải bug cần sửa.

Pages/Services/Project/Blog/Contact — đúng route corporate, không bug.

## 3. Header-right — box câu hỏi + CTA, KHÔNG icon, KHÔNG search/cart

```
<div class="header-contact sm-hide">
  <div>
    <span class="text-caption-2 text_white">Have any Question?</span>
    <div class="text-button text_white">1-555-678-8888</div>
  </div>
</div>
<a href="#" class="tf-btn btn-hover-animate-2 btn-bg-primary-2 rounded-0 btn-px-32 md-hide">
  <span>Get A Quote</span>
  <span class="bg-effect"></span>
</a>
```
LƯU Ý: header-contact ở đây KHÔNG có `<div class="icon">` (khác charity/
logistics có icon PhoneCall/Headset) — chỉ có text 2 dòng, giữ đúng, KHÔNG
tự thêm icon. header-contact ẩn ở "sm" (≤575px); CTA "Get A Quote" ẩn ở
"md" (≤767px, khác lawyer dùng btn-px-32/rounded-0, giữ đúng class).

Mobile offcanvas (`#menu-mobile`, CÓ class "style-dark") đủ 20 niche,
đúng thứ tự chuẩn, "Lawyer" tự active đúng vị trí. 5 nhóm accordion,
Contact link thẳng cuối. Modal "View all demos": link "/landing#demos".

Logo: `logo-lawyer-1.svg` (167x52 header, 193x44 mobile).

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- KHÔNG có icon search/cart nào render
- header-contact hiện, ẩn đúng ở ≤575px; CTA "Get A Quote" ẩn đúng ở
  ≤767px
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: offcanvas có class "style-dark", Demos đủ 20, mọi link đúng
  route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
