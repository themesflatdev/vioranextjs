Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng
con số, không áng chừng. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-spasalon/index.html (route "/demo-spasalon", route group (demo-spasalon)).
Header/Footer ĐÃ CÓ SẴN (header style-9 header-fixed ngưỡng 300px, mốc menu mobile xl 1199/1200; footer-style-9). Niche này
có NHIỀU TRANG CON sẽ làm SAU — bây giờ CHỈ làm trang chủ. Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS), hero+marquee,
rồi 10 block main-content (ĐÃ ĐỌC ĐỦ), THEO 4 NHÓM; verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Đặc điểm: CÓ ScrollSmoother (`#wrapper` > `#smooth-wrapper` > `#smooth-content`), nền SÁNG (--Bg-light #FBF6F4), font h1…h6 =
Bricolage Grotesque (--font-main2), body = Plus Jakarta Sans (--font-main). 5 font biến (main2/3/4/5 = Bricolage/Outfit/Inter/
Rethink Sans — tất cả có sẵn trong assets/font/fonts.css).

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-spasalon)/layout.tsx: wrapper `data-niche="spasalon"`; cấu trúc #wrapper > #smooth-wrapper > #smooth-content; header
   cố định nằm NGOÀI smooth; HeaderSection gọi useScrollSmoother() + useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE: demo-spasalon/css/spa.css (106 dòng) có selector TOÀN CỤC: `body {color}`, `h1,.h1…h6,.h6
   {font-family: var(--font-main2); font-weight:500; color: var(--Secondary)}`, `.text-caption-1`, `.font-main/.font-3/.font-4/.font-5`,
   `.main-menu …`, `.navigation …` nhiều rule, `.tf-btn`, `.tf-btn.btn-bg-white`, `.text_primary`, `.shape-linear-circle {background:
   linear-gradient…}`. Với src/styles/demo-spasalon.scss: BỌC TOÀN BỘ trong `[data-niche="spasalon"] { ... }` (SCSS nesting): `:root {…}` ->
   biến trên `[data-niche="spasalon"]` (dùng `&`); `body {color}` -> `color` trên `[data-niche="spasalon"]`; mọi rule còn lại lồng nguyên văn.
   Đo lại sau khi bọc: màu/font h2 + màu body ở / và /demo-spasalon khớp HTML gốc tương ứng (cổng KHÔNG dùng 5060/5061).
3. Font: h1…h6 = Bricolage Grotesque (font-main2, assets/font/fonts.css đã có @font-face). Xác nhận computed font-family của h2 đúng sau khi bọc.
4. `ls src/hooks src/components/common` và tái dùng: useSplitTextReveal (effect-up, effect-blur-fade, split-lines-transform, split-lines-rotation-x,
   effect-scale, effect-right), useWow, useScrollSmoother, useInfiniteSlide (up/down/left), hook scroll-transform, tf-animateCLP, useSwiperControls,
   effect-content-slide (CSS thuần theo swiper-slide-active — đã xác nhận ở medical). Không cần data-ns-animate, Atropos, typing placeholder.
5. next/image bắt buộc width/height: ảnh KHÔNG khai báo kích thước (dùng kích thước thật):
   spa-item-2.png 212x426 | spa-item-3.png 483x267 | spa-item-4.png 447x363 | spa-item-5.png 346x409 |
   spa-item-6.png 126x265 | spa-item-7.png 113x362 | spa-item-8.png 334x304.
   spa-item-1.png: xem lại src, có width/height trong HTML gốc (388x354). Ảnh khác đã có kích thước trong HTML.
6. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, làm ngay ở bước này). Đã đọc lại HTML: menu spasalon CÓ CẤU TRÚC RIÊNG, KHÔNG dùng
   chung corporate. Bản đồ đầy đủ (đọc từ header spasalon/index.html):
   | Nhóm   | Nhãn                | href gốc                 | Route Next                     |
   | Demos  | (mega-menu)         | (giữ nguyên như header đã làm)                               |
   | Pages  | About Us            | about.html               | /demo-spasalon/about           |
   | Pages  | Booking             | booking.html             | /demo-spasalon/booking         |
   | Pages  | Our Staffs          | staffs.html              | /demo-spasalon/staffs          |
   | Pages  | Member Details      | member-detail.html       | /demo-spasalon/member-detail   |
   | Pages  | Our Testimonials    | testimonials.html        | /demo-spasalon/testimonials    |
   | Pages  | Calender            | calender.html            | /demo-spasalon/calender        |
   | Pages  | Packages            | packages.html            | /demo-spasalon/packages        |
   | Pages  | FAQs                | faqs.html                | /demo-spasalon/faqs            |
   | Servcs | Our Services        | service.html             | /demo-spasalon/service         |
   | Servcs | Services Detail     | service-detail.html      | /demo-spasalon/service-detail/{slug} |
   | Projct | Our Portfolio       | portfolio.html           | /demo-spasalon/portfolio       |
   | Blog   | Blog List           | bloglist.html            | /demo-spasalon/bloglist        |
   | Blog   | Blog Grid           | bloggrid.html            | /demo-spasalon/bloggrid        |
   | Blog   | Blog Detail         | blogdetail.html          | /demo-spasalon/blogdetail/{slug} |
   | —      | Contact             | contact.html             | /demo-spasalon/contact         |
   - "Porfolio" trong dropdown Project là lỗi gõ -> "Portfolio". "Calender" là lỗi gõ trong HTML gốc — giữ nguyên vì là tên route thật.
   - {slug} cho Service Detail và Blog Detail: lấy slug của item ĐẦU TIÊN trong data tương ứng (services.ts, blogPosts.ts) — KHÔNG để
     trỏ route không slug (404). Vì các trang con CHƯA làm nên slug tạm dùng "placeholder" kèm comment `// TODO: cập nhật khi có data`.
   - Tất cả 16 trang con CHƯA có route trong Next (sẽ làm sau) -> hiện tại BẤM vào menu sẽ 404 là bình thường, dự kiến. Chỉ cần format
     đúng "/demo-spasalon/..." và dùng <Link>, KHÔNG để còn ".html".
   Cách làm: (a) đọc src/data/demo-spasalon/menu.ts và components/layout/demo-spasalon/ (Header, MobileNav, HeaderSection); (b) in BẢNG
   TRƯỚC (nhãn | href hiện tại | route đích | cần sửa không); (c) sửa dữ liệu menu theo bảng; cả 3 nơi render (header cố định, header
   thường, offcanvas mobile) dùng chung dữ liệu; dùng <Link>; (d) kiểm tra KHÔNG còn ".html" và KHÔNG còn link tới demo-corporate trong menu.
   KHÔNG tạo route /demo-spasalon/about... bây giờ (sẽ làm sau). KHÔNG sửa FOOTER.
   LƯU Ý: 3 href trong main-content trang chủ cần sửa riêng:
   - `about.html` -> /demo-spasalon/about (khi trang đó đã có, tạm dùng # nếu chưa)
   - `booking.html` -> /demo-spasalon/booking (khi trang đó đã có, tạm dùng # nếu chưa)
   - `blogdetail.html` (x3) -> /blog-detail/{slug bài đầu tiên của corporate} (lấy từ src/data/demo-corporate/blogPosts.ts)
7. Tên file dữ liệu: src/data/demo-spasalon/services.ts, packages.ts, pricing.ts, testimonials.ts, blogPosts.ts.

## NHÓM 1 — HERO (SWIPER) + MARQUEE + ABOUT
### Hero `.tf-slider-3.sw-layout.effect-content-slide` (NGOÀI main-content, trước nó)
`.swiper` data-effect="fade" data-autoplay="true" (autoplay=true, effect=fade, crossFade như medical/insurance). `.swiper-wrapper` 3 slide,
MỖI slide là `.hero-banner-10 > .thumbs.effect-img-zoom > img.img-zoom 1920x880` (spa-hero-1/2/3.jpg, loading eager) + `.content >
.tf-container`. Các phần tử trong .content dùng class `effect-item effect-up delay-1/2/3` (CSS thuần theo `swiper-slide-active` — KHÔNG cần JS).
3 slide CHỈ KHÁC tiêu đề h2:
  1: "Rejuvenate Your Body, Calm Your Mind"; 2: "Reserve Your Glow"; 3: "Explore Your Inner Calm"
Cùng p và nút cho cả 3: p.text_white.mb_40.text-body-default.effect-item.effect-up.delay-2 "Enter a serene space where beauty begins. Let every
touch restore you."; a.tf-btn.btn-switch-text.mx-auto.effect-item.effect-up.delay-3 > span > span.btn-double-text data-text="Book An Appointment"
"Book An Appointment" (href "#").
Nav/dots: `.wrap-sw-button` (ngoài .swiper): 2 `.sw-button.lg-hide.style-1` (nav-prev/next-layout), ẩn khi >=992px; `.sw-dots.style-white.
sw-pagination-layout.text-center.d-lg-none` (ẩn >=992px). Xác nhận vị trí: nav và dots đều trong .tf-slider-3 nhưng NGOÀI .swiper (khác
section-testimonial của healthcoach). Buộc dots/nav bằng ref (useSwiperControls); cấu hình carousel.js: speed 1000, effect fade crossFade, autoplay,
KHÔNG loop.
effect-img-zoom: đọc SCSS `_hero.scss .effect-img-zoom .img-zoom` — đây là CSS scale ảnh khi slide active (tương tự ken-burns). Không cần JS, giữ
đúng class trên wrapper và img.
### `.wrap-marquee` (con của .tf-slider-3, sau .swiper)
`.infiniteslide` data-clone="2" data-style="left": 10 `.marqee-inner.h6.text_secondary-color > i.icon-CheckCircle + text` (5 cụm lặp 2 lần):
"Rejuvenate your skin", "Relieve body tension", "Boost your confidence", "Feel more balanced", "Relax your mind". Tái dùng useInfiniteSlide.
### `section-about-6 tf-spacing-1`
`.tf-container.medium > .row.align-items-center`: col-lg-5 `.wrap-thumb.position-relative` + col-lg-7 `.content`.
- wrap-thumb: `.thumbs > img.tf-animateCLP-left` 520x670 spa-about-1.jpg (lazy) + `span.shape-linear-circle.wow.fadeIn` data-wow-delay="0.6s"
  (vòng tròn gradient linear màu primary -> transparent, CSS thuần đã có trong spa.css).
- Ngoài `.row` (con trực tiếp của .tf-container.medium, vị trí absolute): `.item.position-absolute.md-hide.scroll-transform` data-direction="right"
  data-distance="20%" > img 388x354 spa-item-1.png.
- content: heading-section.d-grid.gap_12.mb_40 [sub "About Us" (text-label text-uppercase split-text effect-up text_primary-color lh-16),
  h2.title.split-text.effect-blur-fade "Your Sanctuary Of Wellness And Beauty", p.desc.text-body-2.mt_4.wow.fadeInUp data-wow-delay="0.4s" đoạn mô tả];
  a.tf-btn.btn-switch-text.wow.fadeInUp data-wow-delay="0.6s" > span > span.btn-double-text data-text="About Us" "About Us" (href "#" tạm).

## NHÓM 2 — SERVICES + BOOK APPOINTMENT + PACKAGES + SPA EXPERIENCE
### `section-service-7 tf-spacing-10`
`.tf-container.medium`: heading-section.d-grid.gap_12.mb_40 [sub "Our Services" (split-text effect-up text_primary-color), h2.title.split-text.
effect-blur-fade: gốc "Treatments That Truly Rstore." (lỗi gõ thiếu "e") -> SỬA thành "Treatments That Truly Restore.",
p.text-body-2.text_secondary.mt_4.split-text.split-lines-transform "Indulge in personalized treatments designed to relax, renew, and restore your
natural glow."]. Danh sách 4 `.tf-box-icon.style-6.wow.fadeInRight` (không data-wow-delay): `.content-inner` (icon + content) + `.wrap-img.hover-image`
(img-style + btn-arrow): ảnh 360x132, icon icomoon riêng (icon-facial-treatments / icon-body-massage / icon-aromatherapy / icon-body-scrubs):
  "Facial Treatments" / service-spa-1.jpg | "Body Massage" / service-spa-2.jpg | "Aromatherapy" / service-spa-3.jpg | "Body Scrubs & Wraps" /
  service-spa-4.jpg. Mô tả TẤT CẢ 4 dịch vụ giống hệt nhau ("Release tension and stress with our range of massage therapies — from Swedish to hot stone.")
  — lỗi demo, GIỮ NGUYÊN. Ngoài .tf-container.medium: `.item.position-absolute.scroll-transform` (không data-direction/distance) > img spa-item-2.png
  212x426.
### `section-book-appointment-2 tf-spacing-13`
`.tf-container.medium > .row.align-items-center`: col-lg-5 `.content` + col-lg-7 `.thumbs.justify-content-lg-end`.
- content: heading-section.d-grid.gap_12.mb_40 [sub "Natural Beauty" (split-text effect-up text_primary-color lh-16), h2.title.text-capitalize.split-text.
  effect-blur-fade "You Deserve to Feel Beautiful. Wellness Begins Here.", p.text-body-2.mt_4.split-text.split-lines-transform mô tả]; a.tf-btn.btn-switch-text.
  wow.fadeInUp data-wow-delay="0.4s" "Book An Appointment" (href "#" tạm).
- thumbs: img.img-1.tf-animateCLP-left 440x567 spa-book-appointment-1.jpg + img.img-2.tf-animateCLP-right 250x322 spa-book-appointment-2.jpg +
  span.shape-linear-circle.position-absolute.wow.fadeIn data-wow-delay="0.6s".
### `section-packages tf-spacing-1`
`.tf-container.medium`: heading-section.d-grid.gap_12.text-center.mb_40 [sub "Our Packages" (split-text effect-up text_primary-color lh-16), h2.title.
split-text.effect-blur-fade "Spa Packages For You"]. `.wrap-packages` 5 `.package-item.wow.fadeInUp`: mỗi item: `.content.d-flex.align-items-center.gap_20`
(`.img-style > img 100x100` + div a.link.h4.title.mb_8 + p.text-body-default.text_secondary) + `.wrap-price > h6.price.text_white`. Dữ liệu:
  package-item-1.jpg | "Full Body Massage" | "Relax your muscles, improve circulation, and melt away tension." | "$65 / 60 min"
  package-item-2.jpg | "Deep Facial Cleansing" | "Cleanse, exfoliate, and hydrate for visibly brighter skin." | "$55 / Session"
  package-item-3.jpg | "Aroma Therapy Massage" | "Enjoy soothing essential oils that calm both body and mind." | "$70 / 60 Min"
  package-item-4.jpg | "Manicure & Pedicure Combo" | "Nourish your hands and feet with professional nail care." | "$65 / 60 Min"
  package-item-5.jpg | "Glow-Up Package" | "Includes facial, massage, and body scrub — perfect for total renewal." | "$120 / 2.5 Hours"
Ngoài .tf-container.medium: `.item.position-absolute.scroll-transform` data-direction="left" > img spa-item-3.png 483x267.
### `section-spa-experience tf-spacing-1`
`.tf-container.medium > .row.align-items-center`: col-lg-5 `.thumbs > img.tf-animateCLP-left` 520x670 spa-care-time-1.jpg + span.shape-linear-circle.
position-absolute.wow.fadeIn data-wow-delay="0.6s"; col-lg-7 `.content`: heading-section.d-grid.gap_12.mb_40 [sub "Self Care Time" (split-text effect-up
text_primary-color), h2.title.split-text.effect-blur-fade "The Spa Experience", p.text-body-2.desc.mt_4.split-text.split-lines-transform "Thoughtfully
designed for your comfort, every visit brings care, calm, and connection. What You'll Experience at Our Spa"]; `.tf-grid-layout.tf-col-2.mb_40.wow.fadeInUp`
data-wow-delay="0.4s" 4 `.box-icon`: `.icon > i.icon-MoonStars | icon-Sparkle | icon-Leaf.fw-6 | icon-Champagne` + h5 "Tranquil Atmosphere" | "Expert
Therapists" | "Premium Natural Products" | "Private Treatment Rooms"; a.tf-btn.btn-switch-text.wow.fadeInUp data-wow-delay="0.6s" "About Us" (href về
/demo-spasalon/about — tạm dùng # nếu chưa làm, sẽ sửa khi có route). Ngoài .row: `.item.position-absolute.lg-hide.scroll-transform` data-direction="right"
data-wow-delay="0.4s" > img spa-item-4.png 447x363.

## NHÓM 3 — GALLERY (2 MARQUEE DỌC) + PRICING (SWIPER) + TESTIMONIAL
### `section-gallery` (KHÔNG có tf-spacing)
`.tf-container.medium > .row.align-items-center`: col-lg-6 heading-section.d-grid.gap_12.mb_40 [sub "Our Gallery" (split-text effect-up text_primary-color),
h2.title.split-text.effect-blur-fade "Moments Of Calm", p.desc.text-body-2.mt_4.split-text.split-lines-transform mô tả]; a.tf-btn.btn-switch-text.wow.fadeInUp
data-wow-delay="0.4s" "All Gallery" (href "#"). col-lg-6 `.wrap-gallery.tf-grid-layout.sm-col-2.gap_30` gồm 2 cột marquee dọc:
  Cột 1: `.infiniteslide` data-clone="2" data-style="up": 6 `.gallery > img` (gallery-1..6.jpg, đa dạng kích thước đã có width/height trong HTML).
  Cột 2: `.infiniteslide.sm-hide` data-clone="2" data-style="down" (ẩn ≤575px): 6 ảnh GIỐNG HỆT cột 1. Tái dùng useInfiniteSlide hướng "up"/"down".
Ngoài .tf-container.medium (con trực tiếp của .section-gallery): `.item-1.position-absolute.scroll-transform` data-direction="up" > img spa-item-5.png
346x409; `.item-2.position-absolute.scroll-transform` data-direction="right" data-distance="30%" > img spa-item-6.png 126x265.
### `section-pricing-5 tf-spacing-14 sw-layout`
`.tf-container.medium`: heading-section.d-grid.gap_12.mb_48.text-center [sub "Our Pricing" (split-text effect-up text_primary-color), h2.title.split-text.
effect-blur-fade "Moments of Calm" (giống heading Gallery — lỗi demo, giữ nguyên), p.text-body-2.desc.mt_4.split-text.split-lines-transform mô tả y hệt Gallery].
`.swiper` data-preview=3 data-tablet=2 data-mobile=1 data-space-lg=32 data-space-md=20 data-space=15 (KHÔNG loop, KHÔNG autoplay; cấu hình carousel.js:
3/2/1 slide tại 992/768/<768). dots `.sw-dots.style-1.position-relative.z-5.sw-pagination-layout.text-center.mt_24` là con trực tiếp của .swiper sau
.swiper-wrapper (đã xác minh pattern). Buộc dots bằng ref. 3 slide:
  1 `.pricing-item.style-4`: h5.title.d-flex.gap_12.align-items-center.mb_16.text_primary (i.icon-aromatherapy + "Serenity Monthly"), p, h2.price.text_primary.
    mb_32 "$180 <span>/month</span>", nút `a.tf-btn.style-border.btn-switch-text.mx-auto.w-full.mb_32` "Join For A Month", ul.list 3 li.text-body-2.text_primary.
    font-4 (i.icon-Check), `.img-style > img` 329x132 spa-pricing-1.jpg.
  2 `.pricing-item.style-4.center`: i.icon-facial-treatments + "Radiance Half-Year", "$990 <span>/ 6 months</span>", nút (KHÔNG có class style-border).
  3 `.pricing-item.style-4`: i.icon-stars-shape-7 + "Luxe Annual Retreat", "$1,850 <span>/ year</span>", nút style-border "Join For A Year".
  (Tất cả href="#". Nội dung tính năng đúng niche spa — giữ nguyên.)
### `section-testimonial-9 tf-spacing-10`
`.tf-container.medium`: heading-section.d-flex.align-items-end.justify-content-between.flex-wrap.gap_16.mb_44: bên trái [sub gốc "Our Gallery"
(nhầm — áp dụng cách xử lý đã thống nhất: viết lại) -> SỬA thành "Client Reviews" (text-label text-uppercase split-text effect-up text_primary-color
mb_12), h2.title.split-text.effect-blur-fade "Kind Words From Our Clients"]; bên phải a.hover-underline-link.link.text-button.text_primary "Read All
Reviews" (href "#").
`.tf-grid-layout.md-col-2.gap_20.wow.fadeInLeft` 2 `.testimonial-item.style-8.hover-image-2`: `.img-style > img 280x373` + `.content > div [ul.ratings
5 sao + p.h6.fw-6.text_primary.font-main.text-capitalize lời nhận xét]` + `a.h6.fw-6.text_primary.link.font-3 tên`:
  testimonial-3.jpg | "The moment I stepped in, I felt calm. The massage was heavenly — I didn't want to leave!" | Lydia Gouse
  testimonial-4.jpg | "This spa is my monthly ritual now. The therapists are so kind, and every detail is perfect." | Madelyn Rhiel Madsen
Ngoài .tf-container.medium: `.item.position-absolute > img spa-item-7.png 113x362` (không scroll-transform, không wow, chỉ absolute trang trí).

## NHÓM 4 — BOOKING + INSIGHTS
### `section-booking tf-spacing-1`
`.tf-container.medium > .row.align-items-center`: col-lg-7.text-center `.content`: heading-section.d-grid.text-center.gap_12.mb_16 [sub "Spa Center"
(split-text effect-up text_primary-color lh-16), h2.title.split-text.effect-blur-fade "Book Your Visit"]; `.info.mb_40`: h5.text_primary.font-main.fw-6.mb_16.
wow.fadeInUp data-wow-delay="0.2s" "Want To Schedule A Treatment Or Ask Us Something?"; p.text-body-2.wow.fadeInUp data-wow-delay="0.4s" "Call us at
<span class=\"h5 text_primary font-main fw-6\">1-333-345-6868</span> or simply complete our quick online form we'll get back to you soon.";
a.tf-btn.btn-switch-text.mx-auto.wow.fadeInUp data-wow-delay="0.6s" "Schedule Your Appointment" data-text cùng tên (href -> /demo-spasalon/booking
khi có route, tạm dùng #). col-lg-5 `.thumbs > img 520x670 spa-care-time-1.jpg` (KHÔNG có class tf-animateCLP) + span.shape-linear-circle.position-absolute.
wow.fadeIn data-wow-delay="0.6s". Ngoài .row (con trực tiếp .tf-container.medium): `.item.position-absolute.lg-hide.scroll-transform` data-direction="left" >
img spa-item-8.png 334x304.
### `section-insights-4 sw-layout tf-spacing-1 pt-0`
`.tf-container.medium`: heading-section.d-grid.gap_8.text-center.mb_48 [sub "Latest New" (text-label text-uppercase split-text effect-up — lưu ý là "New"
không phải "News", giữ đúng như gốc), h2.title.split-text.effect-blur-fade: gốc "Pet Care Tips & Tricks" (sai hoàn toàn niche) -> SỬA thành "Spa & Wellness
Tips"]. `.tf-grid-layout.md-col-3.gap_30` gồm 2 `.blog-item.style-4.hover-image` + 1 `.banner.hover-image`:
  Bài 1: a.img-style.mb_26 -> /demo-spasalon/blogdetail/... (khi có, tạm dùng #); img 410x308 blog-item-22.jpg; tag "spa body"; h5 "5 Self-Care Rituals for
    Stressful Days"; meta: "Lindsey Dorwart", "July 5, 2025".
  Bài 2: img 410x308 blog-item-23.jpg; tag "Spa Salon"; h5 "Why Monthly Facials Keep Your Skin Radiant"; meta: "Rayna Philips", "July 5, 2025".
  Banner: a.img-style -> # (href="#" trong gốc, giữ nguyên); img 410x458 insights-banner.jpg; `.content > h4.mb_24 > a.link.text_white "Summer Glow Special"` +
    a.tf-btn.btn-switch-text "Book now"; `.sale > h6.text_white "FROM" + h2.price.text_white > span.h4.text-white "$" + "15"`.
  SỬA LINK `blogdetail.html` (có ở 3 chỗ — 2 bài viết): niche này sẽ có /demo-spasalon/blogdetail/[slug] sau này; tạm thời href="#" tới khi có route, ghi
  comment `// TODO: /demo-spasalon/blogdetail/{slug}`.

## VERIFY (Playwright; mở HTML gốc qua server tĩnh và Next ở cùng độ rộng; cổng KHÔNG dùng 5060/5061)
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font (Bricolage Grotesque cho h2), link không gạch chân, nền sáng đúng.
- Hero: 3 slide fade autoplay, tiêu đề khác nhau; effect-content-slide (text xuất hiện đúng delay 1/2/3); ảnh effect-img-zoom scale khi active; nav ẩn >=992px, dots
  ẩn >=992px; marquee marquee sau hero chạy sang trái.
- Gallery: 2 cột marquee dọc (up/down), cột 2 ẩn ≤575px; scroll-transform 2 ảnh trang trí đúng hướng.
- Pricing: 3/2/1 slide theo breakpoint, dots bấm được, KHÔNG có `.swiper-button-*` mặc định.
- Testimonial: heading sub đã đổi thành "Client Reviews".
- Insights: h2 đã đổi thành "Spa & Wellness Tips".
- Tất cả scroll-transform di chuyển đúng hướng khi cuộn; shape-linear-circle (gradient tròn) hiện đúng màu.
- Rò rỉ CSS: màu/font h2 + màu body ở / và /demo-spasalon khớp HTML gốc tương ứng, cả khi điều hướng client-side.
- Menu: quét link từ /demo-spasalon (desktop hover dropdown + mobile ≤1199px): MỌI link Pages/Services/Project/Blog/Contact -> 200 và vào đúng trang corporate;
  liệt kê riêng 404 chỉ do niche chưa làm; không còn ".html".
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả bọc CSS; nội dung đã sửa (tiêu đề service "Rstore"->"Restore", sub testimonial "Our Gallery"->"Client Reviews", h2
insights "Pet Care"->"Spa & Wellness Tips"); hook đã tái dùng/tạo mới; kết quả đo từng điểm; việc chưa xong (16 trang con sẽ làm sau).