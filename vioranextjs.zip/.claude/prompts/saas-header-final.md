Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "saas" (route "/demo-saas"). Đã XÁC MINH
bằng đọc trực tiếp demo-saas/index.html.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (KHÔNG splitting.min.js).
Có #smooth-wrapper/#smooth-content (không class phụ). 2 header "style-8
header-sticky" / "style-8" — ĐÃ DIFF: giống hệt nhau (chỉ khác class +
line-wrap).

Cơ chế scroll: header-sticky → `useHeaderSticky` (đã có sẵn). Breakpoint:
`mobile-button d-lg-none` → mốc "lg" (991/992).

Đã fix 1 file SCSS: `src/styles/demo-saas.scss` có
`url(../../assets/images/shape/shape-saas.png)` → sửa thành
`url(/assets/images/shape/shape-saas.png)` (path tuyệt đối, tránh lỗi
build Turbopack module-not-found — xem cách đã làm ở app.scss trước đó).

## 2. PATTERN chung: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

Xác nhận lại đúng (xem memory index-only-niches-reuse-corporate-pages) —
route thật corporate, KHÔNG tiền tố `/demo-saas`. Bỏ "404 Error".

## 3. Chi tiết markup riêng

- `tf-container medium`, `header-inner position-relative`.
- Mega-menu submenu CÓ class "menu-rounded".
- header-right CHỈ có 1 CTA (KHÔNG có Login link, khác aitech/healthcoach):
  `<a href="#" class="tf-btn btn-switch-text md-hide"><span><span
  class="btn-double-text" data-text="Get Started">Get Started</span></span></a>`
  — hiệu ứng chữ cuộn lên khi hover là THUẦN CSS (`.btn-switch-text
  .btn-double-text::before { content: attr(data-text) }` + `:hover { top:
  -100% }`, đã có sẵn trong _button.scss đã copy) — CHỈ CẦN đúng markup
  (span lồng nhau + data-text trùng với text hiển thị), KHÔNG cần JS. CTA
  ẩn ở ≤767px (class "md-hide", KHÁC sm-hide của các niche trước).
- Offcanvas mobile-nav-wrap CÓ class "style-dark".
- Logo: `logo-saas.svg`.

## 4. Menu (giữ nguyên, không phát hiện bug link nào)

12 demo mega-menu thứ tự y hệt các niche trước, "Home SaaS" trỏ
"/demo-saas" (active). Mobile đủ 20 niche, 5 nhóm accordion
Demos/Pages/Services/Project/Blog, Contact link thẳng cuối.

Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥992px main-menu hiện/mobile-button ẩn; ≤991px ngược lại
- Hover 4 submenu mở đúng (CSS hover)
- CTA "Get Started" hiện ở >767px, ẨN ở ≤767px (md-hide, khác sm-hide) —
  đo đúng mốc 767/768
- Hover CTA thấy data-text hoạt động (không bắt buộc phải đo pixel, chỉ
  cần xác nhận markup đúng — có thể inspect computed style `top` của
  `.btn-double-text` khi hover)
- Cơ chế header-sticky: kiểm tra scrollHeight trước khi chọn giá trị test
  cuộn
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
