Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng
con số, không áng chừng, không tự đơn giản hoá. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Convert trang chủ ../viora/viora/demo-aicontentwriter/index.html (route "/demo-aicontentwriter", route group
(demo-aicontentwriter)). Header/Footer ĐÃ CÓ SẴN (header style-10 header-fixed ngưỡng 300px, mốc menu mobile lg
991/992; footer-style-6). Niche này CHỈ có index.html, không có trang con. Làm: BƯỚC 0 (kiểm tra + gắn menu + bọc CSS),
hero, rồi 7 block main-content (ĐÃ ĐỌC ĐỦ), THEO 4 NHÓM; verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau.
Khác aitech: niche này CÓ ScrollSmoother (`#wrapper` > `#smooth-wrapper` > `#smooth-content`), nền SÁNG (--Primary #4E49E7).

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Layout (demo-aicontentwriter)/layout.tsx: wrapper `data-niche="aicontentwriter"`; cấu trúc #wrapper > #smooth-wrapper >
   #smooth-content như HTML gốc (header cố định NGOÀI smooth, header thường + nội dung + footer TRONG smooth-content, theo
   đúng cách các niche dùng ScrollSmoother đã làm); HeaderSection gọi useScrollSmoother() + useWow().
2. BỌC TOÀN BỘ CSS RIÊNG NICHE: demo-aicontentwriter/css/AI-content-writer.css (63 dòng) ngoài `:root` còn có selector TOÀN CỤC:
   `body {color}`, `#smooth-wrapper {background-color}`, `h1,.h1…h6,.h6 {color; font-family; font-weight}`, `.font-main`,
   `.main-menu …`, `.navigation …`, `.tf-btn`, `.tf-btn.btn-bg-white`, `.tab-slide.style-2 .tab-link.active`. Next gộp CSS mọi
   niche vào 1 bundle nên chúng RÒ sang niche khác (đã đo: 18 file CSS niche, tất cả trừ corporate, có kiểu rò này). Làm với
   src/styles/demo-aicontentwriter.scss: BỌC TOÀN BỘ trong `[data-niche="aicontentwriter"] { ... }` (SCSS nesting): `:root {…}`
   -> khai báo biến trên chính `[data-niche=…]` (dùng `&`); `body {color}` -> `color` trên `[data-niche=…]`; `#smooth-wrapper
   {…}` -> `#smooth-wrapper {…}` lồng bên trong; mọi rule còn lại lồng nguyên văn (giữ cả `!important`). KHÔNG đổi giá trị/thứ
   tự. Nếu độ ưu tiên selector đổi làm lệch so với HTML gốc ở chỗ nào, sửa riêng chỗ đó cho khớp bản gốc.
   Nếu prompt aitech-home-final.md đã chạy thì việc đo rò rỉ chéo giữa các niche đã làm ở đó; ở đây chỉ cần đo lại sau khi
   bọc: màu/font h2 và màu body của `/`, `/demo-agency`, `/demo-aitech` và `/demo-aicontentwriter` khớp HTML gốc tương ứng,
   cả khi điều hướng client-side giữa chúng (cổng test KHÔNG dùng 5060/5061).
3. `ls src/hooks src/components/common` và tái dùng: useSplitTextReveal, useWow, useScrollSmoother, useInfiniteSlide, hook tab
   giá Monthly/Yearly (+ tabSlide), hook accordion 1-mục-mở + collapse transition, useSwiperControls, và nếu aitech đã làm:
   useRevealElements (data-ns-animate), TypingPlaceholderInput. Kiểm tra/bổ sung:
   a. useSplitTextReveal có đủ chế độ dùng ở trang này: `effect-left` (from opacity 0, x -50), `effect-right` (from opacity 0,
      x 50), `effect-up` (from opacity 0, y 20), `split-lines-transform` (tách "lines", from opacity 0, yPercent 100, autoAlpha 0,
      stagger 0.2), `split-lines-rotation-x` (tách "lines", from opacity 0, rotationX -120, transformOrigin "top center -50",
      stagger 0.2). Mặc định: SplitText "words, chars", duration 0.9, stagger 0.02, ease power3.out; target là `p`/`a` con đầu tiên
      nếu có, không thì chính phần tử.
   b. useRevealElements cho `data-ns-animate` (trang này chỉ có 1 chỗ: ảnh hero). Nếu CHƯA có thì tạo theo gsapAnimate.js
      initRevealElements: duration = parseFloat(data-duration) (mặc định 0.6); delay = parseFloat(data-delay) (mặc định 0);
      offset 60; start "top 90%"; end "top 50%"; direction mặc định "down"; đặt trước style opacity 1 + filter blur(0); gsap.from(elem,
      {opacity 0, filter "blur(16px)", duration, delay, ease "power2.out", y: +offset (down) | y: -offset (up) | x: -offset (left) |
      x: +offset (right), scrollTrigger {trigger elem, start, end, scrub:false}}). Springer KHÔNG cần (chỉ dùng khi data-spring).
   c. TypingPlaceholderInput (placeholder gõ chữ, main.js animateInput) — nếu CHƯA có thì tạo, PORT NGUYÊN VĂN: placeholders =
      data-placeholders tách "|", interval = data-interval || 100ms; typeIn(): isTyping=true, text = placeholders[i], class span =
      "placeholder-text typing-animation typing-in", sau 2000ms isTyping=false; typeOut(): nếu isTyping thì thoát; class
      "placeholder-text typing-animation typing-out"; sau 800ms i=(i+1)%n rồi typeIn(); khởi động typeIn() một lần rồi
      setInterval(()=>{ if(!isTyping) typeOut(); }, interval). GIỮ quirk gốc (typeOut có thể bị gọi lặp trong 800ms); thêm dọn
      dẹp khi unmount. `.placeholder-wrapper` phải là phần tử KỀ SAU input trong fieldset; input có placeholder=" ".
   d. useInfiniteSlide hỗ trợ hướng "up" VÀ "down" (đọc assets/js/infinityslide.js): wrap `.infiniteslide_wrap` overflow hidden; phần
      tử là flex column nowrap, children flex:none block; nhân bản `clone` (=2) lần; num = chiều cao 1 bộ item gốc; chiều cao wrap
      = num; keyframes `from translate3d(0,0,0) to translate3d(0,-{num}px,0)`; thời lượng = num/speed GIÂY với speed = data-speed
      || 50 (px/s); `linear infinite`; hướng "down" thêm " reverse"; pause khi mouseenter, chạy lại khi mouseleave; tính lại khi
      resize (cột bị ẩn bằng md-hide/lg-hide có chiều cao 0 lúc đầu -> phải tính lại khi hiện ra).
   e. HOOK MỚI useStackElements (hiệu ứng `.stack-element`, gsapAnimate.js stackElement) — xem Nhóm 1.
4. next/image bắt buộc width/height: ảnh trong HTML gốc KHÔNG khai báo kích thước (dùng kích thước thật): images/item-8.svg 93x82
   | images/item-1..7.svg 48x48 | ../assets/images/shape/Lightning-2.png 20x21. Ảnh khác đã có width/height trong HTML (hero.jpg
   1410x705, feature-1..3.jpg 555x555, process-1.jpg 596x596, avatar 48x48...).
5. GẮN MENU HEADER NHƯ HTML GỐC (làm thật, KHÔNG chỉ kiểm tra; làm ngay ở bước này). Đã đọc HTML: niche này KHÔNG có trang con;
   trong header và offcanvas mobile `#menu-mobile`, MỌI mục ngoài "Demos" (Pages, Services, Project, Blog, Contact) đều trỏ sang
   trang CORPORATE (`../demo-corporate/*.html`; tập link đã so với restaurant: GIỐNG HỆT). Corporate chạy ở route GỐC:
   | Nhãn menu                  | href trong HTML gốc                       | Route Next                      |
   | Home Corporate             | ../demo-corporate/index.html              | /                               |
   | Pages > About Us           | ../demo-corporate/about-us.html           | /about-us                       |
   | Pages > Our Team           | ../demo-corporate/our-team.html           | /our-team                       |
   | Pages > Team Detail        | ../demo-corporate/team-detail.html        | /team-detail/{slug}             |
   | Pages > Carrer             | ../demo-corporate/carrer.html             | /carrer                         |
   | Pages > Carrer Detail      | ../demo-corporate/carrer-detail.html      | /carrer-detail/{slug}           |
   | Pages > FAQs               | ../demo-corporate/FAQs.html (F hoa)       | /faqs                           |
   | Services > Services        | ../demo-corporate/services.html           | /services                       |
   | Services > Services Detail | ../demo-corporate/service-detail.html     | /service-detail/{slug}          |
   | Project > Porfolio         | ../demo-corporate/portfolio.html          | /portfolio                      |
   | Project > Portfolio Detail | ../demo-corporate/portfolio-detail.html   | /portfolio-detail/{slug}        |
   | Blog > Blog Full Width     | ../demo-corporate/blog-full-width.html    | /blog-full-width                |
   | Blog > Blog With Sidebar   | ../demo-corporate/blog-with-sidebar.html  | /blog-with-sidebar              |
   | Blog > Blog Detail         | ../demo-corporate/blog-detail.html        | /blog-detail/{slug}             |
   | Contact                    | ../demo-corporate/contact.html            | /contact                        |
   - {slug}: LẤY từ menu của corporate (src/data/demo-corporate/menu.ts đang dùng slug đầu tiên cho các mục "...Detail"), KHÔNG
     gõ tay/đoán. Route "...Detail" không slug sẽ 404.
   - "404 Error": làm ĐỒNG NHẤT với menu corporate (đã bỏ); nếu niche đang có sẵn thì giữ nguyên trạng thái hiện tại.
   - Nhãn "Porfolio" là lỗi gõ -> "Portfolio" (nếu corporate vẫn ghi "Porfolio" thì sửa luôn ở corporate cho đồng nhất). Mục
     "Contact" cấp 1 có 2 thẻ <span> cùng chữ (hiệu ứng hover) là đúng markup gốc.
   - "Home AI Content Writer" trỏ chính nó (/demo-aicontentwriter); "Home <niche khác>" trỏ /demo-<niche>: niche CHƯA làm sẽ 404
     cho tới khi làm tới — dự kiến, chỉ liệt kê, KHÔNG sửa.
   Cách làm: (a) đọc src/data/demo-corporate/menu.ts, src/data/demo-aicontentwriter/menu.ts, components/layout/
   demo-aicontentwriter/ (Header, MobileNav, HeaderSection); (b) in BẢNG TRƯỚC (nhãn | href hiện tại | route đích | khác không) —
   mục trỏ "#", route không tồn tại như /demo-aicontentwriter/about, Detail không slug, hay còn ".html" đều phải sửa; (c) sửa dữ
   liệu menu theo bảng, ưu tiên MỘT NGUỒN (import mảng của corporate nếu có export, không thì copy href kèm comment
   `// mirrors demo-corporate/menu.ts`); KHÔNG đổi cấu trúc menu corporate; giữ mega-menu Demos, class, hover, accordion mobile;
   (d) cả BA nơi render menu (header cố định/thường, offcanvas mobile) đọc cùng dữ liệu; dùng <Link>. KHÔNG tạo route
   /demo-aicontentwriter/about... KHÔNG sửa FOOTER (đã làm ở đợt Footer trước).
6. Tên file dữ liệu: src/data/demo-aicontentwriter/features.ts, processSteps.ts, testimonials.ts, pricing.ts, faqs.ts.

## NHÓM 1 — HERO + FEATURES (STACK)
### Hero `hero-banner-7` (nằm TRONG smooth-content, ngay trước main-content)
- `.tf-container > .row`: col-xl-6 `h1.split-text.effect-left` "Write Smarter With AI"; col-xl-6 `.content`: p.text-body-2.mb_32.
  split-text.split-lines-rotation-x "Create high-quality blog posts, product descriptions, and marketing copy in seconds — powered
  by advanced AI trained for content that converts."; `form.form-newsletter.style-6.mb_30.wow.fadeInUp` data-wow-delay="0.2s"
  action="#": `div.position-relative.input-animate-container` > `fieldset.position-relative` > input[type=text] (type text, không
  phải email).input-field.animated-input placeholder=" " data-placeholders="Enter your email" + `div.placeholder-wrapper` >
  span.placeholder-text.typing-animation + span.cursor; rồi button[name=submit][type=submit].tf-btn.btn-hover-animate >
  span.text-body-1.fw-6 "Try For Free". onSubmit preventDefault. Tiếp: `div.trust.d-flex.align-items-center.gap_12`
  data-wow-delay="0.3s" (div này KHÔNG có class wow): `.group` 3 avatar 48x48 (group-avatar-1-1/2/3.jpg, wow fadeInLeft, delay .1/.2/.3s)
  + p.text-caption-1.text-body-default.wow.fadeInUp data-wow-delay="0.2s" "Trusted by 50k+ users".
- Sau `.row` (trong tf-container): `div.thumbs` data-ns-animate data-duration="1" > img hero.jpg 1410x705 loading="eager".
### `section-feature-2 tf-spacing-10`
- heading-section d-grid gap_16 text-center mb_48: sub (text-label text_primary-color split-text effect-up text-uppercase) "Our
  Features"; h2.title.split-text.effect-right "Key Features"; p.text-body-2.split-text.split-lines-transform "Everything you need to
  write better, faster, and smarter with AI."
- `.stack-element.mb_48 > .wrap-feature.stack-content-wrap` gồm 3 `.element` > `.feature-item.style-1` (item 2 có thêm class `ctl`:
  content TRƯỚC, ảnh SAU; item 1 và 3: ảnh trước, content sau). Ảnh `.img-style` > img 555x555 loading lazy feature-1/2/3.jpg. Content:
  a.h2.link.mb_12 (href "#") tiêu đề + p.text-body-2.mb_32 + `ul.list.d-grid.gap_16` 3 `li.text-body-default.d-flex.align-items-center.
  gap_16` (data-wow-delay "0.4s"/"0.6s"/"0.8s", chỉ là thuộc tính, li không có class wow) + i.icon-Check:
   1 "Intelligent Content Generation" / "Produce high-quality content in seconds using advanced AI trained on top-performing copy." /
     "Supports blog posts, ads, emails, product descriptions, and more", "Suggests headlines, outlines, and paragraph structures",
     "Continuously learns and improves from your writing patterns"
   2 "SEO & Readability Optimization" / "Ensure every piece of content is not only engaging but also optimized for search engines." /
     "Keyword integration and content scoring built-in", "Readability checks for better user experience", "Helps increase organic
     traffic and time on page"
   3 "Custom Tone & Brand Voice" / "Stay on-brand across all content with fully adjustable tone and style settings." / "Choose from
     friendly, professional, witty, or custom tones", "Maintain voice consistency across teams and projects", "Great for agencies and
     multi-brand teams"
- Nút cuối: a.tf-btn.mx-auto.btn-hover-animate.wow.fadeInUp (href "#") > span "Start Writing for Free" + <span></span>.
- HIỆU ỨNG STACK (gsapAnimate.js stackElement — làm đúng): dùng `gsap.matchMedia()` điều kiện "(min-width: 767px)". Với mỗi
  `.stack-element`: totalHeight = outerHeight của `.stack-content-wrap`; lần lượt từng `.element`: tabHeight = element.offsetHeight;
  totalHeight -= tabHeight; tạo `ScrollTrigger.create({ trigger: element, scrub: 1, start: "top 100", end: "+=" + totalHeight, pin: true,
  pinSpacing: false })`. Khi cửa sổ resize: kill toàn bộ ScrollTrigger vừa tạo rồi tính/tạo lại. Dưới 767px không pin (matchMedia tự
  revert). Hook useStackElements: tạo trong useEffect (client) bằng gsap.matchMedia + context.revert() khi unmount; tạo SAU khi
  ScrollSmoother đã khởi tạo; gọi ScrollTrigger.refresh() sau khi ảnh feature tải xong/font tải xong vì chiều cao phụ thuộc layout.

## NHÓM 2 — PROCESS + INTEGRATIONS
### `section-process-3` (không có tf-spacing)
- `.tf-container > heading-section style-default text-center mb_48`: sub gốc "News & Insights" (heading của khối blog đặt nhầm cho
  phần quy trình; áp dụng cách xử lý đã dùng ở aitech) -> SỬA thành "Our Process" (class text-label text-uppercase split-text
  effect-up); h2.title.split-text.effect-right "How It Works"; p.text-body-2.text_secondary "Your content, created in 4 simple steps with
  the power of AI." (KHÔNG có class split-text).
- `div.wrap-process.flat-animate-tab.wow.fadeInLeft`: `.tab-slide.style-2.d-flex.justify-content-center.mb_40 > ul.menu-tab.d-flex.
  align-items-center.overflow-x-auto[role=tablist]` (KHÔNG có `.item-slide-effect`) 4 `li.nav-tab-item > a.tab-link` > span.h6 + span.
  text_muted.text-label.text-uppercase.fw-6.step.letter-spacing-1: "Choose Content Type"/Step1; "Enter Your Input"/Step2 (MẶC ĐỊNH ACTIVE —
  tab thứ 2); "Generate And Edit"/Step3; "Export And Publish"/Step4. Thay Bootstrap data-bs-toggle="tab" bằng useState, giữ class active/
  show để CSS gốc (`.tab-slide.style-2 .tab-link.active`) hoạt động.
- `.tab-content` 4 `.tab-pane[role=tabpanel]` (id discovery, strategy [active show], execution, optimization), mỗi pane `.box-process` >
  `.content` [heading-section style-default mb_32: sub (text_primary-color lh-16 text-label text-uppercase) "Step 1/2/3/4", h3.title.font-2
  "Choose Content Type" / "Enter Your Input" / "Generate and Edit" / "Export and Publish", p.text-body-2.text_secondary — CẢ 4 pane cùng
  1 đoạn: "Add your topic, keywords, tone, and other preferences. You can keep it brief or provide detailed instructions. The AI understands
  context and adapts to your goals instantly." (lỗi demo, giữ nguyên)] + a.tf-btn.btn-hover-animate "Try For Free" (+ <span></span>; pane 4
  ghi "Try for free" — giữ nguyên) và `.img-process` > img process-1.jpg 596x596 loading eager (CẢ 4 pane cùng 1 ảnh — lỗi demo, giữ
  nguyên; đổi tab chỉ đổi pane hiện).
### `section-integrations tf-spacing-10`
- `.tf-container > .row.align-items-center`: col-lg-5 `.wrap-group-logo > .group-logo` gồm `.logo-main` (img item-8.svg 93x82) và 7
  `.item.item-1`…`.item-7` (img item-1..7.svg 48x48). ĐÃ XÁC MINH: chuyển động quanh logo là CSS thuần (_sections.scss `.group-logo`:
  `animation: rotation 100s infinite linear` và `rotation2 100s infinite linear`) -> chỉ cần đúng class/DOM; xác nhận keyframes
  `rotation`/`rotation2` có trong bundle. col-lg-7 `.content`: heading-section style-default mb_32 [sub "Integrations" (text-label text-uppercase
  split-text effect-up text_primary-color), h2.title.split-text.effect-right "Seamlessly Connect With Your Favorite Tools", p.text-body-2.wow.
  fadeInUp data-wow-delay="0.4s" "Integrate our AI writer with the platforms you already use — from CMS and email to design and automation
  tools. No disruption, just smarter content where you need it."] + a.tf-btn.btn-hover-animate.wow.fadeInUp data-wow-delay="0.6s" "Explore
  Integrations" (+ <span></span>), href "#".

## NHÓM 3 — TESTIMONIAL (3 MARQUEE DỌC) + PRICING
### `section-testimonial-6` (không có tf-spacing)
- heading-section style-default text-center mb_48: sub gốc "News & Insights" (nhầm heading blog) -> SỬA thành "Testimonials" (text-label
  text_primary-color split-text effect-up text-uppercase); h2.title.split-text.effect-right "What People Are Saying"; p.text-body-2.split-text.
  split-lines-transform "Join thousands of users creating faster, better content with AI."
- `.wrap-testimonials.tf-grid-layout.lg-col-3.md-col-2.gap_20` gồm 3 `.infiniteslide` (data-clone="2"): cột 1 `data-style="up"`; cột 2 class
  thêm `md-hide`, `data-style="down"`; cột 3 class thêm `lg-hide`, `data-style="up"`. CẢ 3 CỘT chứa CÙNG 1 danh sách 9 `.testimonial-item.
  style-5` (lỗi demo — dùng 1 mảng, render 3 lần): `p.text-body-2.mb_16` lời nhận xét + `.author.d-flex.gap_12` > `.avatar` > img 48x48 +
  div > a.text-button.d-block.link.text_primary (href "#") tên + span.text-caption-1.text_o chức danh. Thứ tự: 
   1 Rebecca M — Marketing Consultant — avatar-10.jpg   2 Emily N — Blogger — avatar-11.jpg   3 Alex Johnson — Content Marketer — avatar-12.jpg
   4 Thomas V — Copywriter — avatar-13.jpg   5 Alex Johnson — Content Marketer — avatar-14.jpg   6 Carla S — Creative Director — avatar-15.jpg
   7 Jamie L — Content Marketer — avatar-16.jpg   8 Alex Johnson — Content Marketer — avatar-17.jpg   9 Daniel K — Shopify Store Manager — avatar-10.jpg
  (Alex Johnson xuất hiện 3 lần với avatar khác nhau, avatar-10 dùng 2 lần — lỗi demo, giữ nguyên.) LỜI NHẬN XÉT: sao chép NGUYÊN VĂN từ
  HTML gốc, từng câu (đừng gõ lại): bắt đầu 1 "As a non-native English speaker, this tool has been a lifesaver…", 2 "I used to spend hours
  crafting blog content from scratch…", 3 "I was surprised at how natural and human the content feels…", 4 "What impressed me most is the tone
  flexibility…", 5 "Writing used to drain my energy…", 6 "Our agency produces tons of content for clients across industries…", 7 "This AI
  writer changed how I work…", 8 "I was skeptical about using AI for writing at first…", 9 "We needed unique descriptions for hundreds of
  products…". Nội dung đúng niche AI Content Writer, không sửa.
- Marquee: speed mặc định 50 px/s (main.js: speed = data-speed || 50, clone = data-clone), cột 2 hướng "down" chạy ngược; cột bị ẩn theo
  breakpoint (md-hide ≤767px ẩn cột 2; lg-hide ≤991px ẩn cột 3) phải tính lại khi hiện ra khi resize.
### `section-pricing-3 flat-animate-tab tf-spacing-10 pricing-container sw-layout`
- NGUỒN GỐC của nội dung pricing (đúng niche, giữ nguyên; chính là đoạn từng lọt sang corporate). heading-section style-default text-center
  mb_48: sub "Our Pricing"; h2.title.split-text.effect-right "Flexible Plans For Every Writer"; p.text-body-2.text_secondary.split-text.
  split-lines-transform: gốc "Choose the plan that fits your needs upgrade anytime as you grow." (thiếu dấu) -> SỬA thành "Choose the plan
  that fits your needs — upgrade anytime as you grow."
- `.tab-slide.style-1.d-flex.justify-content-center.mb_48 > ul.menu-tab.d-inline-flex…` có `<li class="item-slide-effect">` + 2 tab
  "Monthly" (active, data-pricing="monthly") và "Yearly" (data-pricing="year"), href #standard-plan/#premium-plan (không có pane).
- `.tab-content.wow.fadeInUp > .swiper` data-preview=3 data-tablet=2 data-mobile=1 data-space-lg=30 data-space-md=20 data-space=15 (cấu
  hình đã suy từ carousel.js: speed 1000, observer, không loop/autoplay; <768px: 1 slide, space 15; 768–991px: 2 slide, space 20; >=992px: 3
  slide, space 30) và dots `div.sw-dots.style-1.position-relative.z-5.sw-pagination-layout.text-center.mt_24` nằm NGOÀI `.swiper` (cùng
  cấp, ngay sau nó — xác nhận lại vị trí trong HTML gốc); buộc dots bằng ref (useSwiperControls), KHÔNG để Swiper tự vẽ nút/dots.
- 3 `.swiper-slide > .pricing-item.style-1`: 
  Starter: h5.title.d-flex.gap_12.align-items-center.mb_16 > i.icon-stars-shape-5 + "Starter"; p.text-body-default.text_secondary "Perfect for
  individuals trying AI writing for the first time."; giá `h2.price.text_primary.mb_32.price-value` KHÔNG có data-monthly/data-yearly, chứa
  span.wrap-price > span > (span.price-month "free" + span.price-year "free") + span.text-body-default.text-muted.fw-4.price-period "/ month";
  a.tf-btn.style-border.btn-hover-animate-border.w-full.mb_32 "Start Free" (+ <span></span>); ul.list 4 li (text-body-default text_primary + i.icon-Check):
  "Up to 5,000 words/month", "10+ content templates", "Basic tone options", "Limited export formats".
  Pro (`pricing-item style-1 z-5`): heading `d-flex align-items-center mb_16 justify-content-between gap_12` gồm h5.title (i.icon-stars-shape-6 +
  "Pro") và `.tag.d-inline-flex.align-items-center.gap_4.text-button-small.text_white` (img ../assets/images/shape/Lightning-2.png 20x21 +
  "Popular"); p "For content creators, marketers, and small teams needing more power."; data-monthly=29 data-yearly=69; nút "Upgrade to Pro";
  "Up to 100,000 words/month", "25+ content templates", "Advanced tone & style settings", "SEO suggestions included".
  Business: p "For agencies and businesses creating content at scale."; data-monthly=69 data-yearly=99; nút "Start Business Plan"; "Unlimited word
  generation", "Team collaboration features", "Brand voice custom training", "API access". (Với Pro/Business và icon/class nút còn lại: sao chép
  NGUYÊN markup từ HTML gốc.)
- CƠ CHẾ ĐỔI GIÁ (main.js initSwitchPriceValue, đã đọc — làm đúng): trong `.pricing-container`, các phần tử có `data-pricing` là tab; với mỗi
  `.price-value`: monthly = data-monthly, yearly = data-yearly; điền text cho .price-month (monthly) và .price-year (yearly) CHỈ KHI có dữ
  liệu — gói Starter không có data nên GIỮ NGUYÊN chữ "free" (jQuery .text(undefined) không đổi gì); tab "monthly" -> .price-month có class active,
  .price-year bỏ active, `.price-period` = "/ month"; tab khác ("year") -> ngược lại và "/ year" (áp dụng cả với Starter: "free / year"); bấm tab
  còn đặt class active cho đúng thẻ a[data-pricing]; mặc định chạy "monthly" (Pro 29, Business 69). tabSlide: `.item-slide-effect` width = outerWidth
  của li.active, translateX(left của li) khi click, resize và lúc khởi tạo (transition 0.5s trong SCSS). Tái dùng hook tab giá đã có.

## NHÓM 4 — CTA + FAQS
### `section-cta-2` (không có tf-spacing)
`.tf-container > .content-inner > .row.align-items-center`: col-lg-6 `.heading`: `.trust.d-flex.align-items-center.gap_12.mb_16.wow.fadeInLeft`
(`.group` 3 avatar 48x48 group-avatar-1-1/2/3.jpg wow fadeInLeft delay .1/.2/.3s + p.text-caption-1.text-body-default.text_white.wow.fadeInUp
data-wow-delay="0.2s" "Trusted by 50k+ users") + h2.title.text_white "Create Stunning Content in Seconds"; col-lg-6 `.content`: p.text-body-2.mb_32.
text_white.split-text.split-lines-transform "Say goodbye to writer’s block. Generate blog posts, product descriptions, social media captions, and
more" (đúng niche — đây là NGUỒN của câu từng lọt sang aitech; giữ nguyên) + a.tf-btn.btn-hover-animate.btn-bg-white.w-full.wow.fadeInUp
"Get Started" (+ <span></span>), href "#".
### `section-faqs-2 tf-spacing-10`
- `.tf-container > .box`: `.heading-section` [sub "FAQs" (text-label text-uppercase split-text effect-up text_primary-color fw-5 lh-20 mb_20), h2.
  title.mb_12.split-text.effect-left "Frequently Asked Questions", p.desc.text-body-2.text_secondary.split-text.split-lines-transform "Everything
  you need to know before getting started"] + `ul.accordion-wrap.d-grid.gap_16#accordion-faq` gồm 5 `li.accordion-item.style-4.wow.fadeInRight`
  (data-wow-delay như gốc): a.accordion-title (data-bs-toggle="collapse") > .heading > h5.title.text-capitalize (chữ "Q1: …" nằm TRONG tiêu
  đề) + span.icon; panel `.collapse` (câu 1 `.collapse.show`, data-bs-parent="#accordion-faq") > .accordion-faqs-content > p.text-body-default.
  Câu hỏi: "Q1: Is the content truly original?" / "Q2: Can I customize the tone and style of the writing?" / "Q3: How many languages does it
  support?" / "Q4: Do I need writing experience to use the tool?" / "Q5: Can I upgrade or cancel anytime?". CẢ 5 câu trả lời gốc GIỐNG HỆT
  nhau ("Simply fill out our online form or contact us directly — we’ll send you a personalized quote within 24 hours.") — lỗi demo, GIỮ NGUYÊN
  (cùng quyết định đã áp dụng cho FAQ của insurance/aitech).
- Hành vi: Bootstrap collapse với data-bs-parent => CHỈ 1 MỤC MỞ; câu 1 mở sẵn. KHÁC aitech: li ở đây KHÔNG có class action_click/active (JS
  accordionActive không áp dụng) — trạng thái icon do class/aria của `a.accordion-title` (collapsed / aria-expanded); đọc SCSS
  `.accordion-item.style-4` để biết trạng thái nào đổi icon rồi đặt đúng (đừng thêm class `active` nếu CSS không dùng). Dùng hook accordion
  1-mục-mở + collapse transition chuẩn của dự án.

## VERIFY (Playwright; mở HTML gốc qua server tĩnh và Next ở cùng độ rộng; nếu đã cài scripts/viora-check.mjs và viora-links.mjs thì dùng;
## KHÔNG dùng Claude in Chrome)
- Test ở 1919, 1440, 1199, 991, 767, 575: thứ tự block, chiều cao từng block, ảnh, font, link không gạch chân, nền sáng đúng
  (computed background của #smooth-wrapper và màu chữ body khớp bản gốc), không ảnh lỗi/404, có #smooth-wrapper.
- Rò rỉ CSS: sau khi bọc [data-niche], màu/font h2 + màu body ở các niche khác không đổi so với HTML gốc, cả khi điều hướng client-side.
- Hero: h1 effect-left, p rotation-x; placeholder gõ chữ lặp đúng nhịp (ghi các lần đổi class typing-in/typing-out ~8 giây ở bản gốc và Next,
  so thời điểm); ảnh hero chạy data-ns-animate (mờ + blur 16px + trượt 60px trước khi cuộn tới mốc "top 90%", rồi chạy 1 lần duration 1).
- Stack: ≥767px 3 thẻ feature được pin lần lượt khi cuộn (đo vị trí top = 100px tại thời điểm pin), thẻ sau chồng lên thẻ trước; resize
  qua lại mốc 767px không lỗi/giật, không còn ScrollTrigger dư khi chuyển trang.
- Process: mặc định tab 2 "Enter Your Input"; đổi tab đổi pane; nền tab active đúng.
- Integrations: logo xoay (CSS) giống bản gốc.
- 3 marquee dọc: cột 1 và 3 chạy lên, cột 2 chạy xuống; thời lượng = chiều cao 1 bộ 9 item / 50 giây; dừng khi hover; ≤991px cột 3 ẩn, ≤767px
  cột 2 ẩn và lưới còn 2→1 cột; khi mở rộng lại các cột tự chạy đúng.
- Pricing: nhãn Monthly/Yearly; mặc định Pro 29, Business 69 "/ month", Starter "free / month"; bấm Yearly -> Pro 69, Business 99 "/ year",
  Starter vẫn "free / year"; thanh trượt tab đúng vị trí 0.5s; Swiper 3/2/1 slide theo breakpoint, dots bấm được, số `.swiper-button-*` /
  `.swiper-pagination` mặc định = 0.
- FAQ: câu 1 mở sẵn, chỉ 1 mục mở, có transition, icon đổi đúng.
- Menu: quét link từ /demo-aicontentwriter (desktop hover dropdown + mobile ≤991px offcanvas, accordion, bấm từng mục): MỌI link Pages / Services
  / Project / Blog / Contact -> 200 và vào đúng trang corporate; liệt kê riêng 404 chỉ do niche chưa làm; không còn ".html".
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: BẢNG MENU TRƯỚC/SAU; kết quả bọc CSS niche (file đã bọc, kết quả đo rò rỉ); hook/component mới (useStackElements, useRevealElements,
TypingPlaceholderInput, hỗ trợ infiniteslide up/down nếu mới thêm); nội dung đã sửa (2 sub "News & Insights" -> "Our Process"/"Testimonials", dấu "—"
ở pricing); kết quả đo từng điểm trên; việc chưa xong.