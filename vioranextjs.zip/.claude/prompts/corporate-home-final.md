Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Convert trang chủ ../viora/viora/demo-corporate/index.html (route "/",
route group (demo-corporate)) — Header/Footer ĐÃ CÓ SẴN, chỉ làm phần
<main-content> (8 section, ĐÃ ĐỌC ĐỦ, liệt kê chính xác dưới đây). LÀM
THEO TỪNG NHÓM, verify từng nhóm trước khi sang nhóm tiếp, KHÔNG làm 1
lượt hết cả 8 section.

LƯU Ý: 1 section (Case Studies) có LỖI GÕ CLASS THẬT trong HTML gốc
("seciton-case-studies" thay vì "section-") — khi tìm kiếm section trong
các trang KHÁC của corporate hoặc niche khác sau này, LUÔN kiểm tra thêm
các biến thể lỗi chính tả tương tự, đừng chỉ tìm đúng "section-".

## NHÓM 1: Hero (Swiper) + About

- HeroSlider.tsx: Swiper effect "fade", autoplay=true, nav prev/next
  (icon-CaretLeft/Right) + dot pagination. 3 slide, TẤT CẢ 3 SLIDE CÓ
  NỘI DUNG GIỐNG HỆT NHAU (title/desc/button "View Services"→/services)
  — đây là lỗi demo content có thật trong HTML gốc, GIỮ NGUYÊN, không tự
  viết nội dung khác cho từng slide. Chỉ ảnh nền khác nhau
  (corporate-hero-1/2/3.jpg).

- AboutSection.tsx:
  - Video thumbnail có hiệu ứng parallax (data-speed="0.9" — cần cài
    thư viện parallax tương ứng đã có trong assets/js, đọc đúng file đó
    trước khi viết lại bằng React, KHÔNG đoán cơ chế)
  - Nút Play mở popup YouTube (link
    https://www.youtube.com/watch?v=MLpWrANjFbI, class "popup-youtube"
    — dùng magnific-popup gốc, thay bằng modal React đơn giản nhúng
    iframe YouTube khi bấm, không cần cài lại magnific-popup)
  - 4 counter (data-count: 10/250/50/98, data-duration đều 700ms).
    Cơ chế ĐÃ XÁC MINH từ main.js (hàm animateCounters): chỉ chạy 1 LẦN
    DUY NHẤT khi phần tử VÀO HOÀN TOÀN viewport (không phải chỉ chạm
    viewport), đếm từ 0 tới data-count trong đúng data-duration (ms).
    Viết hook useCountUp.ts đúng theo cơ chế này (IntersectionObserver
    threshold 1.0 để bắt "vào hoàn toàn", chạy 1 lần, dùng
    requestAnimationFrame thay vì jQuery animate).

## NHÓM 2: Services (grid 4 icon) + Case Studies (portfolio 4 item)

- ServicesGrid.tsx: 4 "tf-box-icon" (icon font, tiêu đề, mô tả) —
  Business Strategy/Web Development/Branding & Identity/Digital
  Marketing, đều link /services.

- CaseStudiesSection.tsx (LƯU Ý tên class gốc lỗi chính tả "seciton-"):
  4 portfolio item chia 2 hàng (2+2), mỗi item có hiệu ứng "custom
  cursor" (chữ "View" bám theo con trỏ chuột khi hover ảnh, class
  "cursor-wrapper"/"custom-cursor") — đọc đúng cơ chế này trong CSS/JS
  gốc trước khi viết lại (có thể là CSS-only dùng transform theo mouse
  position qua JS, hoặc thư viện riêng — XÁC MINH, không đoán). Data 4
  case study tách vào src/data/demo-corporate/caseStudies.ts.

## NHÓM 3: CTA + Testimonial (2 Swiper đồng bộ)

- CTASection.tsx: tĩnh, heading + mô tả + 2 nút (href="#", giữ nguyên
  không có link thật).

- TestimonialSection.tsx: 2 Swiper ĐỒNG BỘ VỚI NHAU (1 hiện nội dung
  text bên trái dùng data-effect="fade", 1 hiện ảnh thumbnail bên phải)
  — đây là tính năng "Swiper thumbs controller" (2 instance Swiper liên
  kết qua thuộc tính `thumbs`, cuộn cùng lúc). Đọc đúng cách Swiper xử
  lý "thumbs" để implement đúng trong React (dùng ref cho từng swiper
  instance, set thumbs.swiper sau khi cả 2 mount). 3 testimonial, LƯU Ý:
  cả 3 đều ghi category "Logistics" dù đây là niche corporate (lỗi nội
  dung có thật trong HTML gốc — GIỮ NGUYÊN, không tự sửa thành
  "Corporate"). Data tách vào src/data/demo-corporate/testimonials.ts.

## NHÓM 4: Insights/Blog (Swiper responsive) + Newsletter

- InsightsSection.tsx: Swiper responsive
  (data-preview=3/data-screen-xl=4/data-tablet=2/data-mobile=1/
  data-mobile-sm=2 — đọc đúng cách carousel.js gốc xử lý các thuộc tính
  data-* này để cấu hình breakpoints Swiper đúng số cột từng màn hình,
  KHÔNG đoán số liệu). 4 blog card, data tách vào
  src/data/demo-corporate/blogHome.ts.

- NewsletterSection.tsx: ảnh + heading + form (input email + nút
  Subscribe, onSubmit preventDefault) + dải avatar nhóm (4 ảnh, "18K
  people..." — text tĩnh).

## Sau MỖI nhóm

Chạy npm run dev, kiểm tra riêng phần vừa làm, báo cáo tóm tắt trước khi
làm nhóm tiếp theo.

## Sau khi xong toàn bộ 4 nhóm

- Cả 3 Swiper (Hero, Insights) chạy đúng, responsive đúng breakpoint
- 2 Swiper Testimonial đồng bộ đúng (đổi ảnh khi đổi text)
- Counter chạy đúng 1 lần khi cuộn tới, không chạy lại khi cuộn qua lại
- Custom cursor "View" ở Case Studies hoạt động đúng khi hover
- Video popup YouTube mở đúng khi bấm nút Play
- Không còn phụ thuộc jQuery
- Build production pass