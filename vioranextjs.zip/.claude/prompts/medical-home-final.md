Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/delay phải GIỐNG TUYỆT
ĐỐI HTML gốc — đọc CSS/JS gốc lấy đúng con số, không áng chừng, không tự
đơn giản hoá. Không chắc cách làm 1 hiệu ứng → dừng hỏi, đừng tự chọn
cách khác.

Convert trang chủ ../viora/viora/demo-medical/index.html (route
"/demo-medical", route group (demo-medical)) — Header/Footer ĐÃ CÓ SẴN,
chỉ làm hero + 9 section trong main-content (ĐÃ ĐỌC ĐỦ, liệt kê chính xác
bên dưới). LÀM THEO TỪNG NHÓM, verify từng nhóm trước khi sang nhóm tiếp.

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE (bài học từ insurance/agency)

1. src/components/layout/demo-medical/HeaderSection.tsx PHẢI gọi
   useScrollSmoother() và useWow() (insurance từng bị thiếu 2 hook này
   làm parallax/.wow không chạy). Thiếu thì thêm, báo cáo.
2. Layout route group (demo-medical) phải có wrapper data-niche="medical"
   và demo-medical.scss dùng selector [data-niche="medical"] (không dùng
   :root) — xác nhận đã đúng.
3. Xem src/hooks/ và src/components/common/ liệt kê hook/component ĐÃ CÓ
   (useCountUp, useSplitTextReveal, useWow, useInfiniteSlide/marquee,
   useAccordion, ShowcaseGallery, dropdown "nice-select" nếu đã làm ở
   niche khác...) — TÁI DÙNG, không viết lại. Chỉ tạo mới khi thật sự
   chưa có.
4. Quy ước link: các trang con của medical CHƯA làm → dùng đúng route
   cuối cùng theo TÊN FILE gốc, tiền tố /demo-medical, ví dụ
   /demo-medical/about, /demo-medical/our-doctor, /demo-medical/service,
   /demo-medical/contact, /demo-medical/appointment,
   /demo-medical/doctor-detail/[slug], /demo-medical/service-detail/[slug],
   /demo-medical/blogdetail/[slug]. LƯU Ý: tên file blog của medical là
   "blogdetail.html" (KHÔNG có gạch nối — đã kiểm tra, đây là tên file
   THẬT, không phải lỗi gõ) → route "/blogdetail/[slug]", giữ nguyên.

## NHÓM 1: Hero (Swiper fade) + About

- HeroSlider.tsx (tf-slider-2): Swiper React, effect "fade" crossFade,
  speed 1000, slidesPerView 1, KHÔNG autoplay (khác hero corporate), KHÔNG
  loop; navigation prev/next (class nav-prev-layout/nav-next-layout +
  "sw-button style-2 xl-hide" — ẩn ở ≤1199px), pagination bullets
  clickable (sw-dots style-1 sw-pagination-layout). 3 slide, CẢ 3 SLIDE
  NỘI DUNG TEXT GIỐNG HỆT NHAU (lỗi demo — GIỮ NGUYÊN, không tự viết
  riêng): tiêu đề "The Most Reliable Health Services Available", mô tả
  "We are deeply committed to providing patient-centered care that
  prioritizes your well-being, delivered with empathy.", nút "Make An
  Appointment"→/demo-medical/appointment (btn-switch-text/btn-double-text
  data-text — hiệu ứng đổi chữ khi hover là CSS, giữ markup), khối
  "Have any question? 1-555-678-8888" (icon-PhoneCall). Chỉ KHÁC bố cục
  ảnh: slide 1 "thumbs" (medical-hero-1.jpg), slide 2 "thumbs-2"
  (medical-hero-2.png, row có h-100 align-items-lg-center), slide 3
  "thumbs-3" 2 ảnh person-1/person-2 (medical-hero-3.png,
  medical-hero-4.png, delay-4/delay-5). Đúng class từng slide.
  HIỆU ỨNG VÀO: class "effect-item effect-left/right/up delay-N" +
  "effect-content-slide" trên root swiper — ĐÃ XÁC MINH đây là CSS THUẦN
  (_animation.scss: animation chạy lại mỗi khi Swiper gắn class
  swiper-slide-active, delay 0.3s×N, duration 1.6s). KHÔNG cần JS riêng:
  chỉ cần đặt className "swiper effect-content-slide" lên <Swiper> và
  giữ đúng class trên từng phần tử. Kiểm tra SCSS đã nằm trong bundle.

- AboutSection.tsx (section-about-3): heading-section-5 (tag "About Us" +
  title "Caring Healthcare You Can Trust" split-text effect-left; mô tả
  split-text split-lines-transform; nút "About Us"→about) + 3
  portfolio-item style-2 hover-image-2 (grid md-col-3 gap_30, ảnh
  410x308 portfolio-item-1/2/3.jpg): "Experienced Professionals" (link
  "Our Teams"→our-doctor), "State-Of-The-Art Facilities." (link "Our
  Services"→service), "Personalized Treatment Plans." (link "Contact
  Us"→contact). GIỮ NGUYÊN dấu chấm cuối ở title 2 và 3 như HTML gốc.
  Nội dung (patient-centered care...) ĐÚNG niche medical, không sửa.

## NHÓM 2: Services (tab) + Why Choose Us

- ServicesTabSection.tsx (section-service-5, bg-primary-color): tag "Our
  Services" + title "Medical Services" (text_white). Cột trái: menu 7 tab
  (tab-slide style-3, mỗi tab "tab-link" + icon-ArrowRight3): General
  Check-Up, Pediatrics, Cardiology, Laboratory Tests, Dermatology,
  Emergency Care, Disease Management. TAB MẶC ĐỊNH ACTIVE LÀ
  "Pediatrics" (tab thứ 2, KHÔNG phải tab đầu). Thay Bootstrap
  data-bs-toggle="tab" bằng useState (id tab đang active), giữ nguyên
  class "active"/"show" để CSS gốc hoạt động. ĐÃ XÁC MINH: cả 7 pane có
  nội dung GIỐNG HỆT NHAU (sub "Cardiology", tiêu đề "Trusted Advanced
  Care for Heart Health", mô tả "At our medical center, our experienced
  cardiologists offer...", ảnh service-9.jpg 480x480, bg
  shape-card-2.png, nút btn-arrow) — lỗi demo, GIỮ NGUYÊN: đổi tab chỉ
  đổi pane đang hiện, nội dung vẫn y hệt (không tự viết nội dung riêng
  cho từng tab). Link tiêu đề/btn-arrow → /demo-medical/service-detail/
  cardiology (slug đúng với dịch vụ Cardiology; nếu chưa có data thì
  hard-code tạm + TODO). Pane active có class effect-item? (không — chỉ
  hero dùng) → không cần animation riêng ngoài hover-image-2 (CSS).

- WhyChooseSection.tsx (section-why-2): tag "Why Choose Us", title
  "Excellence In Modern Healthcare" (split-text effect-left), mô tả
  split-text split-lines-transform, 2 counter: "25" + span tĩnh ",000" +
  sub-counter "+" ("Happy Patients Treated") và "98" + "%" ("Patient
  Satisfaction Rate") — TÁI DÙNG useCountUp (data-count, data-duration
  700, chạy 1 lần khi vào HOÀN TOÀN viewport, đúng cơ chế đã dùng ở
  corporate/insurance). Nút "About Us". Cột phải: ảnh why-2.jpg 600x600
  trong "img-style scale-up-img tf-animateCLP-right" + img.scale-up.
  HAI HIỆU ỨNG ĐÃ ĐỌC TỪ gsapAnimate.js (phải làm đúng):
  (a) tf-animateCLP-*: thêm class "active-animate" khi phần tử vào
      viewport (IntersectionObserver threshold 0.1; thêm kiểm tra khi
      scrollPosition + windowHeight*0.9 > offsetTop), trễ theo
      data-delay (giây, mặc định 0) — phần clip-path reveal còn lại là
      CSS theo .active-animate.
  (b) scale-up-img: scrub — gsap timeline ScrollTrigger {trigger: section,
      start "top bottom", end "bottom center", scrub 1} → phần tử
      ".scale-up" scale tới 1.15 (duration 1).
  Kiểm tra src/hooks đã có hook cho 2 hiệu ứng này chưa (có thể đã tạo ở
  corporate: uncover/parallax); chưa có thì tạo hook dùng chung
  (vd useClipReveal, useScaleUpImage), cleanup đúng khi unmount/đổi route.

## NHÓM 3: Benefit + Testimonial (Swiper loop)

- BenefitSection.tsx (section-benefit bg-light-color): tag "Our Benefit",
  title "Discover The Finest Medical Benefits"; 4 tf-box-icon style-3
  (wow fadeInUp) chia 2 cột (col-lg-5 col-md-6 | offset-lg-1 col-md-6):
  Personalized Patient Care (icon-Asclepius), Fast & Flexible Scheduling
  (icon-ClockUser), Trusted & Certified Experts (icon-SketchLogo),
  Cutting-Edge Medical Tools (icon-Stethoscope). Nội dung giữ nguyên.
  Xác nhận 4 class icon tồn tại trong icomoon đã copy (nếu thiếu → báo).

- TestimonialSection.tsx (section-testimonial-3): Swiper loop=true
  (KHÔNG autoplay), slidesPerView 1, speed 1000, trong col-lg-10, bọc
  "wow fadeInUp"; nav prev/next (wrap-sw-button, gap_12) + pagination
  dots chỉ hiện ≤1199px (class d-xl-none). 3 slide GIỐNG HỆT NHAU (lỗi
  demo, giữ nguyên): 5 sao, "We've never experienced such a
  patient-focused approach. Kudos to the staff for being informative,
  patient, and consistently supportive." — John Smith // CEO Digital
  Themeflat. LƯU Ý markup slide 1 khác slide 2-3 một chút (slide 1: ul
  gap_1 + li "text-body-default font-2 text_primary font-main"; slide 2-3:
  gap_4 + "text-body-2 font-2 text_primary") — GIỮ ĐÚNG class từng slide.
  Data → src/data/demo-medical/testimonials.ts.

## NHÓM 4: Team + Banner + Book Appointment + Insights + Partner marquee

- DoctorsSection.tsx (section-team-2): tag "Meet Our Team", title "Our
  Dedicated Professionals" + nút "View All" (href="#" GIỮ NGUYÊN như HTML
  gốc). Lưới lg-col-4 md-col-2 gap_30, 4 card-team style-2 hover-image-2
  wow fadeInLeft (data-wow-delay "", .1s, .2s, .3s): Dr. Linda Parker
  (Chief Medical Officer), Dr. Samuel Lee (Cardiologist), Dr. Maria Torres
  (Pediatrician), Dr. James Anderson (Neurologist); ảnh team-1..4.png
  300x400; 3 social icon (Facebook/X/Linkedin href="#"); btn-arrow
  href="#". Ảnh + tên → /demo-medical/doctor-detail/[slug]. Tạo
  src/data/demo-medical/doctors.ts (name, role, image, slug — slug:
  dr-linda-parker, dr-samuel-lee, dr-maria-torres, dr-james-anderson) —
  data này sẽ được MỞ RỘNG & DÙNG CHUNG khi làm trang our-doctor và
  doctor-detail, nên đặt tên field rõ ràng.

- BannerSection.tsx (section-banner): ảnh nền banner-1.jpg 1920x336
  (loading eager), title "Ready To Take Charge Of Your Health?" (text_white
  split-text effect-left), mô tả split-lines-transform, 2 nút: "Schedule A
  Free Consultation" (btn-bg-white-2, →appointment) và "Call Us:
  315-666-6688" (style-border-white, href="#"; số điện thoại KHÁC với
  hero — lỗi demo, giữ nguyên).

- BookAppointmentSection.tsx (section-book-appointment): tag "BOOK YOUR
  CONSULTATION NOW" + title "Schedule Appointment Today"; ảnh
  book-consultation-1.jpg 800x588 trong "thumbs scale-up-img
  tf-animateCLP-left" + img.scale-up (dùng lại 2 hook ở Nhóm 2); form
  "form-book-appointment wow fadeInRight": "Book Appointment" / "Schedule a
  consultation to start your journey to better health.", input Your Name,
  input type number "Phone Number", dropdown "Choose Services", textarea,
  nút submit "Book Appointment" (btn-switch-text, w-full), onSubmit
  preventDefault.
  SỬA 2 CHỖ NỘI DUNG (chỉ sửa chỗ sai hẳn, đã áp dụng đúng quy tắc đã
  thống nhất):
  1) Dropdown "Choose Services" trong HTML gốc có option của niche BẤT
     ĐỘNG SẢN ("Buying a Home", "Selling a Property", "Financing
     Options", "Other") → đổi thành dịch vụ y tế khớp 7 tab ở Nhóm 2:
     "Choose Services" (placeholder, selected), "General Check-Up",
     "Pediatrics", "Cardiology", "Laboratory Tests", "Dermatology",
     "Emergency Care", "Disease Management", "Other". Tách mảng option
     vào src/data/demo-medical/ (dùng chung được cho trang appointment
     sau này).
  2) Placeholder textarea lỗi chính tả "Your mesage" → "Your message".
  Dropdown (class "nice-select" — jQuery plugin gốc): viết bằng React
  state (mở/đóng, chọn option, đóng khi click ra ngoài), giữ đúng class
  .nice-select/.current/.list/.option/.selected để CSS gốc hoạt động. Nếu
  đã có component dropdown dùng chung từ niche khác thì TÁI DÙNG; chưa có
  thì tạo src/components/common/NiceSelect.tsx (sẽ còn dùng cho
  appointment/contact...).

- InsightsSection.tsx (section-insights): tag "INSIGHTS", title "Our
  Latest Insights"; lưới lg-col-2, 2 blog-item style-2 hover-image wow
  fadeInLeft (data-wow-delay .1s/.2s), ảnh 280x280 blog-item-15/16.jpg +
  bg shape-card-5.png: "HEALTHCARE — Top Signs You Shouldn't Ignore and
  When to See a Doctor", "WELLNESS — Nutrition Tips Recommended by Our
  Medical Experts". Link (ảnh/tiêu đề/btn-arrow) → /demo-medical/
  blogdetail/[slug] (hợp lệ, đúng tên file thật). Tạo
  src/data/demo-medical/blogPosts.ts (title, tag, image, slug) — sẽ mở
  rộng khi làm bloglist/bloggrid.

- Partner marquee (wrap-partner, tf-spacing-8): 6 logo partner-1..6.svg,
  infiniteslide data-clone=2 data-style=left — TÁI DÙNG useInfiniteSlide/
  PartnerMarquee đã có, KHÔNG viết lại.

## Sau MỖI nhóm

npm run dev, kiểm tra riêng phần vừa làm, báo cáo tóm tắt trước khi sang
nhóm kế.

## Sau khi xong toàn bộ — verify bằng Playwright (mở song song HTML gốc
## và localhost, cùng viewport, cuộn tới từng section, đợi animation)

- Hero: fade giữa 3 slide, animation effect-item chạy lại mỗi lần đổi
  slide, nav ẩn ≤1199px, dots bấm được, KHÔNG autoplay
- Tab dịch vụ: mặc định "Pediatrics", đổi tab đúng, không dùng Bootstrap JS
- Counter 25,000+ / 98% chạy 1 lần khi cuộn tới; chuỗi hiển thị đúng
  "25,000+"
- tf-animateCLP + scale-up: reveal đúng, scale 1.15 theo cuộn
- Testimonial loop, nút prev/next, dots chỉ hiện ≤1199px
- Dropdown "Choose Services" hiện đúng 9 option mới, mở/đóng đúng
- computed style: thẻ <a> text-decoration none, font đúng (kiểm tra CSS
  cascade như mục 8.1 master-workflow)
- Chuyển qua lại / ↔ /demo-agency ↔ /demo-insurance ↔ /demo-medical bằng
  Link (client-side navigation): màu CSS không lẫn niche
- Không phụ thuộc jQuery/Bootstrap JS, npm run build pass