Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "architechture" (route
"/demo-architechture"). Đã XÁC MINH bằng đọc trực tiếp
demo-architechture/index.html — KHÔNG có bug nội dung, 2 bản header giống
hệt nhau.

## 1. Cấu trúc DOM — dùng `header-fixed`, KHÁC 6 niche vừa làm

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer.

2 header "style-19 header-fixed" (ngoài) / "style-19" (trong) — NỘI DUNG
GIỐNG HỆT NHAU. **Cơ chế scroll là `header-fixed` (threshold 300px, KHÔNG
direction-aware) — dùng hook `useHeaderFixed` đã có sẵn ở
src/hooks/useHeaderFixed.ts (viết cho corporate, TÁI DÙNG nguyên, KHÔNG
dùng `useHeaderSticky`)**, prop tên `isFixed` (không phải `isSticky`),
class thêm là `is-fixed` (không phải `is-sticky`) — đúng pattern
demo-corporate/HeaderSection.tsx + Header.tsx, xem lại 2 file đó làm mẫu.
Breakpoint: `mobile-button d-xl-none` → mốc "xl" (1199/1200), ĐÚNG như
bảng mục 1. Container `tf-container w-1840`.

## 2. Header-right — chỉ icon search (KHÔNG cart) + CTA đổi chữ hover

```
<ul class="nav-icon-list">
  <li><a class="nav-icon-item" href="#search"><i class="icon icon-MagnifyingGlass"></i></a></li>
</ul>
<a href="#" class="tf-btn-2 md-hide btn-switch-text">
  <span><span class="btn-double-text" data-text="Get A Quote">Get A Quote</span></span>
</a>
```
CHỈ có icon search, KHÔNG có icon giỏ hàng/cart (khác đa số niche trước).
CTA "Get A Quote" dùng hiệu ứng đổi chữ hover THUẦN CSS giống solarenergy
(`btn-switch-text` + `.btn-double-text[data-text]`, không cần JS), ẩn ở
"md" (≤767px).

## 3. Menu nội dung — không có bug

12 demo mega-menu đúng thứ tự chuẩn, architechture KHÔNG có mặt trong 12
demo featured của chính nó. Pages/Services/Project/Blog/Contact đúng route
corporate. Nút "View all demos" chỉ `tf-btn` trơn.

Mobile offcanvas (`#menu-mobile`, CÓ class "style-dark") đủ 20 niche,
đúng thứ tự chuẩn, "Architechture" tự active đúng vị trí. 5 nhóm
accordion, Contact link thẳng cuối. Modal "View all demos": link
"/landing#demos".

Logo: `logo-architechture-1.svg` (167x52 header, 193x44 mobile).

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- Chỉ icon search hiện (không có cart)
- Hover CTA "Get A Quote" đổi chữ overlay (CSS attr), ẩn ở ≤767px (md)
- Cơ chế header-fixed: cuộn quá 300px → class "is-fixed" trên bản fixed,
  KHÔNG quan tâm hướng cuộn (khác header-sticky của 6 niche vừa làm)
- Mobile: offcanvas có class "style-dark", Demos đủ 20, mọi link đúng
  route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
