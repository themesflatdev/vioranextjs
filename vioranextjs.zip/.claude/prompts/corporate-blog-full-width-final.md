Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc —
đọc kỹ CSS gốc lấy đúng con số, không áng chừng. Nếu không chắc, dừng
hỏi thay vì tự chọn cách khác.

Convert ../viora/viora/demo-corporate/blog-full-width.html thành route
"/blog-full-width" (route group (demo-corporate), Header/Footer đã có
sẵn). Đây là trang blog listing đơn giản, KHÔNG có sidebar (khác biến
thể "blog-with-sidebar" sẽ làm sau).

## Nội dung (đã đọc đủ)

- Heading "Our Blog" / "Latest News" (heading-section style-default)
- 2 blog-item "lớn" xếp hàng ngang (row-blog, flex-column ở mobile,
  flex-row từ md trở lên, ảnh 937x620 và 464x620)
- 7 blog-item còn lại dạng lưới 3 cột (tf-grid-layout md-col-3)
- Pagination tĩnh (3 trang + nút mũi tên, KHÔNG cần làm phân trang thật
  ở bước này — chỉ hiển thị UI giống demo, giống cách đã làm ban đầu ở
  dự án Agentra trước khi có yêu cầu làm thật sau này)
- TẤT CẢ 9 bài đều link tới "blog-detail.html" (1 trang demo dùng chung,
  sẽ làm route động [slug] khi tới lượt convert blog-detail.html)

## Data

Tạo src/data/demo-corporate/blogPosts.ts — 9 bài, mỗi bài: title, author,
date ("June 12, 2025" — giữ nguyên, tất cả bài đều cùng ngày theo HTML
gốc, không phải lỗi cần sửa), image, size ("large" cho 2 bài đầu, "normal"
cho 7 bài còn lại) — để dùng lại được cho các trang blog khác
(blog-with-sidebar, blog-detail) sau này, đặt tên field rõ ràng.

## Component

- BlogFullWidthGrid.tsx (đặt trong components/othersPages/demo-corporate/):
  render đúng bố cục 2 item lớn + 7 item lưới, dùng chung 1
  BlogPostCard.tsx con (nhận props từ data, size lớn/nhỏ) để tái dùng
  cho các trang blog khác.
- Pagination.tsx (đặt trong components/common/ nếu CHƯA có component
  pagination dùng chung nào trong dự án viora — kiểm tra trước, không
  tạo trùng): UI tĩnh giống HTML gốc.

## Trang

Tạo route "/blog-full-width" (page.tsx), ráp: heading + BlogFullWidthGrid
+ Pagination.

Giữ nguyên toàn bộ class CSS gốc.

## Sau khi xong

Chạy npm run dev, dùng Playwright so sánh với HTML gốc:
- Bố cục 2 item lớn + lưới 7 item khớp đúng
- Responsive: ở mobile, row-blog chuyển thành cột dọc (flex-column)
- Pagination hiện đúng UI
- Không phụ thuộc jQuery
- Build production pass