Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "construction" (route
"/demo-construction"). Đã XÁC MINH bằng đọc trực tiếp
demo-construction/index.html.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (KHÔNG
splitting.min.js). Có #smooth-wrapper/#smooth-content — LƯU Ý: ngay sau
#smooth-content, TRƯỚC header thường, có 1 `.topbar-2` phức tạp (email +
địa chỉ + dropdown ngôn ngữ + dropdown văn phòng "New York/Ha Noi/Los
Angeles/London Office") — đây là NỘI DUNG TRANG CHỦ (Bước 3), KHÔNG dựng
ở bước Header này, chỉ ghi nhận để không nhầm cấu trúc DOM sau này.

2 header "style-11 header-sticky" / "style-11" — ĐÃ DIFF: giống hệt nhau
(chỉ khác class + line-wrap).

Cơ chế scroll: header-sticky → `useHeaderSticky` (đã có sẵn), ĐÚNG như
bảng. Breakpoint: `<nav class="main-menu style-2 xl-hide">` — có class
"xl-hide" tường minh → mốc "xl" (1199/1200), ĐÚNG như bảng, xác nhận chắc
chắn qua class thật (không như spasalon/coworkingspace bị sai).

## 2. PATTERN chung: Pages/Services/Project/Blog/Contact TRỎ SANG CORPORATE

Xác nhận lại đúng (xem memory index-only-niches-reuse-corporate-pages) —
route thật corporate, KHÔNG tiền tố `/demo-construction`. Bỏ "404 Error".

## 3. Chi tiết markup riêng

- `tf-container w-1840`, `<nav class="main-menu style-2 xl-hide">`.
- header-right CÓ 2 phần khác các niche trước:
  - `.nav-icon-list`: icon search (`icon-MagnifyingGlass`, trỏ
    `href="#search"`, mở offcanvas search — offcanvas search THẬT SỰ
    KHÔNG xây ở bước này, ngoài phạm vi Header, CHỈ render markup/icon
    tĩnh, link không cần hoạt động) + icon giỏ hàng (`icon-Handbag` +
    badge số "24", trỏ `#shoppingCart` — offcanvas giỏ hàng CŨNG ngoài
    phạm vi, chỉ render markup tĩnh).
  - CTA `<a class="tf-btn btn-hover-animate-2 btn-bg-primary-2 rounded-0
    sm-hide">Get A quote</a>` (href="#", ẩn ở ≤575px).
  - rồi `.mobile-button.d-xl-none`.
- Offcanvas mobile-nav-wrap KHÔNG có class phụ nào.
- Logo: `logo-construction.svg`.

## 4. Menu (giữ nguyên, không phát hiện bug link nào)

12 demo mega-menu thứ tự y hệt các niche trước, "Home Construction"...
XÁC NHẬN LẠI: construction có nằm trong 12 demo featured của chính nó hay
không (đọc kỹ danh sách 12 demo trong HTML gốc trước khi code — nếu
construction KHÔNG có card tự-trỏ-chính-mình giống coworkingspace thì giữ
đúng y hệt danh sách 12 demo chuẩn không thêm bớt, nếu CÓ thì map đúng vị
trí "Home Construction" trỏ "/demo-construction").

Mobile — đủ 20 niche, 5 nhóm accordion Demos/Pages/Services/Project/Blog,
Contact link thẳng cuối.

Modal "View all demos": link "/landing#demos".

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover 4 submenu mở đúng (CSS hover)
- CTA "Get A quote" ẩn ở ≤575px (sm-hide)
- Search/cart icon hiện đúng, KHÔNG cần verify chức năng mở offcanvas
  (ngoài phạm vi)
- Cơ chế header-sticky: kiểm tra scrollHeight trước khi chọn giá trị test
  cuộn, ưu tiên page.mouse.wheel()
- Mobile: Demos đủ 20, mọi link Pages/Services/Project/Blog/Contact trỏ
  đúng route corporate
- Không có .char, không console error, không phụ thuộc jQuery/Bootstrap JS
