Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition phải GIỐNG TUYỆT ĐỐI HTML gốc
(../viora/viora/demo-medical/). Đọc CSS/JS gốc lấy đúng con số, không áng chừng,
không tự đơn giản hoá. Không chắc cách làm 1 hiệu ứng -> dừng hỏi.

Làm 9 trang trong dropdown "Pages" của medical (route group (demo-medical), prefix
/demo-medical), THEO NHÓM, verify xong nhóm nào báo cáo nhóm đó rồi mới sang nhóm sau:
  Nhóm 0: phần dùng chung  |  Nhóm 1: About, Our Doctor, Doctor Detail
  Nhóm 2: Testimonials, Pricing, Working Hours, FAQs  |  Nhóm 3: Appointment, Cost Calculator
KHÔNG làm Services, Service Detail, Porfolio, Blog, Contact ở bước này.

## BƯỚC 0 — KIỂM TRA TRƯỚC KHI CODE
1. Lỗi Swiper (nút/dots mặc định màu xanh) đã sửa chưa? Nếu CHƯA áp dụng
   fix-swiper-controls.md thì làm nó TRƯỚC (pricing + testimonial của các trang dưới
   dùng Swiper). Lưu ý: ở pricing, dots `.sw-pagination-layout` nằm NGOÀI `.swiper`
   (cùng cấp, trong `.sw-layout`) -> giữ đúng vị trí như HTML gốc; hook dùng ref nên
   không phụ thuộc vị trí.
2. Các trang này dùng datepicker jQuery UI: HTML gốc nạp assets/css/jquery-ui.css
   (36KB) mà chuỗi SCSS vendor của dự án CHƯA có. Thêm src/styles/vendor/jquery-ui.scss
   (copy nội dung assets/css/jquery-ui.css) và @use nó TRƯỚC reset trong app.scss như các
   vendor khác. KHÔNG nạp bằng thẻ <link>.
3. `ls src/hooks src/components/common` và dùng lại thứ đã có: useCountUp, useWow,
   useSplitTextReveal, useScrollSmoother, useAccordion (1 mục mở), cơ chế collapse
   transition chung (grid-template-rows), tab giá Monthly/Yearly (tạo ở corporate
   services nếu có), dropdown NiceSelect, DoctorsSection/BannerSection/
   BookAppointmentSection/BenefitSection/WhyChooseSection/TestimonialSection của
   trang chủ medical. Chỉ tạo mới khi chưa có.
4. HeaderSection của medical phải gọi useScrollSmoother() + useWow(); layout có
   wrapper data-niche="medical".
5. Route theo TÊN FILE gốc: /demo-medical/about, /our-doctor, /doctor-detail/[slug],
   /testimonials, /pricing, /workinghours, /appointment, /costcalculator, /faqs.
   LƯU Ý: menu gốc ghi href "FAQs.html" (F hoa) nhưng file thật là "faqs.html" -> route
   là /faqs, sửa href trong menu. Sau khi có route doctor-detail, SỬA mục menu
   "Doctor Detail" (desktop + mobile) trỏ /demo-medical/doctor-detail/dr-linda-parker
   (slug đầu tiên), không để trỏ route không slug (404).

## NHÓM 0 — PHẦN DÙNG CHUNG

0.1 PageHeaderBanner (khối `page-layout-v01`, nằm NGOÀI main-content, trước nó): breadcrumb
  + h2 + ảnh images/hero.png 696x509. Markup gốc: .page-layout-v01 > .tf-container.medium
  > .row > col-lg-6 (.content: ul.tf-breadcrumb.mb_12 [li.text-label > a.link.text_primary-color
  "HOME" -> /demo-medical, li.text_primary-color.text-label crumb] + h2.title.text_primary-color)
  | col-lg-6 (.thumb.d-flex.align-items-end > img). Props: crumb, title. Giá trị từng trang:
  about "ABOUT US"/"About Us" | our-doctor "OUR DOCTORS"/"Our Doctors" | doctor-detail
  "Doctor details"/"Our Doctors" (giữ như gốc) | testimonials "Testimonials"/"Testimonials" |
  pricing "Pricing"/"Pricing" | workinghours "Working hours"/"Working Hours" | appointment
  gốc ghi "Make An apppointment"/"Make An appointment" -> SỬA lỗi chính tả thành "Make An
  Appointment" cho cả 2 | costcalculator "Cost Calculator"/"Cost Calculator" | faqs gốc ghi
  "fAQs" -> SỬA thành "FAQs", h2 "FAQs".

0.2 Hai block cuối trang là BIẾN THỂ của component trang chủ (đã đối chiếu từng dòng) — thêm
  prop `variant`, KHÔNG viết lại component:
  - BannerSection variant "inner": nút 1 là `tf-btn btn-hover-animate btn-bg-white` với
    <span class="text_primary-color">Schedule A Free Consultation</span><span></span> (KHÔNG
    dùng btn-switch-text/btn-double-text như trang chủ). Nút 2 và phần còn lại giữ nguyên.
  - BookAppointmentSection variant "inner": ảnh bọc bằng `<div class="hover-image-2"><div
    class="thumbs img-style tf-animateCLP-left">` và <img> KHÔNG có class scale-up (trang chủ
    mới dùng scale-up-img); nút submit `tf-btn btn-hover-animate btn-bg-primary-2 btn-bg-1
    btn-px-28 w-full` với <span>Book Appointment</span><span class="bg-effect"></span>; h4 có
    class font-main. Thêm prop `bgLight` (class `bg-light-color` — có ở doctor-detail,
    testimonials, pricing, workinghours, faqs; KHÔNG có ở about, our-doctor). Dropdown
    "Choose Services" dùng cùng mảng option y tế đã sửa ở trang chủ; "Your mesage" ->
    "Your message".
  Copy markup từng biến thể từ HTML gốc, đừng suy từ trang chủ.

0.3 Data bác sĩ: src/data/demo-medical/doctors.ts, thêm mảng `doctorsAll` ĐỦ 8 người của
  trang our-doctor (ảnh 300x400): Dr. Linda Parker — Cardiologist (team-5.png); Dr. Samuel Lee —
  Cardiologist (team-2.png); Dr. Maria Torres — Pediatrician (team-3.png); Dr. James Anderson —
  Neurologist (team-4.png); Dr. Joseph Jessica — Heart Specialist (team-6.png); gốc ghi
  "Dr. Andew Hope" -> SỬA thành "Dr. Andrew Hope" — Neurology Expert (team-7.png); Dr. Jessica
  Jung — Medicine Specialists (team-8.png); gốc ghi "Dr. david John" -> SỬA thành "Dr. David
  John" — Medicine Specialists (team-9.png). Slug: dr-linda-parker, dr-samuel-lee,
  dr-maria-torres, dr-james-anderson, dr-joseph-jessica, dr-andrew-hope, dr-jessica-jung,
  dr-david-john. Mảng 4 người của trang chủ (Linda Parker là Chief Medical Officer, ảnh team-1)
  GIỮ NGUYÊN như HTML gốc (cùng tên Linda Parker nhưng khác ảnh/chức danh giữa trang chủ và
  our-doctor là đặc điểm của theme, không sửa); link của họ đều trỏ slug tương ứng.

## NHÓM 1 — ABOUT, OUR DOCTOR, DOCTOR DETAIL
Thứ tự block KHÁC nhau giữa các trang — theo đúng thứ tự dưới đây.

### /demo-medical/about  (PageHeaderBanner, rồi main-content)
1. section-benefit (variant "about"): KHÁC trang chủ — không có bg-light-color; tiêu đề nằm
   riêng 1 row `col-xxl-5`; 4 box nằm trong `row align-items-end` (col-lg-5 col-md-6 |
   offset-lg-1 col-md-6); nội dung 4 box giống trang chủ.
2. section-why-2 v2 (`section-why-2 v2 bg-light-color tf-spacing-1`): ảnh BÊN TRÁI (col-md-6
   hover-image-2 > .img-style.tf-animateCLP-right, KHÔNG scale-up-img), nội dung bên phải; chữ
   + 2 counter (25,000+ / 98%) giống trang chủ; nút "About Us" href="#".
3. section-team-2: GIỐNG HỆT trang chủ (4 bác sĩ) -> tái dùng DoctorsSection.
4. section-banner (variant inner)  5. section-book-appointment (variant inner, KHÔNG bgLight).

### /demo-medical/our-doctor
1. section-doctor-details (variant "lead"): ảnh images/doctor-detail.jpg 600x600 bên trái
   (col-lg-6 hover-image-2 > .img-style.tf-animateCLP-right); phải: tag "team leader", h2 "Dr.
   Linda Parker", đoạn mô tả, 3 counter (20 + sub "k" "Happy Patients"; 10 + "+" "Years
   Experience"; 30 + "+" "Certificates"; data-duration 700), nút "Read More" ->
   /demo-medical/doctor-detail/dr-linda-parker.
   SỬA đoạn mô tả (gốc có chữ vô nghĩa: "from and the a preventive care ... and the a the and
   providing"): "Health care is a vital aspect of maintaining overall well-being, encompassing
   a range of services from preventive care to the treatment of illnesses. It focuses on
   promoting health, preventing diseases, and providing medical attention when needed."
2. section-team-2 (variant "all"): `section-team-2 tf-spacing-1 bg-secondary-color`, tag
   "Meet Our Team" (class tag v2), title "Our Dedicated Professionals", card `card-team style-2 v2
   hover-image-2 wow fadeInLeft` (khác trang chủ ở "v2"), lưới tf-grid-layout lg-col-4 md-col-2
   gap_30, ĐỦ 8 bác sĩ từ doctorsAll, data-wow-delay lặp ["", ".1s", ".2s", ".3s"] ×2. Ảnh +
   tên -> /doctor-detail/[slug]; 3 social icon href="#"; btn-arrow href="#".
3. section-book-appointment (inner, KHÔNG bgLight)  4. section-banner (inner)
   (CHÚ Ý: ở trang này book-appointment đứng TRƯỚC banner.)

### /demo-medical/doctor-detail/[slug]  — ROUTE ĐỘNG
Cùng quy ước các trang detail trước: HTML gốc chỉ có 1 bản nội dung demo; thân bài DÙNG CHUNG
cho mọi slug, chỉ phần theo slug là tên/chức danh (tra doctorsAll, slug lạ -> notFound()),
generateStaticParams theo 8 slug.
1. section-doctor-details (variant "detail"): cột trái `box-left`: ảnh doctor-detail.jpg +
   khối "Working Hours" (h4 font-main fw-6) với 7 dòng Monday..Sunday, mỗi dòng "08:30 - 18:00"
   và link "Book Now" (hover-line-text) -> /demo-medical/appointment. Cột phải: tag "team leader",
   h2 = TÊN bác sĩ (theo slug), 2 đoạn mô tả, 3 counter (như our-doctor), khối "Education &
   Experience" (4 dòng).
   SỬA mâu thuẫn nội bộ của bản demo (cùng nguyên tắc đã làm ở team-detail corporate):
   - Dòng h6 dưới h2 gốc lặp lại đúng tên ("Dr. Linda Parker") -> hiển thị CHỨC DANH của bác sĩ
     theo slug.
   - Đoạn mô tả 1: dùng đúng đoạn đã làm sạch ở our-doctor (bỏ chữ vô nghĩa); đoạn 2 giữ
     nguyên ("Medical services are an essential part of our lives...").
   - Education: giữ "Christian Medical College & Hospital Ludhiana". "Specialty" gốc là
     "Neurology Expert" -> dùng chức danh theo slug; "Degrees" gốc "Neurology Expert" (trùng) ->
     "MD, Board Certified"; "Training" gốc "Interventional Neurology Expert" -> "Advanced
     Clinical Training". (Lý do: thân bài dùng chung cho 8 bác sĩ, không được mâu thuẫn với
     chức danh hiển thị.)
2. section-book-appointment (inner, bgLight)  3. section-banner (inner)

## NHÓM 2 — TESTIMONIALS, PRICING, WORKING HOURS, FAQS
### /demo-medical/testimonials
1. section-testimonial: h2 "Our Client Happy Say About Us" (text_primary, split-text
   effect-left), lưới tf-grid-layout lg-col-3 md-col-2 gap_30, 6 `testimonial-item style-7 v2`,
   thực chất 3 người LẶP 2 lần (giữ nguyên, lỗi demo): Jamie L — Content Marketer (avatar-16)
   "Working with Viora has completely shifted how I take care of myself. I have more energy,
   better focus, and feel truly in control of my health."; Alex Johnson — Content Marketer
   (avatar-12) "Viora didn’t just give me a plan — they gave me confidence. I feel stronger,
   calmer, and more balanced than ever before."; Rebecca M — Marketing Consultant (avatar-10)
   "I’ve tried so many programs, but Viora is the first that actually stuck. Everything was
   personalized, realistic, and supportive." (dùng dấu nháy cong ’ và gạch — như gốc; thứ tự
   trong HTML gốc: Jamie, Alex, Rebecca, Jamie, Alex, Rebecca). Avatar dùng ảnh dùng chung
   assets/images/avatar/avatar-N.jpg.
2. section-testimonial-3: GIỐNG HỆT trang chủ -> tái dùng TestimonialSection (Swiper loop, đã
   sửa nút/dots theo fix-swiper-controls).
3. book-appointment (inner, bgLight)  4. banner (inner)

### /demo-medical/pricing
section-pricing-6 flat-animate-tab: h2 "Regular Health Checkup <br> Package For You"
(heading-section style-default text-center, split-text effect-RIGHT — khác các nơi khác dùng
effect-left); tab-slide style-1 có <li class="item-slide-effect"> + 2 tab: Monthly (active,
data-pricing="monthly"), Yearly (data-pricing="year"); `.pricing-container` bọc; Swiper
(preview 3 / tablet 2 / mobile 1, space-lg 30 / md 20 / 15 — đọc carousel.js để cấu hình đúng
breakpoint), dots `.sw-dots.style-1.position-relative.z-5.sw-pagination-layout.text-center.mt_24`
đặt NGOÀI .swiper; 3 `pricing-item style-1`:
 - Regular Plan (wow fadeInRight, nút viền): "Ideal for routine check-ups and preventive care,
   this plan covers essential consultations, general screenings." data-monthly 25 / data-yearly 55;
   nút "Appointment Now" (style-border btn-hover-animate-border); 5 mục: General health check-ups;
   Blood & cholesterol screening; Basic laboratory tests; Doctor consultations; Prescription guidance.
 - Standard Plan (z-5 wow fadeInDown, tag "Popular" + ảnh shape/Lightning-2.png): "This package
   includes diagnostic tests, specialist consultations, and care services for a proactive approach
   to health." (gốc gõ sai "care servs" -> SỬA "services"); 35 / 85; nút đặc btn-hover-animate;
   Everything in the Basic Plan; Specialist consultations; Advanced diagnostics; Vaccinations &
   immunizations; Chronic disease management.
 - Premium Plan (wow fadeInLeft, nút viền): "The most extensive health plan, offering full-body
   check-ups, priority medical access, and tailored wellness programs." 69 / 99; All in the
   Comprehensive Plan; Full-body health assessment; Priority appointments 24/7; Personalized
   nutrition; Mental health counseling.
 (Tên gói trong danh sách tính năng — "Basic Plan", "Comprehensive Plan" — lệch với tên gói thật
 "Regular"/"Standard": lỗi demo, GIỮ NGUYÊN. Nút "Appointment Now" href="#" giữ nguyên.)
 Nội dung pricing này đúng niche medical (chính là nguồn gốc của đoạn từng lọt sang insurance).
CƠ CHẾ JS GỐC (đã đọc main.js — làm đúng):
 (a) initSwitchPriceValue, phạm vi `.pricing-container`: mỗi `.price-value` có .price-month và
     .price-year đều được điền text (monthly / yearly); tab Monthly -> .price-month nhận class
     "active", .price-year bỏ "active", `.price-period` = "/ month"; tab Yearly -> ngược lại và
     "/ year". Mặc định chạy ở "monthly". (data-pricing của tab 2 là "year", mọi giá trị khác
     "monthly" đều coi là yearly.) Nếu corporate-services đã có hook tab giá thì TÁI DÙNG.
 (b) tabSlide: `.item-slide-effect` đặt width = outerWidth của li.active, transform
     translateX(vị trí left của li) khi click, khi resize và lúc khởi tạo; CSS transition 0.5s
     (đã có trong SCSS). Dùng chung cho mọi `.tab-slide`.
Sau đó book-appointment (inner, bgLight) + banner (inner).

### /demo-medical/workinghours
section-workinghours flat-animate-tab: tag "Working hours" (mb_20), h2 "Find The Hours That
Suits For You" (text-center), tab-slide style-6 (KHÔNG có item-slide-effect) 4 tab: View All,
Body Surgery (MẶC ĐỊNH ACTIVE — tab thứ 2), Dental Care, Cardiology; nội dung `tab-content wow
fadeInLeft` (data-wow-delay .1s): cả 4 pane đều là cùng 1 ảnh images/calendar.png 1290x936 bọc
`.calendar` (lỗi demo — GIỮ NGUYÊN, đổi tab chỉ đổi pane đang hiện). Tab bằng useState, giữ class
active/show. Sau đó book-appointment (inner, bgLight) + banner (inner).

### /demo-medical/faqs
section-faqs-2: tag "FAQs", h2 "Frequently Asked Questions"; 2 cột col-lg-6, mỗi cột là 1
accordion ĐỘC LẬP kiểu CHỈ 1 MỤC MỞ (data-bs-parent riêng: #accordion-faq và #accordion-faq2);
`accordion-item style-border`, tiêu đề h6.title.text-capitalize. Chỉ câu 1 (cột trái) mở sẵn.
Dùng hook accordion 1-mục-mở + cơ chế collapse transition chuẩn của dự án. 8 câu hỏi GIỮ NGUYÊN
như HTML gốc (cột trái 1-4, cột phải 5-8) — chúng gần như lặp nhau và câu 2 sai ngữ pháp, đó là
đặc điểm của theme, KHÔNG viết lại. Riêng 8 câu TRẢ LỜI gốc đều là Lorem Ipsum chưa viết ->
viết câu trả lời thật (đã chọn theo chính sách xử lý placeholder):
 1 "What should I do in case of a medical emergency?" — "In a life-threatening situation, call
   your local emergency number immediately. For urgent but non-critical care, contact our
   emergency line at 1-555-678-8888 and our team will guide you to the right care."
 2 "What are Dedicated to Better Health?" — "Our clinic is dedicated to better health through
   preventive care, accurate diagnosis and personalized treatment plans delivered by experienced
   doctors."
 3 "What should I do in case of a medical emergency?" — "Stay calm, move to a safe place if you
   can, and call emergency services. If you are already our patient, let us know so we can share
   your medical history with the responding team."
 4 "What should I do in a medical emergency?" — "Check that the person is breathing and
   responsive, call for help, and follow the dispatcher's instructions until medical staff arrive."
 5 "What may I do in a medical emergency?" — "You may call our emergency line, go to the nearest
   emergency room, or contact us to arrange urgent same-day care when it is safe to do so."
 6 "What must I do during a medical emergency?" — "Contact emergency services first, avoid moving
   someone with a suspected serious injury, and keep a list of medications and allergies ready for
   the medical team."
 7 "What can I do during a medical emergency?" — "You can provide basic first aid if you are
   trained, keep the patient comfortable and calm, and give clear information to the responders
   when they arrive."
 8 "What must I do in a medical emergency?" — "Act quickly: call emergency services, share the
   patient's condition and location, and follow our team's advice for any follow-up care."
Data -> src/data/demo-medical/faqs.ts. Sau đó book-appointment (inner, bgLight) + banner (inner).

## NHÓM 3 — APPOINTMENT, COST CALCULATOR
### /demo-medical/appointment  (chỉ có 2 block: section-book-appointment-3, rồi banner inner)
`.wrap` gồm 2 phần: `form.form-book-appointment.d-grid.gap_20` (tiêu đề "Book Appointment" /
"Schedule a consultation to start your journey to better health.") và `.box-info` ("Reach Out to
Us" + 3 mục info-list: icon-PhoneCall "Emergency Contact:" 1-555-678-8888; icon-MapPin "Home
Visit:" 101 E 129th St, East Chicago, 2nd Floor, NY; icon-Alarm "Working Hours:" 24/7 from Mon to
Sat). Form: Your Name; Phone Number (type number); dropdown "Choose Services" (SỬA: gốc là option
bất động sản "Buying a Home/Selling a Property/Financing Options" -> dùng đúng mảng 7 dịch vụ y tế +
"Other" đã dùng ở trang chủ); dropdown "Choose Doctor" (Dr. Linda Parker, Dr. Samuel Lee, Dr.
Maria Torres, Dr. James Anderson — gốc để value rác "buying/selling/financing/Other": thay bằng
slug bác sĩ); ô ngày `#datepicker` (placeholder mm/dd/yyyy, icon-CalendarBlank); textarea (SỬA
"Your mesage" -> "Your message"); nút submit `tf-btn btn-hover-animate btn-bg-1 btn-px-28 w-full`
với <span class="bg-effect">. onSubmit preventDefault. Dropdown = NiceSelect React (state mở/đóng,
đóng khi click ngoài) giữ class .nice-select/.current/.list/.option/.selected.
DATEPICKER (thay jQuery UI): gốc gọi `$("#datepicker").datepicker()` KHÔNG tuỳ chọn -> mặc định
jQuery UI: định dạng mm/dd/yy (vd 10/05/2026), mở khi focus/click ô, tiêu đề "Tháng Năm" với nút
prev/next, hàng thứ Su–Sa, hôm nay được đánh dấu, chọn ngày thì điền ô và đóng lịch. Tạo
components/common/DatePickerInput.tsx tự vẽ lịch bằng React nhưng với ĐÚNG DOM/class của jQuery UI
(ui-datepicker, ui-datepicker-header, ui-datepicker-prev/next, ui-datepicker-title,
ui-datepicker-calendar, ui-state-default/highlight/active, ui-datepicker-other-month...) để
jquery-ui.css + `.ui-datepicker {width:320px !important}` của theme áp dụng đúng. ĐỪNG đoán class:
mở HTML gốc bằng Playwright, click #datepicker, in `document.querySelector('.ui-datepicker')
.outerHTML` và sao chép cấu trúc đó; đo vị trí popup (dưới ô input, z-index) rồi làm giống.
Không cài jQuery. Chuyển tháng bằng nút prev/next hoạt động.

### /demo-medical/costcalculator  (chỉ có section-cost-calculator, rồi banner inner)
`.box-calculator` gồm `.box-left` và `.box-right`.
- box-left: h4.title.mb_48 "General Advices" + 5 `.box-icon` (icon + h6.text_primary-color + p).
  Tiêu đề/icon: Make A Calculator (icon-Calculator), Check Free Time (icon-Alarm), Arrange Checkup
  (icon-Calendar), Arrive In Time (icon-Car), Finish The Checkup (icon-Smiley). Mô tả gốc đều là
  Lorem Ipsum chưa viết -> viết thật: "Estimate your treatment cost in seconds by choosing the
  procedures you need." / "Review our working hours and find a convenient time slot for your visit."
  / "Book your consultation online and let our team prepare everything in advance." / "Plan your
  trip, arrive a few minutes early and complete your check-in with ease." / "Receive your results
  and a personalized care plan before you leave."
- box-right: `form.form-calculator` có 3 `.box`, mỗi box h3.heading.mb_40 + `.d-grid.gap_20` gồm
  4 hàng `d-flex align-items-center gap_12`: (nhãn + NiceSelect), (nhãn "Number" + range), (nhãn +
  NiceSelect), (nhãn "Number" + range). Nhãn chữ `.title.text-button.text_primary`.
  Box 1 "Cosmetic Dentistry procedures": "Dental Service" [Lumineers veneers, Porcelain veneers,
  Composite veneers]; range mặc định 8; "Teeth Service" [Professional, Dentist-dispensed at-home
  systems]; range 8.
  Box 2 "Basic Dentistry Procedures": "Dental Filling" [Front teeth dental bonding, Back teeth dental
  bonding, Dental amalgam]; range 5; "Teeth Service" [Pulling Teeth, Wisdom tooth extractions,
  Wisdom tooth extractions, Wisdom tooth extractions] (lặp — lỗi demo, giữ nguyên); range 8.
  Box 3 "Reconstructive Dental Procedures": "Dentures" [Dental crowns, Conventional dental bridges,
  Maryland Bridges]; range 8; "Teeth Service" [Complete dentures, Partial dentures]; range 8.
  Mọi NiceSelect có placeholder "Choose Services" (selected).
  Thanh trượt `.tf-range-slider`: input[type=range].slider min 0 max 10 + `.thumb.thumb-circle.h4`
  hiện giá trị. JS gốc (rangeSlide): left của thumb = percent*(sliderWidth-40)+20 (px) với
  percent=(val-min)/(max-min); cập nhật khi kéo (input), khi resize và lúc khởi tạo; textContent =
  giá trị. Viết hook useRangeThumb (ref + ResizeObserver) đúng công thức này.
  `.wrap-total`: "Total:" + h6.total.font-main.text-white = "$120". ĐÃ XÁC MINH JS gốc KHÔNG tính
  tổng — "$120" là chữ TĨNH trong HTML. GIỮ NGUYÊN "$120" tĩnh (không tự thêm logic tính tiền); ghi
  chú trong báo cáo cuối rằng đây là giới hạn của theme gốc.

## VERIFY (bắt buộc sau MỖI nhóm; nếu đã cài scripts/viora-check.mjs và viora-links.mjs thì dùng,
## nếu chưa thì dùng Playwright tự viết)
- So HTML gốc với Next ở 1440, 991, 575: thứ tự block, chiều cao block, ảnh, font, link KHÔNG gạch
  chân, không có nút/dots Swiper mặc định (số `.swiper-button-*`/`.swiper-pagination` = 0).
- Quét link nội bộ của từng trang: không còn 404 (đặc biệt menu "Doctor Detail", "FAQs", các nút
  "Book Now"/"Read More"); bấm card bác sĩ ở about/our-doctor/trang chủ -> đúng
  /doctor-detail/[slug], đổi tên/chức danh đúng, slug lạ -> 404.
- Pricing: đổi Monthly/Yearly đổi giá + "/ month" / "/ year", thanh trượt tab chạy mượt (0.5s), dots hoạt động.
- Working hours: mặc định tab "Body Surgery". FAQs: mỗi cột chỉ 1 mục mở, câu 1 mở sẵn, có transition.
- Appointment: dropdown mở/đóng/chọn được, datepicker mở/chọn ngày/đổi tháng, giao diện khớp gốc.
- Cost calculator: 6 thanh trượt, thumb hiện đúng số và đúng vị trí, 6 dropdown, "$120" tĩnh.
- Chuyển qua lại / ↔ /demo-agency ↔ /demo-medical bằng <Link>: màu không lẫn.
- Không jQuery/Bootstrap JS; npm run build pass.

Báo cáo cuối: file đã tạo/sửa, hook/component mới (DatePickerInput, useRangeThumb...), nội dung đã
viết lại (nguyên văn: FAQ answers, cost calculator advices, doctor-detail, bio), lỗi chính tả đã sửa,
việc chưa xong.bawts