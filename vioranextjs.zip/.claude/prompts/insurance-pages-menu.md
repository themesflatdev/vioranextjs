Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation phải GIỐNG TUYỆT ĐỐI HTML gốc.

Làm 6 trang trong dropdown "Pages" của insurance, THEO ĐÚNG THỨ TỰ, báo
cáo xong trang nào rồi mới sang trang tiếp theo:

About Us → Our Team → Team Detail → Testimonials → Pricing → FAQs

NHIỀU SECTION TÁI DÙNG được từ trang chủ insurance đã build (AboutSection,
ServicesSwiperSection, OverviewSection, FAQSection với hook
useScrollSmoother/useWow) — kiểm tra trước khi viết mới, KHÔNG viết lại.

=====================================================================
TRANG 1 — /demo-insurance/about-us (about-us.html) — 5 section
=====================================================================

1. section-about: GIỐNG HỆT AboutSection.tsx đã build ở trang chủ (cùng
   nội dung, cùng counter) — TÁI DÙNG THẲNG.
2. section-service-4: GIỐNG HỆT ServicesSwiperSection.tsx đã build ở
   trang chủ — TÁI DÙNG THẲNG (đã sửa link "Explore All Plans" ở bước
   trang chủ rồi, không cần sửa lại).
3. section-team (MỚI): 3 thành viên (Maria Torres-CEO, David Cho-CTO,
   Amira Hassan-Head of Strategy — ĐÂY LÀ SUBSET của 6 người đầy đủ ở
   Trang 2, dùng chung data, KHÔNG tạo trùng) + nút "Join Our Team"→"#".
4. section-overview: GIỐNG HỆT OverviewSection.tsx đã build ở trang chủ
   — TÁI DÙNG THẲNG.

=====================================================================
TRANG 2 — /demo-insurance/our-team (our-team.html)
=====================================================================

section-team đầy đủ: 6 thành viên — Maria Torres (CEO), David Cho (CTO),
Amira Hassan (Head of Strategy), Sofia Almeida (Director of Product),
**[VỊ TRÍ 5 BỊ LỖI]**, Isabelle Laurent (Head of People).

ĐÃ XÁC NHẬN: vị trí 5 trong HTML gốc bị lỗi copy-paste (lặp y hệt "Amira
Hassan - Head of Strategy" thay vì 1 người khác) — THAY bằng người MỚI:
"Daniel Reyes" — "Director of Claims" (dùng ảnh team-5.jpg đã có sẵn,
chỉ đổi tên/chức danh).

Tạo src/data/demo-insurance/teamMembers.ts DÙNG CHUNG cho Trang 1 (subset
3 người đầu) và Trang 3 (team-detail).

=====================================================================
TRANG 3 — /demo-insurance/team-detail/[slug] (team-detail.html) — ROUTE ĐỘNG
=====================================================================

1 bản demo dùng chung (giống HỆT cấu trúc corporate's team-detail —
sticky avatar bên trái "data-startoffset=450", "Areas of Expertise" bên
phải). PHÁT HIỆN CÙNG LỖI đã gặp ở corporate: tiêu đề "Chief Executive
Officer" nhưng mô tả lại viết "Maria Torres is the Chief Marketing
Officer" — ÁP DỤNG CÙNG CÁCH SỬA đã làm cho corporate: bỏ cụm "Chief
Marketing Officer" khỏi mô tả, đổi she/her → they/their, dùng đúng y hệt
đoạn thay thế đã viết cho corporate's team-detail.

Title/tên/ảnh lấy theo slug (tra teamMembers.ts insurance, 6 slug). Route
"/team-detail/[slug]/page.tsx", generateStaticParams theo 6 slug.

=====================================================================
TRANG 4 — /demo-insurance/testimonials (testimonials.html)
=====================================================================

Lưới 6 testimonial (Savannah Nguyen-Homeowner, Bessie Cooper-Villa Owner,
Jerome Bell-Architect, Theresa Webb-Homeowner, Jessica Jung-Homeowner,
Ferran Lopez-Homeowner) — NỘI DUNG NÀY HOÀN TOÀN PHÙ HỢP insurance (nói
về "coverage", "peace of mind"), GIỮ NGUYÊN 100%, KHÔNG sửa gì (đây
chính là nguồn gốc nội dung đã từng bị lạc sang agency trước đó — giờ ở
đúng chỗ của nó).

Data tách vào src/data/demo-insurance/testimonialsFull.ts. Cuối trang:
section-overview (tái dùng) + section-faqs-1 (tái dùng).

=====================================================================
TRANG 5 — /demo-insurance/pricing (pricing.html) — SỬA TOÀN BỘ TÍNH NĂNG
=====================================================================

ĐÃ XÁC NHẬN theo quy tắc đã thống nhất (chỉ sửa khi sai hẳn chủ đề): toàn
bộ 3 gói pricing đang dùng tính năng/nút bấm của niche MEDICAL ("Blood &
cholesterol screening", "Doctor consultations", nút "Appointment Now")
dù heading đúng ghi "Insurance Services" — SỬA LẠI toàn bộ. GIỮ NGUYÊN
tên gói/giá (Regular $25/$55, Standard $35/$85 "Popular", Premium
$69/$99), chỉ đổi mô tả/tính năng/nút:

**Regular Plan** — "Ideal for individuals seeking essential coverage,
this plan protects against life's most common risks with
straightforward, no-fuss protection."
- Basic liability coverage
- 24/7 claims support
- Standard property protection
- Online policy management
- Email support

**Standard Plan (Popular)** — "This package includes broader coverage,
faster claims processing, and added protection for a more complete
peace of mind."
- Everything in the Regular Plan
- Extended liability coverage
- Accident & injury protection
- Priority claims processing
- Family coverage add-on

**Premium Plan** — "The most comprehensive insurance plan, offering full
coverage, priority support, and tailored protection for your family and
assets."
- All in the Standard Plan
- Full asset protection
- Priority 24/7 claims support
- Personalized risk assessment
- Dedicated insurance advisor

Đổi nút "Appointment Now" ở cả 3 gói → "Get a Quote".

Swiper (data-preview=3/tablet=2/mobile=1), tab Monthly/Yearly (tái dùng
cơ chế tab giá đã có pattern từ dự án trước). Cuối trang: section-faqs-1
(tái dùng).

=====================================================================
TRANG 6 — /demo-insurance/faqs (faqs.html)
=====================================================================

ĐỦ 10 câu hỏi (5 câu đầu giống hệt trang chủ + 5 câu MỚI: Can I change my
plan later?/Do I need to see a doctor first?/How do I renew my
insurance?/Can I get coverage for accidents?/Can I use any hospital with
my plan?) — TẤT CẢ ĐỀU PHÙ HỢP insurance. GIỮ NGUYÊN toàn bộ câu trả lời
(dù lặp lại giống nhau, đã xác nhận không sửa — đúng quyết định đã áp
dụng cho trang chủ). Layout "fixed-thumb" (heading sticky khi cuộn qua
10 câu — tái dùng cơ chế sticky đã có).

Data 10 câu tách vào src/data/demo-insurance/faqsFull.ts. Cuối trang:
section-request (tái dùng từ trang chủ).

=====================================================================
SAU KHI XONG CẢ 6 TRANG
=====================================================================

Playwright so sánh với HTML gốc:
- Các section tái dùng (About, Services Swiper, Overview, FAQ) hoạt động
  đúng, không lỗi khi tái sử dụng nhiều lần
- 6 team member link đúng /team-detail/[slug], vị trí 5 hiện đúng
  "Daniel Reyes - Director of Claims" (không còn trùng Amira Hassan)
- team-detail không còn mâu thuẫn CEO/CMO
- Pricing hiện đúng nội dung insurance mới, không còn dấu vết y tế
- FAQ trang riêng hiện đủ 10 câu, sticky heading hoạt động
- Không phụ thuộc jQuery/Bootstrap JS, build production pass