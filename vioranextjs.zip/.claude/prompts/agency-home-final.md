Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

QUAN TRỌNG: Mọi hiệu ứng CSS/animation/transition/easing/delay phải GIỐNG
TUYỆT ĐỐI HTML gốc — đọc kỹ CSS/JS gốc lấy đúng con số, không áng chừng,
không tự đơn giản hoá. Nếu không chắc cách implement 1 hiệu ứng phức tạp
trong React, DỪNG LẠI hỏi thay vì tự chọn cách khác.

Convert trang chủ ../viora/viora/demo-agency/index.html (route
"/demo-agency") — Header/Footer ĐÃ CÓ SẴN, chỉ làm <main-content> (6
section, ĐÃ ĐỌC ĐỦ). LÀM THEO TỪNG NHÓM, verify từng nhóm trước khi sang
nhóm tiếp.

TRƯỚC KHI BẮT ĐẦU: mở lại code ProjectsSection/CaseStudiesSection,
TestimonialSection, useCountUp đã build ở corporate-home-final.md — NHIỀU
KỸ THUẬT Ở ĐÂY TÁI DÙNG ĐƯỢC (custom cursor, Swiper thumbs đồng bộ,
counter), không viết lại từ đầu nếu corporate đã có sẵn cơ chế đúng.

## NHÓM 1: Hero (ảnh tĩnh + parallax) + About (counter tái dùng)

- HeroBanner.tsx: KHÁC corporate — đây là ảnh TĨNH (không phải Swiper),
  có hiệu ứng parallax (data-rotate="180" trên shape trang trí — xoay
  theo scroll, đọc đúng cơ chế parallax.js gốc). Nút "Get in touch" có
  hiệu ứng hover đặc biệt (2 icon ArrowUpRight chồng nhau, class
  "btn-hover-rounded-icon" — đọc đúng CSS để tái hiện đúng kiểu hover
  này, sẽ dùng lại nhiều lần ở các nút khác trong trang).

- AboutSection.tsx: heading có class "text-change-color" (hiệu ứng đổi
  màu chữ khi cuộn — đọc đúng cơ chế trong CSS/JS gốc trước khi code,
  KHÔNG đoán). 4 counter — TÁI DÙNG THẲNG hook useCountUp đã build ở
  corporate (cùng cơ chế data-count/data-duration).

## NHÓM 2: Services (4 item hover-reveal ảnh) + Our Project (Swiper + custom cursor)

- ServicesNumbered.tsx: 4 "tf-box-number" (số thứ tự 01-04, tiêu đề, mô
  tả, ảnh "img-hover" ẩn mặc định). Đọc đúng CSS/JS gốc xem ảnh
  "img-hover" hiện theo cách nào (hover cả hàng thì ảnh hiện lên cố định
  hay ảnh theo con trỏ chuột — XÁC MINH không đoán).

- OurProjectSection.tsx: Swiper (data-screen="767" data-preview="1"),
  TÁI DÙNG cơ chế "custom cursor" (chữ "View" bám chuột) đã build ở
  CaseStudiesSection của corporate — cùng class cursor-wrapper/
  custom-cursor, tái dùng hook/component đã có.

## NHÓM 3: Resume (tab hover đổi ảnh + marquee lồng trong section)

- ResumeSection.tsx: bên trái 4 ảnh xếp lớp (tab1-4, mặc định hiện
  tab1), bên phải 4 "wrap-resume-item" có data-tab tương ứng — HOVER vào
  item nào thì đổi ảnh sang đúng tab đó (class "tabs-hover-wrap
  tab-effect-left" — xác nhận là HOVER trigger, không phải click, đọc kỹ
  CSS/JS gốc để chắc chắn). Dùng useState lưu tab đang active.

- Marquee LỒNG BÊN TRONG section-resume-2 (không phải section riêng,
  class "infiniteslide" data-clone="2") — 5 câu lặp lại (Work Together/
  Start Now/Design Smart/Grow Faster/Build Bold). Nếu đã có hook marquee
  dùng chung từ trước, tái dùng; nếu chưa, viết mới và ghi chú để tái
  dùng cho niche sau.

## NHÓM 4: Testimonial (Swiper thumbs đồng bộ — tái dùng từ corporate)

- TestimonialSection.tsx: CÙNG CƠ CHẾ "Swiper thumbs đồng bộ" đã build ở
  corporate (2 swiper liên kết) — tái dùng component/hook đã có, chỉ đổi
  data. 3 testimonial, LƯU Ý 2/3 testimonial ghi category "Logistics" dù
  đây là niche agency (lỗi nội dung có thật, GIỮ NGUYÊN, không tự sửa).
  Data tách vào src/data/demo-agency/testimonials.ts.

## Sau MỖI nhóm

Chạy npm run dev, kiểm tra riêng phần vừa làm, báo cáo trước khi làm
nhóm tiếp theo.

## Sau khi xong toàn bộ

- Parallax hero + hiệu ứng xoay shape đúng khi cuộn
- Hover đổi màu chữ About đúng
- Hover Services đúng cách hiện ảnh
- Custom cursor "View" ở Our Project hoạt động
- Hover resume item đổi đúng ảnh tương ứng
- Marquee trong Resume chạy mượt
- Testimonial Swiper thumbs đồng bộ đúng
- Không phụ thuộc jQuery, build production pass