Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "solarenergy" (route "/demo-solarenergy").
Đã XÁC MINH bằng đọc trực tiếp demo-solarenergy/index.html — KHÔNG có bug
nội dung, 2 bản header giống hệt nhau.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer.

2 header "style-16 header-sticky bg-white" (ngoài) / "style-16" (trong) —
NỘI DUNG GIỐNG HỆT NHAU. Cơ chế scroll: header-sticky → `useHeaderSticky`
(TÁI DÙNG). Container `tf-container large`, `header-inner position-relative
w-full px-0`.

## 2. Breakpoint — KHÁC các niche vừa làm, KHÔNG có class "xl-hide"

`<nav class="main-menu">` KHÔNG có class `xl-hide`/`style-2` gì thêm, và
`.mobile-button` dùng `d-lg-none` (KHÔNG phải `d-xl-none`) → mốc "lg"
(991/992px), ĐÚNG như bảng mục 1 (solarenergy = lg, khác 5 niche vừa làm
đều là xl). Layout ẩn/hiện main-menu/mobile-button dựa vào rule mặc định
của `.main-menu`/`.mobile-button` trong _header.scss (không cần class
phụ), giữ đúng y hệt cấu trúc class trong HTML gốc (không tự thêm
"xl-hide").

## 3. Header-right — 1 CTA "Let's Talk" hiệu ứng đổi chữ khi hover

KHÔNG có `.nav-icon-list`, KHÔNG có header-contact. Chỉ có:
```
<a href="#" class="tf-btn btn-switch-text sm-hide">
  <span>
    <span class="btn-double-text" data-text="Let's Talk">Let's Talk</span>
  </span>
</a>
```
Hiệu ứng đổi chữ khi hover là THUẦN CSS (class `btn-switch-text` +
`.btn-double-text[data-text]`, dùng `content: attr(data-text)` trong
_header.scss/_button.scss — đã xác nhận KHÔNG có xử lý JS nào cho
"btn-double-text" trong assets/js/main.js), giữ nguyên markup, không cần
JS. Ẩn ở breakpoint "sm" (≤575px, `sm-hide`). Giữ đúng ký tự apostrophe
cong "'" trong "Let's Talk" (khác dấu nháy đơn thẳng ').

## 4. Menu nội dung — không có bug

12 demo mega-menu đúng thứ tự chuẩn, solarenergy KHÔNG có mặt trong 12
demo featured của chính nó. Pages/Services/Project/Blog/Contact dùng đúng
route corporate. Mega-menu có class "menu-rounded" (giữ đúng, giống
gardenlandscaping). Nút "View all demos" chỉ `tf-btn` trơn.

Mobile offcanvas (`#menu-mobile`, KHÔNG có class "style-dark") đủ 20
niche, đúng thứ tự chuẩn, "Solar Energy" tự active đúng vị trí. 5 nhóm
accordion, Contact link thẳng cuối. Modal "View all demos": link
"/landing#demos".

Logo: `logo-solar-energy-1.svg` (167x52 header VÀ 193x44 mobile — dùng
đúng biến thể "-1").

## Sau khi xong — checklist verify

- ≥992px main-menu hiện/mobile-button ẩn; ≤991px ngược lại (mốc LG, khác
  hẳn 5 niche vừa làm)
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- Hover CTA "Let's Talk" đổi chữ overlay (CSS attr, không cần JS), ẩn ở
  ≤575px
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: Demos đủ 20, mọi link đúng route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
