Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

Setup Header hoàn chỉnh cho niche "logistics" (route "/demo-logistics").
Đã XÁC MINH bằng đọc trực tiếp demo-logistics/index.html — KHÔNG có bug
nội dung, 2 bản header giống hệt nhau.

## 1. Cấu trúc DOM

gsap.min.js + ScrollSmoother + ScrollTrigger + SplitText (không
splitting.min.js). #smooth-wrapper/#smooth-content bọc header thường +
nội dung + footer.

2 header "style-15 header-sticky bg-dark-color pt-0" (ngoài) / "style-15"
(trong) — NỘI DUNG GIỐNG HỆT NHAU. Cơ chế scroll: header-sticky →
`useHeaderSticky` (TÁI DÙNG). Breakpoint: `<nav class="main-menu
xl-hide">` → mốc "xl" (1199/1200), ĐÚNG như bảng mục 1. Container
`tf-container large`.

## 2. Header-right — KHÔNG có search/cart, có box khẩn cấp + CTA

Giống charity/logistics đều KHÔNG có `.nav-icon-list` (bỏ hẳn icon
search/cart cho style-14 VÀ style-15). `.header-right` có:
```
<div class="header-contact sm-hide">
  <div class="icon"><i class="icon-Headset"></i></div>
  <div>
    <span class="text-caption-2 text_white">Call Emergency</span>
    <div class="text-button text_white">1-555-678-8888</div>
  </div>
</div>
<a href="#" class="tf-btn style-border-3 btn-hover-animate-border md-hide">
  <span>Request A Quote</span>
  <span class="bg-effect"></span>
</a>
```
header-contact ẩn ở "sm" (≤575px). CTA "Request A Quote" href="#" (không
trỏ đâu cả trong HTML gốc, giữ nguyên href="#"), ẩn ở "md" (≤767px,
`md-hide`).

## 3. Menu nội dung — không có bug

12 demo mega-menu đúng thứ tự chuẩn, logistics KHÔNG có mặt trong 12 demo
featured của chính nó. Pages/Services/Project/Blog/Contact dùng đúng route
corporate, không bug. Nút "View all demos" ở style-15 chỉ có class
`tf-btn` trơn (không có `btn-mega-2`/`btn-bg-primary-2` như niche khác —
giữ đúng, không tự thêm class).

Mobile offcanvas (`#menu-mobile`, CÓ class "style-dark" — giống
carservices) đủ 20 niche, đúng thứ tự chuẩn, "Logistics" tự active đúng
vị trí. 5 nhóm accordion, Contact link thẳng cuối. Modal "View all demos":
link "/landing#demos".

Logo: `logo-logistics-1.svg` (167x52 header VÀ 193x44 mobile — dùng đúng
biến thể "-1", không dùng "-2").

## Sau khi xong — checklist verify

- ≥1200px main-menu hiện/mobile-button ẩn; ≤1199px ngược lại
- Hover Pages/Services/Project/Blog xổ đúng submenu (CSS hover)
- KHÔNG có icon search/cart (đã bỏ đúng theo HTML gốc)
- header-contact hiện, ẩn đúng ở ≤575px; CTA "Request A Quote" ẩn đúng ở
  ≤767px
- Cơ chế header-sticky: cuộn xuống ẩn, cuộn lên hiện, chỉ áp dụng từ
  scrollTop >= 400
- Mobile: offcanvas có class "style-dark", Demos đủ 20, mọi link đúng
  route corporate
- Không có `.char`, không console error, không phụ thuộc jQuery/Bootstrap
  JS
- `npm run build` pass
