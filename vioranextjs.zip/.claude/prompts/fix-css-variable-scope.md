Đọc CLAUDE.md và .claude/prompts/master-workflow.md trước khi bắt đầu.

BUG MỚI PHÁT HIỆN (khác lỗi cascade Bootstrap đã sửa trước đó): chuyển
qua lại giữa các niche (vd /demo-agency ↔ /), MÀU SẮC/BIẾN CSS BỊ LẪN
QUA NHAU — do MỌI file src/styles/demo-<niche>.scss đều định nghĩa biến
màu ở `:root` (phạm vi TOÀN TÀI LIỆU), trong khi Next.js gộp CHUNG tất cả
CSS import (kể cả import riêng trong từng layout.tsx của route group)
vào 1 bundle CSS TOÀN CỤC — khiến file nào load sau trong bundle sẽ đè
biến màu của MỌI trang, không phân biệt route.

## Cách sửa: scope biến CSS theo từng niche bằng data-attribute

1. Với TỪNG file src/styles/demo-<niche>.scss (cả 20 niche), đổi:
     :root {
       --Primary: ...;
       --Secondary: ...;
       ...
     }
   thành:
     [data-niche="<niche>"] {
       --Primary: ...;
       --Secondary: ...;
       ...
     }
   (thay đúng "<niche>" bằng tên niche tương ứng file, ví dụ "agency",
   "corporate"...). GIỮ NGUYÊN toàn bộ phần còn lại của file (font-face
   class, h1-h6 rule...) — CHỈ đổi selector bọc ngoài của khối biến màu.

2. Trong MỖI route group layout.tsx (app/(demo-<niche>)/layout.tsx), tìm
   phần tử bọc ngoài cùng {children} (thường là <div> hoặc <main> gốc
   của layout đó), thêm thuộc tính `data-niche="<niche>"` vào phần tử đó
   (thay đúng tên niche). Nếu route group hiện tại KHÔNG có 1 wrapper div
   nào bọc ngoài (children được return trực tiếp), thêm 1 <div
   data-niche="..."> bọc quanh {children} (kèm Header/Footer nếu chúng
   đang nằm trong layout này) để đảm bảo MỌI phần tử con đều nằm trong
   phạm vi CSS variable đúng.

3. Route "/" (corporate) và mọi route khác đều áp dụng y hệt — không bỏ
   sót niche nào trong 20 niche.

4. Nếu có bất kỳ CSS nào đang dùng `:root` cho mục đích KHÁC (không phải
   biến theo niche, ví dụ biến dùng chung toàn site như breakpoint hay
   spacing chuẩn) — GIỮ NGUYÊN ở `:root` thật, KHÔNG đổi nhầm những biến
   dùng chung này thành scoped.

## Verify bằng Playwright

- Mở route "/" (corporate), lấy computed value của
  `getComputedStyle(document.documentElement).getPropertyValue('--Primary')`
  hoặc phần tử có data-niche="corporate" — phải ra đúng #94F3B4 (màu
  corporate).
- Mở route "/demo-agency" trong CÙNG 1 session Next.js (client-side
  navigation, không reload cứng) — kiểm tra lại giá trị --Primary tại
  phần tử data-niche="agency" phải ra đúng #CCFF77 (màu agency), KHÔNG
  bị dính màu corporate.
- Test qua lại CẢ 2 CHIỀU (corporate→agency, agency→corporate) nhiều lần
  bằng client-side navigation (click Link, không gõ URL mới) để chắc
  chắn không còn hiện tượng lẫn màu.
- Test thêm với 2-3 niche khác bất kỳ (đã làm Header/Footer trước đó) để
  xác nhận sửa đúng cho toàn bộ 20 niche, không chỉ 2 niche đã có trang
  chủ.

## Sau khi xong

Build production pass. Cập nhật master-workflow.md ghi lại quy tắc này:
"BẮT BUỘC mọi file demo-<niche>.scss dùng selector [data-niche='...'],
KHÔNG BAO GIỜ dùng :root cho biến màu riêng niche" — để các niche làm
sau (nếu file scss được viết mới) tuân theo ngay từ đầu.